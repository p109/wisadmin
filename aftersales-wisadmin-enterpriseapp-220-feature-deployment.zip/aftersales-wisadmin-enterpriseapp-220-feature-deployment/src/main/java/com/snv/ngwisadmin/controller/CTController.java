package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.componenttype.CTClassDTO;
import com.snv.ngwisadmin.model.componenttype.CTDescDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleMap;
import com.snv.ngwisadmin.service.CTService;

@Controller
public class CTController {

	@Autowired
	CTService service;
	
	@RequestMapping(value = "/get-ctc-desc", method = RequestMethod.GET)
	@ResponseBody
	public List<CTClassDTO> getCTClassDesc()
	{
		System.out.println("get ctc desc controller");
		return service.getCTClassDesc();
	}
	
	@RequestMapping(value = "/get-ct-desc", method = RequestMethod.GET)
	@ResponseBody
	public List<CTDescDTO> getCTDesc()
	{
		System.out.println("get ct desc controller");
		return service.getCTDesc();
	}
	
	@RequestMapping(value = "/get-ct-rule", method = RequestMethod.GET)
	@ResponseBody
	public CTRuleMap getCTRule()
	{
		System.out.println("get ct rule controller");
		return service.getCTRule();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/insert-ct-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<CTDescDTO> insertCTDesc(@RequestBody CTDescDTO dto)
	{
		System.out.println("insert ct");
		return service.insertCTDesc(dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-ct-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<CTDescDTO> udpateCTDesc(@RequestBody List<CTDescDTO> dtoList)
	{
		System.out.println("update ct");
		return service.updateCTDesc(dtoList);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/delete-ct-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<CTDescDTO> deleteCTDesc(@RequestBody CTDescDTO dto)
	{
		System.out.println("delete ct");
		return service.deleteCTDesc(dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/insert-ct-class", method = RequestMethod.POST)
	@ResponseBody
	public List<CTClassDTO> insertCTClass(@RequestBody CTClassDTO dto)
	{
		return service.insertCTClassDesc(dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-ct-class", method = RequestMethod.POST)
	@ResponseBody
	public List<CTClassDTO> updateCTClass(@RequestBody List<CTClassDTO> dtoList)
	{
		return service.updateCTClassDesc(dtoList);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/delete-ct-class", method = RequestMethod.POST)
	@ResponseBody
	public List<CTClassDTO> deleteCTClass(@RequestBody CTClassDTO dto)
	{
		return service.deleteCTClassDesc(dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/insert-ct-rule", method = RequestMethod.POST)
	@ResponseBody
	public CTRuleMap insertCTRule(@RequestBody CTRuleDTO dto)
	{
		return service.insertCTRule(dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-ct-rule", method = RequestMethod.POST)
	@ResponseBody
	public CTRuleMap updateCTRule(@RequestBody List<CTRuleDTO> dtoList)
	{
		return service.updateCTRule(dtoList);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/delete-ct-rule", method = RequestMethod.POST)
	@ResponseBody
	public CTRuleMap deleteCTRule(@RequestBody CTRuleDTO dto)
	{
		return service.deleteCTRule(dto);
	}
	
	//TODO: Eventually this should get done
	@PreAuthorize("hasAnyAuthority('ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/promote-ct-rule", method = RequestMethod.GET)
	public String promoteCTRule()
	{
		//service.promoteCTRule();
		return "";
	}
}
