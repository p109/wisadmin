package com.snv.ngwisadmin.model.wcc;

import javax.validation.constraints.NotEmpty;

public class CoverageCodeRuleDTO {
	// Int so can't apply empty or null check.In db it is non-nullable
	int id;
	@NotEmpty(message = "WCC can not be empty")
	String wcc;
	@NotEmpty(message = "Effective Start Date can not be empty")
	String effectiveStart;
	String effectiveEnd;
	String user;
	String updateTime;
	// Int so can't apply empty or null check.In db it is non-nullable
	int monthLimit;
	// Int so can't apply empty or null check.In db it is non-nullable
	int mileLimit;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getWcc() {
		return wcc;
	}

	public void setWcc(String wcc) {
		this.wcc = wcc;
	}

	public String getEffectiveStart() {
		return effectiveStart;
	}

	public void setEffectiveStart(String effectiveStart) {
		this.effectiveStart = effectiveStart;
	}

	public String getEffectiveEnd() {
		return effectiveEnd;
	}

	public void setEffectiveEnd(String effectiveEnd) {
		this.effectiveEnd = effectiveEnd;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public int getMonthLimit() {
		return monthLimit;
	}

	public void setMonthLimit(int monthLimit) {
		this.monthLimit = monthLimit;
	}

	public int getMileLimit() {
		return mileLimit;
	}

	public void setMileLimit(int mileLimit) {
		this.mileLimit = mileLimit;
	}

}
