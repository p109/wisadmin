package com.snv.ngwisadmin.util;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

public class Utility {

	// In case a result set object is null, convert to string
	public static String checkNull(Date input) {
		if (input == null) {
			return "null";
		} else {
			return input.toString();
		}
	}

	public static String checkNull(Timestamp input) {
		if (input == null) {
			return "";
		} else {
			return input.toString();
		}
	}

	// Converts string input yyyy-mm-dd into a Date object
	public static Date toDate(String input) {
		if (input == null || input.equals("null")) {
			return null;
		} else {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			try {
				return new Date(format.parse(input).getTime());
			} catch (ParseException e) {
				// T3679A2 -- handle this later
				System.err.println(e.getMessage());
			}
		}
		return null;
	}

	// retrieves the max value of that field
	public static int getMaxId(String field, NamedParameterJdbcTemplate t) {
		String sql = "";

		// There are more dynamic ways of doing this, but they are slower for Snowflake
		switch (field) {
		case "BODY RULE":
			sql = "select max(i_bdy_rule_id) from wis.bdy_rule";
			break;
		case "LAUNCH RULE":
			sql = "select max(i_lnch_rule_id) from wis.lnch_rule";
			break;
		case "REPORT":
			sql = "select max(i_rep_id) from wis.report";
			break;
		case "CT RULE":
			sql = "select max(i_ct_rule_id) from wis.ct_rule";
			break;
		case "EP PLANT":
			sql = "select max(i_ep_rule_id) from wis.ep_ucode";
			break;
		case "TP PLANT":
			sql = "select max(i_tp_rule_id) from wis.tp_ucode";
			break;
		case "WCC":
			sql = "select max(i_wcc_rule_id) from wis.wcc_rule";
			break;
		case "WORKFLOW REQUEST":
			sql = "select max(request_id) from wis.workflow_request";
			break;
		case "WORKFLOW STEP":
			sql = "select max(seq_step) from wis.workflow_step";
			break;
		case "BLOCK":
			sql = "select max(i_blk_id) from wis.block";
			break;
		}

		Map<String, Object> params = new HashMap<>();

		SqlRowSet rs = t.queryForRowSet(sql, params);
		int maxId = 0;
		while (rs.next()) {
			maxId = rs.getInt(1);
		}

		return maxId;
	}
}
