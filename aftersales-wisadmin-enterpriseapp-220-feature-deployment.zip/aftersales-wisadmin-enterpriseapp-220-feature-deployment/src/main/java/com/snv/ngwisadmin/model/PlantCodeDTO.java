package com.snv.ngwisadmin.model;

import javax.validation.constraints.NotEmpty;

public class PlantCodeDTO {

	@NotEmpty(message = "Model Year can not be empty")
	String modelYear;
	@NotEmpty(message = "Sales Code can not be empty")
	String salesCode;
	@NotEmpty(message = "Plant 1-digit code can not be empty")
	String plant;
	@NotEmpty(message = "Plant 2-digit code can not be empty")
	String plantCode;
	String user;
	String updateTimestamp;
	//Int so can't apply empty or null check.In db it is nullable
	int id;
	
	public PlantCodeDTO() {
		modelYear = "";
		salesCode = "";
		plant = "";
		plantCode = "";
		user = "";
		updateTimestamp = "";
		id = -1;
	}

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}

	public String getSalesCode() {
		return salesCode;
	}

	public void setSalesCode(String salesCode) {
		this.salesCode = salesCode;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(String updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
}
