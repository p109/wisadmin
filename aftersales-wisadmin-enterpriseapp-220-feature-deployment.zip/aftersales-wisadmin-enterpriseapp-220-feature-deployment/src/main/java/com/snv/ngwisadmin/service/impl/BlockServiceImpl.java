package com.snv.ngwisadmin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.BlockRuleDTO;
import com.snv.ngwisadmin.repository.BlockRuleDAO;
import com.snv.ngwisadmin.service.BlockService;

@Service
public class BlockServiceImpl implements BlockService {

	@Autowired
	BlockRuleDAO dao;
	
	public List<BlockRuleDTO> getBlockRules() {
		return dao.getBlockRules();
	}
	
	public List<BlockRuleDTO> insertBlockRule(BlockRuleDTO dto) {
		dao.insertBlockRule(dto);
		return dao.getBlockRules();
	}
	
	public List<BlockRuleDTO> updateBlockRule(List<BlockRuleDTO> dtoList) {
		dao.updateBlockRule(dtoList);
		return dao.getBlockRules();
	}
	
	public List<BlockRuleDTO> deleteBlockRule(BlockRuleDTO dto) {
		dao.deleteBlockRule(dto);
		return dao.getBlockRules();
	}
}
