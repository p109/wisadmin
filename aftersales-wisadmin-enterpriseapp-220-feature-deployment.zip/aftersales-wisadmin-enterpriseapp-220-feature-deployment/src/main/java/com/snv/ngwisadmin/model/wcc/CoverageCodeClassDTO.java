package com.snv.ngwisadmin.model.wcc;

import javax.validation.constraints.NotEmpty;

public class CoverageCodeClassDTO {

	// Int so can't apply empty or null check.In db it is non-nullable
	int id;
	@NotEmpty(message = "Condition Class can not be empty")
	String conditionClass;
	@NotEmpty(message = "Transaction can not be empty")
	String transaction;
	String user;
	String updateTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getConditionClass() {
		return conditionClass;
	}

	public void setConditionClass(String conditionClass) {
		this.conditionClass = conditionClass;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

}
