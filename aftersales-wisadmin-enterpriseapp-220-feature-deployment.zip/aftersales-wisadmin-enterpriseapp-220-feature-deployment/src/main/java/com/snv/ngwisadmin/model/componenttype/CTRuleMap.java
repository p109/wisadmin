package com.snv.ngwisadmin.model.componenttype;

import java.util.ArrayList;
import java.util.List;

public class CTRuleMap {

	List<CTRuleDTO> ruleList;
	List<CTClassDTO> classList;
	
	
	
	public CTRuleMap() {
		ruleList = new ArrayList<CTRuleDTO>();
		classList = new ArrayList<CTClassDTO>();
	}
	public List<CTRuleDTO> getRuleList() {
		return ruleList;
	}
	public void setRuleList(List<CTRuleDTO> ruleList) {
		this.ruleList = ruleList;
	}
	public List<CTClassDTO> getClassList() {
		return classList;
	}
	public void setClassList(List<CTClassDTO> classList) {
		this.classList = classList;
	}
	
	
}
