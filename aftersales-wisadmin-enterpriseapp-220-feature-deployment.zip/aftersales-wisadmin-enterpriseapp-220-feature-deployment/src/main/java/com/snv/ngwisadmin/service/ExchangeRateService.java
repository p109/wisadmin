package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.CanadaExchangeDTO;
import com.snv.ngwisadmin.model.ExchangeDTO;

public interface ExchangeRateService {

	public List<CanadaExchangeDTO> getCanadaRates();
	
	public List<CanadaExchangeDTO> modifyCanadaRate(CanadaExchangeDTO dto, String action);

	public List<ExchangeDTO> getExchangeRates();

	public List<ExchangeDTO> modifyExchangeRate(ExchangeDTO dto, String action);
}
