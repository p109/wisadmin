package com.snv.ngwisadmin.repository.body;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.PlatformDescDTO;

public class PlatformDescDTOMapper implements RowMapper<PlatformDescDTO> {

	public PlatformDescDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		PlatformDescDTO dto = new PlatformDescDTO();
		dto.setPlatform(rs.getString("C_PLTFRM"));
		dto.setDescription(rs.getString("X_PLTFRM"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
