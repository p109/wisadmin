package com.snv.ngwisadmin.repository;

import java.util.List;

import com.snv.ngwisadmin.model.CanadaExchangeDTO;
import com.snv.ngwisadmin.model.ExchangeDTO;

public interface ExchangeRateDAO {

	List<CanadaExchangeDTO> getCanadaExchange();
	
	boolean insertCanadaExchange(CanadaExchangeDTO dto);
	
	boolean updateCanadaExchange(CanadaExchangeDTO dto);
	
	boolean deleteCanadaExchange(CanadaExchangeDTO dto);

	List<ExchangeDTO> getExchange();

	boolean insertExchange(ExchangeDTO dto);

	boolean updateExchange(ExchangeDTO dto);

	boolean deleteExchange(ExchangeDTO dto);
	
}
