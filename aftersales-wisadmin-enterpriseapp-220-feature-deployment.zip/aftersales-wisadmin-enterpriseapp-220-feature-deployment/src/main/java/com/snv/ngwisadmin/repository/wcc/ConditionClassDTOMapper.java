package com.snv.ngwisadmin.repository.wcc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import ch.qos.logback.classic.pattern.Util;

import com.snv.ngwisadmin.model.wcc.ConditionClassDTO;
import com.snv.ngwisadmin.util.Utility;

public class ConditionClassDTOMapper implements RowMapper<ConditionClassDTO> {
	public ConditionClassDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		ConditionClassDTO dto = new ConditionClassDTO();
		dto.setCode(rs.getString("C_COND_CLS"));
		dto.setDesc(rs.getString("X_COND_CLS"));
		dto.setUpdateTime(Utility.checkNull(rs.getTimestamp("T_STMP_UPD")));
		dto.setUser(rs.getString("I_LOGON"));
		
		return dto;
	}
}
