package com.snv.ngwisadmin.repository.workflow;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.workflow.WorkflowApprovalDTO;
import com.snv.ngwisadmin.model.workflow.WorkflowInformation;
import com.snv.ngwisadmin.model.workflow.WorkflowRequestDTO;
import com.snv.ngwisadmin.model.workflow.WorkflowStepDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Constants;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class WorkflowDAOImpl implements WorkflowDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	DataSource ds;
	
	@Autowired
	AuthenticationFacade auth;

	@Override
	public WorkflowInformation getWorkflowRequests() {
		WorkflowInformation dto = new WorkflowInformation();
		String sql = "select * from wis.workflow_step";
		List<WorkflowStepDTO> stepList = jdbcTemplate.query(sql, new WorkflowStepDTOMapper());
		dto.setStepList(stepList);

		sql = "select * from wis.workflow_request";
		List<WorkflowRequestDTO> requestList = jdbcTemplate.query(sql, new WorkflowRequestDTOMapper());
		dto.setRequestList(requestList);

		sql = "select * from wis.workflow_approver";
		List<WorkflowApprovalDTO> approvalList = jdbcTemplate.query(sql, new WorkflowApprovalDTOMapper());
		dto.setApprovedList(approvalList);

		return dto;
	}

	@Override
	public int insertWorkflowRequest(WorkflowRequestDTO dto) {
		int maxId = Utility.getMaxId("WORKFLOW REQUEST", jdbcTemplate);

		System.out.println("Got max id");
		maxId++;
		String sql = "insert into wis.workflow_request values (:request_id , :requestor ,"
				+ ":request_desc , :request_status , :t_stmp_submit , :seq_step , null)";
		//SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("workflow_request");
		Map<String, Object> params = new HashMap<>();

		params.put("request_id", maxId);
		params.put("request_desc", dto.getDescription());
		params.put("requestor", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_submit", new Timestamp(System.currentTimeMillis()));
		params.put("request_status", Constants.WORKFLOW_PENDING);
		params.put("seq_step", 1);

		jdbcTemplate.update(sql, params);

		return maxId;
	}

	// Have to get request details from db as invalid info can be inserted from
	// front-end
	public WorkflowRequestDTO getIndividualRequest(WorkflowRequestDTO dto) {
		String reqDetails = "select * from wis.workflow_request where request_id=:id";

		Map<String, Object> params = new HashMap<>();

		params.put("id", dto.getId());
		List<WorkflowRequestDTO> dtoList = jdbcTemplate.query(reqDetails, params, new WorkflowRequestDTOMapper());
		return dtoList.get(0);
	}

	@Override
	public int approveWorkflowRequest(WorkflowRequestDTO dto) {

		dto = getIndividualRequest(dto);
		String stepQuery = "select step_name from wis.workflow_step where seq_step=:seqStep";

		Map<String, Object> selectParams = new HashMap<>();
		selectParams.put("seqStep", dto.getStep());

		String stepName = jdbcTemplate.queryForObject(stepQuery, selectParams, String.class);
		int seqStep = dto.getStep();

		// Can't approve or reject a workflow that is completed
		if (Constants.WORKFLOW_PENDING.equals(dto.getStatus())) {

			int maxSeqId = Utility.getMaxId("WORKFLOW STEP", jdbcTemplate);

			SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis")
					.withTableName("workflow_approver");
			Map<String, Object> params = new HashMap<>();

			params.put("approver", auth.getLoggedInUser().getUserId());// group name at a later point of time
			params.put("request_id", dto.getId());
			params.put("step_name", stepName);
			params.put("step_status", Constants.WORKFLOW_STEP_APPROVE);
			params.put("t_stmp_action", new Timestamp(System.currentTimeMillis()));
			params.put("seq_step", seqStep);

			jdbcInsert.execute(params);

			// Check if we are completed with the workflow
			if (seqStep < maxSeqId) {
				int updatedSeqStep = ++seqStep;
				System.out.println("updatedSeqStep is:  " + updatedSeqStep);

				String updateSql = "update wis.workflow_request set seq_step = :updatedSeqStep, "
						+ "t_stmp_submit = current_timestamp where request_id = :id";

				Map<String, Object> updateParams = new HashMap<>();
				updateParams.put("updatedSeqStep", updatedSeqStep);
				updateParams.put("id", dto.getId());

				jdbcTemplate.update(updateSql, updateParams);
				return updatedSeqStep;

			} else {
				String updateSql = "update wis.workflow_request set t_stmp_complete = current_timestamp, "
						+ "request_status=:updatedRequestStatus where request_id = :id";

				Map<String, Object> updateParams = new HashMap<>();
				updateParams.put("id", dto.getId());
				updateParams.put("updatedRequestStatus", Constants.WORKFLOW_APPROVED);

				jdbcTemplate.update(updateSql, updateParams);
				
				return -1;

			}
		}
		
		//Unable to update the request so set -2 so no email is sent
		return -2;
	}

	@Override
	public boolean rejectWorkflowRequest(WorkflowRequestDTO dto) {

		dto = getIndividualRequest(dto);
		// Can't reject a workflow that is closed
		if (Constants.WORKFLOW_PENDING.equals(dto.getStatus())) {
			// Puts step name into approval permanent record in case workflow steps are ever
			// modified
			String stepQuery = "select step_name from wis.workflow_step where seq_step=:seqStep";

			Map<String, Object> selectParams = new HashMap<>();
			selectParams.put("seqStep", dto.getStep());

			String stepName = jdbcTemplate.queryForObject(stepQuery, selectParams, String.class);

			SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis")
					.withTableName("workflow_approver");
			Map<String, Object> params = new HashMap<>();

			params.put("approver", auth.getLoggedInUser().getUserId());// group name at a later point of time
			params.put("request_id", dto.getId());
			params.put("step_name", stepName);
			params.put("step_status", Constants.WORKFLOW_STEP_REJECT);
			params.put("t_stmp_action", new Timestamp(System.currentTimeMillis()));
			params.put("seq_step", dto.getStep());

			jdbcInsert.execute(params);

			String updateSql = "update wis.workflow_request set request_status = :requestStatus, t_stmp_complete = current_timestamp where request_id=:requestId";

			Map<String, Object> updateParams = new HashMap<>();
			updateParams.put("requestStatus", Constants.WORKFLOW_REJECTED);
			updateParams.put("requestId", dto.getId());

			jdbcTemplate.update(updateSql, updateParams);
		}
		return true;
	}

	@Override
	public List<String> getApproverList(int requestId) {
		
		String sql = "select u.i_logon from aqip.usr_grp_asgn u, wis.workflow_step s, wis.workflow_request r " +
			"where r.request_id=:requestId and s.seq_step = r.seq_step and trim(u.n_group) = trim(s.n_group)";
		Map<String, Object> requestParams = new HashMap<>();
		requestParams.put("requestId", requestId);
		List<String> approvers = jdbcTemplate.queryForList(sql, requestParams, String.class);
		return approvers;

	}
	
	//Returns list of ids who receive notification mails upon request completion
	public List<String> getNotificationList() {
		String sql = "select i_logon from aqip.usr_grp_asgn where i_system='NGW' and " +
				" trim(n_group) = 'REQUEST NOTIFICATION'";
		Map<String, Object> params = new HashMap<>();
		return jdbcTemplate.queryForList(sql, params, String.class);
	}

}
