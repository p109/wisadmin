package com.snv.ngwisadmin.repository.plant;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;

import com.snv.ngwisadmin.model.PlantDTO;
import com.snv.ngwisadmin.util.Constants;

public class PlantDTOMapper implements RowMapper<PlantDTO> {

	String plantType;
	
	public PlantDTOMapper(String type)
	{
		super();
		plantType = type;
	}
	
	@Override
	public PlantDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		PlantDTO dto = new PlantDTO();
		if (Constants.ASSEMBLY_PLANT.equals(plantType))
		{
			dto.setPlant(rs.getString("I_PLT_ASSY"));
			dto.setPlantLocation(rs.getString("C_PLT_ASSY_LOC").trim());
			dto.setPlantDescription(rs.getString("X_PLT_ASSY"));
		}
		else
		if (Constants.ENGINE_PLANT.equals(plantType))
		{
			dto.setPlant(rs.getString("I_PLT_ENG"));
			dto.setPlantDescription(rs.getString("X_PLT_ENG"));
		}
		else
		if (Constants.TRANS_PLANT.equals(plantType))
		{
			dto.setPlant(rs.getString("I_PLT_TRN"));
			dto.setPlantDescription(rs.getString("X_PLT_TRN"));
		}
		
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTimestamp(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
