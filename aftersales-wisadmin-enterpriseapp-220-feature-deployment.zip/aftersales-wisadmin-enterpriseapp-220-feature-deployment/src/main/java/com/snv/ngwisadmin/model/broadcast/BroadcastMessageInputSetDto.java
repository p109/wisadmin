package com.snv.ngwisadmin.model.broadcast;

import java.util.HashSet;
import java.util.Set;

public class BroadcastMessageInputSetDto {

	Set<String> broadcastTypeSet = new HashSet<>();
	Set<String> reportTypeSet = new HashSet<>();
	Set<String> messageTypeSet = new HashSet<>();
	Set<String> messageSet = new HashSet<>();

	public Set<String> getBroadcastTypeSet() {
		return broadcastTypeSet;
	}

	public Set<String> getReportTypeSet() {
		return reportTypeSet;
	}

	public Set<String> getMessageTypeSet() {
		return messageTypeSet;
	}

	public Set<String> getMessageSet() {
		return messageSet;
	}

}
