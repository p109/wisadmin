package com.snv.ngwisadmin.model.broadcast;

public class BroadcastMessageDTO {

	int id;
	
	//Contact, Footnote, Home
	String broadcastType;
	
	//Advanced Reports, MOP/MIS, EWT, etc
	String reportType;
	
	//Comments, FAQs, Issues
	String messageType;
	
	String effectiveDate;
	String subject;
	String message;
	String email;
	String user;
	String updateTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBroadcastType() {
		return broadcastType;
	}
	public void setBroadcastType(String broadcastType) {
		this.broadcastType = broadcastType;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
}
