package com.snv.ngwisadmin.model;

import javax.validation.constraints.NotEmpty;

//Object can handle assembly, engine, or transmission plants
public class PlantDTO {
	@NotEmpty(message = "Plant can not be empty")
	String plant;
	@NotEmpty(message = "Plant location can not be empty")
	String plantLocation;
	@NotEmpty(message = "Plant description can not be empty")
	String plantDescription;
	String user;
	String updateTimestamp;
	
	public PlantDTO() {
		plant = "";
		plantLocation = "";
		plantDescription = "";
		user = "";
		updateTimestamp = "";
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPlantLocation() {
		return plantLocation;
	}

	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}

	public String getPlantDescription() {
		return plantDescription;
	}

	public void setPlantDescription(String plantDescription) {
		this.plantDescription = plantDescription;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(String updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}
	
	
}
