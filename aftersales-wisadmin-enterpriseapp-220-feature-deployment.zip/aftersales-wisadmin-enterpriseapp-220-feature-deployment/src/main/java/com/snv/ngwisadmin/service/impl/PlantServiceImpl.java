package com.snv.ngwisadmin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.PlantCodeDTO;
import com.snv.ngwisadmin.model.PlantDTO;
import com.snv.ngwisadmin.repository.plant.PlantMaintenanceDAO;
import com.snv.ngwisadmin.service.PlantService;

@Service
public class PlantServiceImpl implements PlantService {

	@Autowired
	PlantMaintenanceDAO dao;
	
	public List<PlantDTO> getPlantDesc(String type)
	{
		return dao.getPlantDesc(type);
	}
	
	public List<PlantCodeDTO> getPlantCodes(String type)
	{
		return dao.getPlantCodes(type);
	}
	
	public List<PlantDTO> insertPlantDesc(String type, PlantDTO dto)
	{
		
		setZeroPlantLocation(type, dto);
		dao.insertPlantDesc(type, dto);
		
		return getPlantDesc(type);
	}
	
	public List<PlantDTO> updatePlantDesc(String type, List<PlantDTO> dtoList)
	{
		//both plant locations need to be set for update
		setZeroPlantLocation(type, dtoList.get(0));
		setZeroPlantLocation(type, dtoList.get(1));
		dao.updatePlantDesc(type, dtoList);
		
		return getPlantDesc(type);
	}
	
	public List<PlantDTO> deletePlantDesc(String type, PlantDTO dto)
	{
		setZeroPlantLocation(type, dto);
		dao.deletePlantDesc(type, dto);
		
		return getPlantDesc(type);
	}
	
	//There are no locations for engine and transmission
			//They are hardcoded here
	private void setZeroPlantLocation(String type, PlantDTO dto)
	{
		if ("T".equals(type) || "E".equals(type))
		{
			dto.setPlantLocation("00000");
		}
	}

	@Override
	public List<PlantCodeDTO> insertPlantCode(String type, PlantCodeDTO dto) {
		dao.insertPlantCode(type, dto);
		return getPlantCodes(type);
	}

	@Override
	public List<PlantCodeDTO> updatePlantCode(String type,
			List<PlantCodeDTO> dtoList) {
		dao.updatePlantCode(type, dtoList);
		return getPlantCodes(type);
	}

	@Override
	public List<PlantCodeDTO> deletePlantCode(String type,
			PlantCodeDTO dto) {
		dao.deletePlantCode(type, dto);
		return getPlantCodes(type);
	}
}
