package com.snv.ngwisadmin.repository.broadcast;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.broadcast.BroadcastTypeDTO;
import com.snv.ngwisadmin.util.Constants;

public class BroadcastTypeDTOMapper implements RowMapper<BroadcastTypeDTO> {

	private String broadcastType;
	
	public BroadcastTypeDTOMapper(String type) {
		super();
		broadcastType = type;
	}
	
	public BroadcastTypeDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		BroadcastTypeDTO dto = new BroadcastTypeDTO();
		
		if (Constants.REPORT_DESC.equals(broadcastType))
		{
			dto.setBroadcastType(rs.getString("C_REP"));
			dto.setTypeDescription(rs.getString("X_REP"));
		}
		if (Constants.BROADCAST_TYPE_DESC.equals(broadcastType))
		{
			dto.setBroadcastType(rs.getString("C_TYP"));
			dto.setTypeDescription(rs.getString("X_TYP"));
		}
		if (Constants.BROADCAST_DESC.equals(broadcastType))
		{
			dto.setBroadcastType(rs.getString("C_BRD_TYP"));
			dto.setTypeDescription(rs.getString("X_BRD_TYP"));
		}
		
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
