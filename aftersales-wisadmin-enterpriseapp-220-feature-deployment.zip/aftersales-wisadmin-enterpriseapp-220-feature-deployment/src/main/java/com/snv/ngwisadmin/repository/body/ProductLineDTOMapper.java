package com.snv.ngwisadmin.repository.body;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.ProductLineDTO;

public class ProductLineDTOMapper implements RowMapper<ProductLineDTO> {

	public ProductLineDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		ProductLineDTO dto = new ProductLineDTO();
		dto.setProductLine(rs.getString("C_PL"));
		dto.setDescription(rs.getString("X_PL"));
		dto.setLopBook(rs.getString("C_LOP_BOOK"));
		dto.setPlatform(rs.getString("C_PLTFRM"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
