package com.snv.ngwisadmin.service.impl;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;
import com.snv.ngwisadmin.service.MailService;

@Service
public class MailServiceImpl implements MailService {

	//Sends a mail to all users in distribution list
	//The first email in the distribution list is the send to field
	//All other emails are added into cc
	public void sendMail(List<String> distribution, String title, String body)
	{
		//No mail can be sent
		if (distribution.size() == 0)
		{
			System.err.println("Distribution size is 0, no mail can send");
			return;
		}
		
	
		Mail mail = new Mail();
		mail.setFrom(new Email("mopar_wis_support_notification_group@fcagroup.com"));
		mail.addContent(new Content("text/plain", body));
		
		Personalization personalization = new Personalization();
		personalization.addTo(new Email(distribution.get(0)));
		personalization.setSubject(title);
		if (distribution.size() > 1)
		{
			for (int i = 1; i < distribution.size(); i++)
			{
				Email distMail = new Email(distribution.get(i));
				personalization.addCc(distMail);
			}
		}
		mail.addPersonalization(personalization);
	      
		SendGrid sg = 
	    		  new SendGrid("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");
	    Request request = new Request();
	    
	    try
	    {
	    	request.setMethod(Method.POST);
	    	request.setEndpoint("mail/send");
	    	request.setBody(mail.build());
 
	    	Response response = sg.api(request);
	    	//In case want to log anything from response
	    }
	    catch (IOException e)
	    {
	    	System.err.println("Error while sending mail: " + e.getMessage());
	    }
	    return;
	}
}
