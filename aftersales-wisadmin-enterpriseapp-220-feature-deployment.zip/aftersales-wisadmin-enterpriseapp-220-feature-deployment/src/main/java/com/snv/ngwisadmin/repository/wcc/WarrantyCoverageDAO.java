package com.snv.ngwisadmin.repository.wcc;

import java.util.List;

import com.snv.ngwisadmin.model.wcc.ConditionClassDTO;
import com.snv.ngwisadmin.model.wcc.ConditionCoverageDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeClassDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeRuleDTO;

public interface WarrantyCoverageDAO {

	public List<CoverageCodeDTO> getCoverageDesc();
	
	public boolean insertCoverageDesc(CoverageCodeDTO dto);
	
	public boolean updateCoverageDesc(CoverageCodeDTO dto);
	
	public boolean deleteCoverageDesc(CoverageCodeDTO dto);
	
	public List<CoverageCodeRuleDTO> getCoverageRule();
	
	public boolean insertCoverageRule(CoverageCodeRuleDTO dto);
	
	public boolean updateCoverageRule(CoverageCodeRuleDTO dto);
	
	public boolean deleteCoverageRule(CoverageCodeRuleDTO dto);
	
	//There is no update because all fields for update are the table index
	//It's simpler to delete and insert for update since all fields are checked
	public List<CoverageCodeClassDTO> getCoverageClass();
	
	public boolean insertCoverageClass(CoverageCodeClassDTO dto);
	
	public boolean deleteCoverageClass(CoverageCodeClassDTO dto);
	
	public List<ConditionClassDTO> getConditionClass();
	
	public List<ConditionCoverageDTO> getConditionCoverage();
	
	public boolean insertConditionClass(ConditionClassDTO dto);
	
	public boolean updateConditionClass(ConditionClassDTO dto);
	
	public boolean deleteConditionClass(ConditionClassDTO dto);
}
