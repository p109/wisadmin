package com.snv.ngwisadmin;

import java.io.IOException;
import java.util.Base64;
import java.util.Properties;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.UserCredentialsDataSourceAdapter;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.validation.SmartValidator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.DecryptionFailureException;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.amazonaws.services.secretsmanager.model.InternalServiceErrorException;
import com.amazonaws.services.secretsmanager.model.InvalidParameterException;
import com.amazonaws.services.secretsmanager.model.InvalidRequestException;
import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.snv.ngwisadmin.security.LdapClient;

@SpringBootApplication
public class AppBootConfig extends SpringBootServletInitializer {

	@Autowired
	Environment env;

	// public final String snowflakesecretName = "snowflake_credentials";

	public static void main(String[] args) {
		SpringApplication.run(AppBootConfig.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder appBuilder) {
		return appBuilder.sources(AppBootConfig.class);
	}

	@Bean
	public DataSource pgDataSource() {
		DriverManagerDataSource ds;
		ds = new DriverManagerDataSource(env.getProperty("jdbc.url"), getDataSourceSecrets());
		System.out.println("After establishing datsource");
		ds.setDriverClassName(env.getProperty("jdbc.driver"));
		return ds;
	}

	private Properties getDataSourceSecrets() {

		// Create a Secrets Manager client
		AWSSecretsManager client = AWSSecretsManagerClientBuilder.standard().withRegion(Regions.US_EAST_1).build();

		String secret;
		JsonNode secretsJson = null;
		ObjectMapper objectMapper = new ObjectMapper();

		String snowflakesecretName = env.getProperty("snowflakesecretName");
		GetSecretValueRequest getSecretValueRequest = new GetSecretValueRequest().withSecretId(snowflakesecretName);
		GetSecretValueResult getSecretValueResult = null;

		try {
			getSecretValueResult = client.getSecretValue(getSecretValueRequest);

		} catch (DecryptionFailureException e) {
			System.out.println("Decryption Failure Exception: " + e.getMessage());
		}

		catch (InternalServiceErrorException e) {
			System.out.println("Internal Service Error Exception: " + e.getMessage());
		}

		catch (InvalidRequestException e) {
			System.out.println("The request was invalid due to: " + e.getMessage());
		}

		catch (InvalidParameterException e) {
			System.out.println("The request had invalid params: " + e.getMessage());
		} catch (ResourceNotFoundException e) {
			System.out.println("Resource Not Found Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception inside getting datasecrets: " + e.getMessage());
			e.printStackTrace();
		}
		if (getSecretValueResult.getSecretString() != null) {
			secret = getSecretValueResult.getSecretString();
		} else {
			secret = new String(Base64.getDecoder().decode(getSecretValueResult.getSecretBinary()).array());
		}

		if (secret != null) {
			try {
				secretsJson = objectMapper.readTree(secret);
			}

			catch (IOException e) {
				System.out.println("Exception while retrieving secret values: " + e.getMessage());
			}
		}

		else {
			System.out.println("The Secret String returned is null");

		}

		Properties props = new Properties();
		props.put("user", secretsJson.get("User Name").textValue());
		props.put("password", secretsJson.get("password").textValue());
		/*
		 * props.put("warehouse", "WIS_WH"); props.put("db", "WIS_DB"); //
		 * props.put("schema", "S"); props.put("schema", "WIS_SCHEMA");
		 * props.put("role", "WIS_OPERATIONAL");
		 */
		props.put("warehouse", env.getProperty("jdbc.warehouse"));
		props.put("db", env.getProperty("jdbc.db"));
		props.put("schema", env.getProperty("jdbc.schema"));
		props.put("role", env.getProperty("jdbc.role"));
		return props;

	}

	@Bean
	public SmartValidator localValidatorFactoryBean() {
		return new LocalValidatorFactoryBean();

	}

	/*
	 * @Override public void addResourceHandlers(final ResourceHandlerRegistry
	 * registry) { //
	 * registry.addResourceHandler("/static/**").addResourceLocations(
	 * "classpath:/static/"); //
	 * registry.addResourceHandler("/**").addResourceLocations("/"); }
	 */

	@Bean
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate(DataSource dataSource) {
		return new NamedParameterJdbcTemplate(dataSource);
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	private DataSource getDataSourceFromJndiName(final String dsJndiName, final String dsUserId, final String dsAuthPin)
			throws NamingException {
		UserCredentialsDataSourceAdapter dataSource = new UserCredentialsDataSourceAdapter();
		javax.naming.InitialContext ctx = new javax.naming.InitialContext();
		javax.sql.DataSource ds = (javax.sql.DataSource) ctx.lookup(dsJndiName);
		dataSource.setTargetDataSource(ds);
		dataSource.setUsername(dsUserId);
		dataSource.setPassword(dsAuthPin);

		return dataSource;
	}

	@Bean
	public LdapContextSource contextSource() {
		LdapContextSource contextSource = new LdapContextSource();
		//JsonNode secretsJson=getLdapSecrets();
		System.out.println("ldap url");
		contextSource.setUrl(env.getProperty("ldap.url"));
		//contextSource.setUrl(secretsJson.get("User Name").textValue());
		System.out.println("ldap principal");
		contextSource.setUserDn(env.getProperty("ldap.principal"));
		//contextSource.setUserDn(env.getProperty("ldap.principal"));
		contextSource.setPassword(env.getProperty("ldap.password"));
		//contextSource.setPassword(env.getProperty("ldap.password"));
		System.out.println("return context");
		return contextSource;
	}

	private JsonNode getLdapSecrets() {

		AWSSecretsManager client = AWSSecretsManagerClientBuilder.standard().withRegion(Regions.US_EAST_1).build();
		String secret;
		JsonNode secretsJson = null;
		ObjectMapper objectMapper = new ObjectMapper();

		String ldapSecretName = env.getProperty("ldapSecretName");
		GetSecretValueRequest getSecretValueRequest = new GetSecretValueRequest().withSecretId(ldapSecretName);
		GetSecretValueResult getSecretValueResult = null;

		try {
			getSecretValueResult = client.getSecretValue(getSecretValueRequest);

		} catch (DecryptionFailureException e) {
			System.out.println("Decryption Failure Exception: " + e.getMessage());
		} catch (InternalServiceErrorException e) {
			System.out.println("Internal Service Error Exception: " + e.getMessage());
		} catch (InvalidRequestException e) {
			System.out.println("The request was invalid due to: " + e.getMessage());
		}

		catch (InvalidParameterException e) {
			System.out.println("The request had invalid params: " + e.getMessage());
		} catch (ResourceNotFoundException e) {
			System.out.println("Resource Not Found Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception inside getting datasecrets: " + e.getMessage());
			e.printStackTrace();
		}
		if (getSecretValueResult.getSecretString() != null) {
			secret = getSecretValueResult.getSecretString();
		} else {
			secret = new String(Base64.getDecoder().decode(getSecretValueResult.getSecretBinary()).array());
		}

		if (secret != null) {
			try {
				secretsJson = objectMapper.readTree(secret);
				return secretsJson;
			}

			catch (IOException e) {
				System.out.println("Exception while retrieving secret values: " + e.getMessage());
			}
		}

		else {
			System.out.println("The Secret String returned is null");

		}
		return null;


	}

	@Bean
	public LdapTemplate ldapTemplate() {
		return new LdapTemplate(contextSource());
	}

	@Bean
	public LdapClient ldapClient() {
		return new LdapClient();
	}
}
