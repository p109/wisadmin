package com.snv.ngwisadmin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.LdapUserDTO;
import com.snv.ngwisadmin.model.UserGroupDTO;
import com.snv.ngwisadmin.model.UserMembershipDTO;
import com.snv.ngwisadmin.repository.user.UserMaintenanceDAO;
import com.snv.ngwisadmin.security.LdapClient;
import com.snv.ngwisadmin.service.UserMaintenanceService;

@Service
public class UserMaintenanceServiceImpl implements UserMaintenanceService {

	@Autowired
	UserMaintenanceDAO dao;
	
	@Autowired
	LdapClient ldapClient;
	
	@Autowired
	@Qualifier("userManagerDetails")
	UserDetailsService udService;
	
	public List<UserGroupDTO> getUserGroup()
	{
		return dao.getUserGroup();
	}
	
	//Gets users with their roles, optional id parameter
	public List<UserMembershipDTO> getUserMembership(String id)
	{
		if (id == null || "".equals(id))
		{
			return dao.getUserMembership();
		}
		else
		{
			return dao.getUserMembership(id);
		}
	}
	
	//Gets username and email of a searched user
	public LdapUserDTO getUserDetails(String id)
	{
		List<LdapUserDTO> userList = ldapClient.search(id.toLowerCase());
		if (userList.size() > 0)
		{
			return userList.get(0);
		}
		else
		{
			return null;
		}
	}
	
	//Intended for one user multiple groups
	//To remove a user from all groups, one element of UserMembershipDTO is passed with
	//the id of the user, and blank group
	public boolean updateUserMembership(List<UserMembershipDTO> userGroup)
	{
		String id = userGroup.get(0).getUserId();
		List<UserMembershipDTO> existingGroup = dao.getUserMembership(id);
		
		//Check through groups user has currently that don't exist in the update
		//Any groups not in update are removed
		List<UserMembershipDTO> removeList = new ArrayList<>();
		for (UserMembershipDTO exist : existingGroup)
		{
			boolean removeGroup = true;
			for (UserMembershipDTO newGroup : userGroup)
			{
				if (newGroup.getUserGroup().equals(exist.getUserGroup()))
				{
					removeGroup = false;
					break;
				}
			}
			
			if (removeGroup)
			{
				removeList.add(exist);
			}
		}
		
		//Check through groups user is updating that they don't have currently
		//Any groups not current are added
		List<UserMembershipDTO> addList = new ArrayList<>();
		for (UserMembershipDTO newGroup : userGroup)
		{
			boolean addGroup = true;
			for (UserMembershipDTO exist : existingGroup)
			{
				if (newGroup.getUserGroup().equals(exist.getUserGroup()))
				{
					addGroup = false;
					break;
				}
			}
			if (addGroup)
			{
				addList.add(newGroup);
			}
		}
		
		dao.deleteUserMemberList(removeList);
		dao.insertUserMemberList(addList);
		
		//TODO When adding or removing super admin, must be super admin
		
		InMemoryUserDetailsManager manager = (InMemoryUserDetailsManager) udService;
		List<String> roleList = dao.getUserRoles(id);
		List<GrantedAuthority> authorityList = new ArrayList<>();
		for (String role : roleList)
		{
			authorityList.add(new SimpleGrantedAuthority(role));
		}
		manager.deleteUser(id);
		manager.createUser(User.withUsername(id).password("").authorities(authorityList).build());
		
		return true;
	}
}
