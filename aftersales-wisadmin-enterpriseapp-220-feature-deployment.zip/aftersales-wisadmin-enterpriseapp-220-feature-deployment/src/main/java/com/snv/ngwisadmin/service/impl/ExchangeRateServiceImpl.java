package com.snv.ngwisadmin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.CanadaExchangeDTO;
import com.snv.ngwisadmin.model.ExchangeDTO;
import com.snv.ngwisadmin.repository.ExchangeRateDAO;
import com.snv.ngwisadmin.service.ExchangeRateService;
import com.snv.ngwisadmin.util.Constants;

@Service
public class ExchangeRateServiceImpl implements ExchangeRateService {

	@Autowired
	ExchangeRateDAO dao;

	public List<CanadaExchangeDTO> getCanadaRates() {
		return dao.getCanadaExchange();
	}

	public List<CanadaExchangeDTO> modifyCanadaRate(CanadaExchangeDTO dto, String action) {
		if (Constants.INSERT.equals(action)) {
			dao.insertCanadaExchange(dto);
		}
		if (Constants.UPDATE.equals(action)) {
			dao.updateCanadaExchange(dto);
		}
		if (Constants.DELETE.equals(action)) {
			dao.deleteCanadaExchange(dto);
		}

		return dao.getCanadaExchange();
	}

	@Override
	public List<ExchangeDTO> getExchangeRates() {
		return dao.getExchange();
	}

	@Override
	public List<ExchangeDTO> modifyExchangeRate(ExchangeDTO dto, String action) {
		if (Constants.INSERT.equals(action)) {
			dao.insertExchange(dto);
		}
		if (Constants.UPDATE.equals(action)) {
			dao.updateExchange(dto);
		}
		if (Constants.DELETE.equals(action)) {
			dao.deleteExchange(dto);
		}

		return dao.getExchange();
	}
}
