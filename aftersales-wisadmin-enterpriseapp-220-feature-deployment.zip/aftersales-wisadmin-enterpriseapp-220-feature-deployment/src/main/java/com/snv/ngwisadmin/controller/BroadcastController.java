package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.broadcast.BroadcastMessageDTO;
import com.snv.ngwisadmin.model.broadcast.BroadcastMessageMap;
import com.snv.ngwisadmin.model.broadcast.BroadcastTypeDTO;
import com.snv.ngwisadmin.service.BroadcastService;

@Controller
public class BroadcastController {

	@Autowired
	BroadcastService service;
	
	@RequestMapping(value = "get-broadcast-type", method = RequestMethod.GET)
	@ResponseBody
	List<BroadcastTypeDTO> getBroadcastType(@RequestParam String type)
	{
		return service.getBroadcastType(type);
	}
	
	@RequestMapping(value = "get-broadcast-message", method = RequestMethod.GET)
	@ResponseBody
	List<BroadcastMessageDTO> getBroadcastMessage()
	{
		return service.getBroadcastMessage();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "modify-broadcast-type", method = RequestMethod.POST)
	@ResponseBody
	List<BroadcastTypeDTO> modifyBroadcastType(@RequestParam String type, @RequestParam String action,
			@RequestBody BroadcastTypeDTO dto)
	{
		return service.modifyBroadcastType(dto, type, action);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "modify-broadcast-message", method = RequestMethod.POST)
	@ResponseBody
	List<BroadcastMessageDTO> modifyBroadcastMessage(@RequestParam String action, 
			@RequestBody BroadcastMessageDTO dto)
	{
		return service.modifyBroadcastMessage(dto, action);
	}
	
	@RequestMapping(value = "get-input-parameters", method = RequestMethod.GET)
	@ResponseBody
	BroadcastMessageMap getInputParametersForBroadcastMessage()
	{
		return service.getInputParametersForBroadcastMessage();
	}
	
}
