package com.snv.ngwisadmin.repository.broadcast;

import java.util.List;

import com.snv.ngwisadmin.model.broadcast.BroadcastMessageDTO;
import com.snv.ngwisadmin.model.broadcast.BroadcastMessageMap;
import com.snv.ngwisadmin.model.broadcast.BroadcastTypeDTO;

public interface BroadcastDAO {

	public List<BroadcastTypeDTO> getBroadcastType(String type);
	
	public List<BroadcastMessageDTO> getBroadcastMessage();
	
	public boolean insertBroadcastType(BroadcastTypeDTO dto, String type);
	
	public boolean updateBroadcastType(BroadcastTypeDTO dto, String type);
	
	public boolean deleteBroadcastType(BroadcastTypeDTO dto, String type);
	
	public boolean insertBroadcastMessage(BroadcastMessageDTO dto);
	
	public boolean updateBroadcastMessage(BroadcastMessageDTO dto);
	
	public boolean deleteBroadcastMessage(BroadcastMessageDTO dto);

	public BroadcastMessageMap getInputParametersForBroadcastMessage();
}
