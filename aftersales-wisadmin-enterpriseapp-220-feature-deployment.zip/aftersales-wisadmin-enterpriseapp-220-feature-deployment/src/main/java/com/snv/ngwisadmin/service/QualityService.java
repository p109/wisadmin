package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.CommodityDirectorDTO;
import com.snv.ngwisadmin.model.QualityManagerDTO;

public interface QualityService {

	List<CommodityDirectorDTO> getCommodityDirector();

	List<CommodityDirectorDTO> modifyCommodityDirector(CommodityDirectorDTO dto, String action);

	List<QualityManagerDTO> getQualityManager();

	List<QualityManagerDTO> modifyQualityManager(QualityManagerDTO dto, String action);

}
