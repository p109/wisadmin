package com.snv.ngwisadmin.model.componenttype;

import javax.validation.constraints.NotEmpty;

public class CTRuleDTO {

	@NotEmpty(message = "CT can not be empty")
	String ct;
	@NotEmpty(message = "CT Class can not be empty")
	String ctClass;
	@NotEmpty(message = "Engine Plant can not be empty")
	String enginePlant;
	@NotEmpty(message = "Trans Plant can not be empty")
	String transPlant;
	@NotEmpty(message = "Scode Pattern can not be empty")
	String scodePattern;
	String buildStart;
	String buildEnd;
	@NotEmpty(message = "Effective Start Date can not be empty")
	String effectiveStart;
	String effectiveEnd;
	
	String user;
	String updateTime;
	//Int so can't apply empty or null check.In db it is non-nullable
	int id;
	@NotEmpty(message = "Product Line can not be empty")
	String productLine;
	String description;
	
	public CTRuleDTO() {
		ct = "";
		ctClass = "";
		enginePlant = "";
		transPlant = "";
		scodePattern = "";
		buildStart = "";
		buildEnd = "";
		effectiveStart = "";
		effectiveEnd = "";
		user = "";
		updateTime = "";
		id = -1;
		productLine = "";
	}

	public String getCt() {
		return ct;
	}

	public void setCt(String ct) {
		this.ct = ct;
	}

	public String getCtClass() {
		return ctClass;
	}

	public void setCtClass(String ctClass) {
		this.ctClass = ctClass;
	}

	public String getEnginePlant() {
		return enginePlant;
	}

	public void setEnginePlant(String enginePlant) {
		this.enginePlant = enginePlant;
	}

	public String getTransPlant() {
		return transPlant;
	}

	public void setTransPlant(String transPlant) {
		this.transPlant = transPlant;
	}

	public String getScodePattern() {
		return scodePattern;
	}

	public void setScodePattern(String scodePattern) {
		this.scodePattern = scodePattern;
	}

	public String getBuildStart() {
		return buildStart;
	}

	public void setBuildStart(String buildStart) {
		this.buildStart = buildStart;
	}

	public String getBuildEnd() {
		return buildEnd;
	}

	public void setBuildEnd(String buildEnd) {
		this.buildEnd = buildEnd;
	}

	public String getEffectiveStart() {
		return effectiveStart;
	}

	public void setEffectiveStart(String effectiveStart) {
		this.effectiveStart = effectiveStart;
	}

	public String getEffectiveEnd() {
		return effectiveEnd;
	}

	public void setEffectiveEnd(String effectiveEnd) {
		this.effectiveEnd = effectiveEnd;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getProductLine() {
		return productLine;
	}
	
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
}
