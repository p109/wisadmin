package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.wcc.ConditionClassDTO;
import com.snv.ngwisadmin.model.wcc.ConditionCoverageDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeClassDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeRuleDTO;
import com.snv.ngwisadmin.service.WarrantyCoverageService;
import com.snv.ngwisadmin.util.Constants;

@Controller
public class WarrantyCoverageController {

	@Autowired
	WarrantyCoverageService service;
	
	@RequestMapping(value = "/get-wcc-desc", method = RequestMethod.GET)
	@ResponseBody
	public List<CoverageCodeDTO> getWccDesc()
	{
		return service.getCoverageDesc();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-wcc-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<CoverageCodeDTO> modifyWccDesc(@RequestParam String action, 
			@RequestBody CoverageCodeDTO dto)
	{
		return service.modifyCoverageDesc(dto, action);
	}
	
	@RequestMapping(value = "/get-wcc-rule", method = RequestMethod.GET)
	@ResponseBody
	public List<CoverageCodeRuleDTO> getWccRule()
	{
		return service.getCoverageRules();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-wcc-rule", method = RequestMethod.POST)
	@ResponseBody
	public List<CoverageCodeRuleDTO> modifyWccRule(@RequestParam String action,
			@RequestBody CoverageCodeRuleDTO dto)
	{
		return service.modifyCoverageRule(dto, action);
	}
	
	@RequestMapping(value = "/get-wcc-class", method = RequestMethod.GET)
	@ResponseBody
	public List<CoverageCodeClassDTO> getWccClass()
	{
		return service.getCoverageClass();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-wcc-class", method = RequestMethod.POST)
	@ResponseBody
	public List<CoverageCodeClassDTO> modifyWccClass(@RequestParam String action,
			@RequestBody CoverageCodeClassDTO dto)
	{
		return service.modifyCoverageClass(dto, action);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-wcc-class", method = RequestMethod.POST)
	@ResponseBody
	public List<CoverageCodeClassDTO> updateWccClass(@RequestParam String action,
			@RequestBody List<CoverageCodeClassDTO> dto)
	{
		return service.updateCoverageClass(dto, action);
	}
	
	@RequestMapping(value = "/get-cond-class", method = RequestMethod.GET)
	@ResponseBody
	public List<ConditionClassDTO> getCondClass()
	{
		return service.getConditionClass();
	}
	
	@RequestMapping(value = "/get-cond-coverage", method = RequestMethod.GET)
	@ResponseBody
	public List<ConditionCoverageDTO> getCondCoverage()
	{
		return service.getConditionCoverage();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-cond-class", method = RequestMethod.POST)
	@ResponseBody
	public List<ConditionClassDTO> modifyCondClass(@RequestParam String action, 
			@RequestBody ConditionClassDTO dto)
	{
		return service.modifyConditionClass(dto, action);
	}
}
