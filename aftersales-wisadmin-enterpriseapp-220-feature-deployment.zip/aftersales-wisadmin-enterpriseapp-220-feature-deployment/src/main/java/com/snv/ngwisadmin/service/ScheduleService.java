package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.BatchScheduleDTO;

public interface ScheduleService {

	public List<BatchScheduleDTO> getBatchSchedule();
	
	public List<BatchScheduleDTO> modifyBatchSchedule(BatchScheduleDTO dto, String action);
}
