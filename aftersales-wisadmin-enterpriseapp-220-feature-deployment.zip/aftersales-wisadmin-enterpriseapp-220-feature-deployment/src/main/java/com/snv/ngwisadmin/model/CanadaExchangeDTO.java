package com.snv.ngwisadmin.model;

public class CanadaExchangeDTO {

	//short so can't apply empty or null check.In db it is non-nullable
	short modelYear;
	//Float so can't apply empty or null check.In db it is non-nullable
	float rate;
	String user;
	String updateTime;
	
	//Used when updating as MY is a table index
	short oldModelYear;

	public short getModelYear() {
		return modelYear;
	}

	public void setModelYear(short modelYear) {
		this.modelYear = modelYear;
	}

	public float getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public short getOldModelYear() {
		return oldModelYear;
	}

	public void setOldModelYear(short oldModelYear) {
		this.oldModelYear = oldModelYear;
	}
}
