package com.snv.ngwisadmin.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.BatchScheduleDTO;
import com.snv.ngwisadmin.util.Utility;

public class BatchScheduleDTOMapper implements RowMapper<BatchScheduleDTO>{

	public BatchScheduleDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		BatchScheduleDTO dto = new BatchScheduleDTO();
		
		dto.setModelYear(rs.getString("I_MOD_YR"));
		dto.setMis(rs.getInt("I_REPORT_MIS"));
		dto.setConditionCutoff(Utility.checkNull(rs.getDate("D_COND_CUTOFF")));
		dto.setSalesCutoff(Utility.checkNull(rs.getDate("D_SALE_CUTOFF")));
		dto.setBatchStart(Utility.checkNull(rs.getDate("D_SCHD_LOAD")));
		dto.setUserAccess(Utility.checkNull(rs.getDate("D_USER_NOTIFY")));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
