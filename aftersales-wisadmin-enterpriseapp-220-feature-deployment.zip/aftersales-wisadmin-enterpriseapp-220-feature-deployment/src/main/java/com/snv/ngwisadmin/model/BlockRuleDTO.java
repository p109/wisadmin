package com.snv.ngwisadmin.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

public class BlockRuleDTO {

	//Int so can't apply empty or null check.In db it is non-nullable
	int id;

	@NotEmpty(message = "Fg can not be empty")
	String fg;
	@NotEmpty(message = "Cg can not be empty")
	String cg;
	@NotEmpty(message = "Cc can not be empty")
	String cc;
	@NotEmpty(message = "Oc can not be empty")
	String oc;
	@NotEmpty(message = "Platform can not be empty")
	String platform;
	@NotEmpty(message = "Family can not be empty")
	String family;
	@NotEmpty(message = "Cond Cls can not be empty")
	String condClass;

	@Min(value = 0, message = "Odometer must not be negative")
	int odomMin;
	@Min(value = 0, message = "Odometer must not be negative")
	int odomMax;
	float laborMin;
	float laborMax;

	short blockExpense;
	short blockCondition;
	
	@NotEmpty(message = "Effective Start Date can not be empty")
	String effectiveStart;
	String effectiveEnd;
	@NotEmpty(message = "Description can not be empty")
	String description;
	String user;
	String updateTime;
	@NotEmpty(message = "Sublet can not be empty")
	String sublet;
	@NotEmpty(message = "Transaction can not be empty")
	String transaction;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFg() {
		return fg;
	}

	public void setFg(String fg) {
		this.fg = fg;
	}

	public String getCg() {
		return cg;
	}

	public void setCg(String cg) {
		this.cg = cg;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getOc() {
		return oc;
	}

	public void setOc(String oc) {
		this.oc = oc;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getCondClass() {
		return condClass;
	}

	public void setCondClass(String condClass) {
		this.condClass = condClass;
	}

	public int getOdomMin() {
		return odomMin;
	}

	public void setOdomMin(int odomMin) {
		this.odomMin = odomMin;
	}

	public int getOdomMax() {
		return odomMax;
	}

	public void setOdomMax(int odomMax) {
		this.odomMax = odomMax;
	}

	public float getLaborMin() {
		return laborMin;
	}

	public void setLaborMin(float laborMin) {
		this.laborMin = laborMin;
	}

	public float getLaborMax() {
		return laborMax;
	}

	public void setLaborMax(float laborMax) {
		this.laborMax = laborMax;
	}

	public short getBlockExpense() {
		return blockExpense;
	}

	public void setBlockExpense(short blockExpense) {
		this.blockExpense = blockExpense;
	}

	public short getBlockCondition() {
		return blockCondition;
	}

	public void setBlockCondition(short blockCondition) {
		this.blockCondition = blockCondition;
	}

	public String getEffectiveStart() {
		return effectiveStart;
	}

	public void setEffectiveStart(String effectiveStart) {
		this.effectiveStart = effectiveStart;
	}

	public String getEffectiveEnd() {
		return effectiveEnd;
	}

	public void setEffectiveEnd(String effectiveEnd) {
		this.effectiveEnd = effectiveEnd;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getSublet() {
		return sublet;
	}

	public void setSublet(String sublet) {
		this.sublet = sublet;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

}
