package com.snv.ngwisadmin.model.broadcast;

import java.util.HashMap;
import java.util.Map;

public class BroadcastMessageMap {
	
	Map<String, String> broadcastTypeMap = new HashMap<>();
	Map<String, String> reportTypeMap = new HashMap<>();
	Map<String, String> messageTypeMap = new HashMap<>();
	
	public Map<String, String> getBroadcastTypeMap() {
		return broadcastTypeMap;
	}
	public void setBroadcastTypeMap(Map<String, String> broadcastTypeMap) {
		this.broadcastTypeMap = broadcastTypeMap;
	}
	public Map<String, String> getReportTypeMap() {
		return reportTypeMap;
	}
	public void setReportTypeMap(Map<String, String> reportTypeMap) {
		this.reportTypeMap = reportTypeMap;
	}
	public Map<String, String> getMessageTypeMap() {
		return messageTypeMap;
	}
	public void setMessageTypeMap(Map<String, String> messageTypeMap) {
		this.messageTypeMap = messageTypeMap;
	}
	
	

}
