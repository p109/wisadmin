package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.BlockRuleDTO;
import com.snv.ngwisadmin.service.BlockService;

@Controller
public class BlockController {

	@Autowired
	BlockService service;
	
	@RequestMapping(value = "/get-block-rules", method = RequestMethod.GET)
	@ResponseBody
	public List<BlockRuleDTO> getBlockRules()
	{
		return service.getBlockRules();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/insert-block-rule", method = RequestMethod.POST)
	@ResponseBody
	public List<BlockRuleDTO> insertBlockRule(@RequestBody BlockRuleDTO dto)
	{
		return service.insertBlockRule(dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-block-rule", method = RequestMethod.POST)
	@ResponseBody
	public List<BlockRuleDTO> updateBlockRule(@RequestBody List<BlockRuleDTO> dtoList)
	{
		return service.updateBlockRule(dtoList);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/delete-block-rule", method = RequestMethod.POST)
	@ResponseBody
	public List<BlockRuleDTO> deleteBlockRule(@RequestBody BlockRuleDTO dto)
	{
		return service.deleteBlockRule(dto);
	}
	
}
