package com.snv.ngwisadmin.model;

public class QualityManagerDTO {

	String qualityManager;
	String qualityManagerDescription;
	String commodityDirector;
	String user;
	String updateTime;
	String oldManager;

	public String getQualityManager() {
		return qualityManager;
	}

	public void setQualityManager(String qualityManager) {
		this.qualityManager = qualityManager;
	}

	public String getQualityManagerDescription() {
		return qualityManagerDescription;
	}

	public void setQualityManagerDescription(String qualityManagerDescription) {
		this.qualityManagerDescription = qualityManagerDescription;
	}

	public String getCommodityDirector() {
		return commodityDirector;
	}

	public void setCommodityDirector(String commodityDirector) {
		this.commodityDirector = commodityDirector;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getOldManager() {
		return oldManager;
	}

	public void setOldManager(String oldManager) {
		this.oldManager = oldManager;
	}

}
