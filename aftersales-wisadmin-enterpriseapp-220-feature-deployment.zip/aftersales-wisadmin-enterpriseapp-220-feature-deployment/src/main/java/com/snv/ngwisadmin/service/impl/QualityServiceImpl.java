package com.snv.ngwisadmin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.CommodityDirectorDTO;
import com.snv.ngwisadmin.model.QualityManagerDTO;
import com.snv.ngwisadmin.repository.quality.QualityDAO;
import com.snv.ngwisadmin.service.QualityService;

@Service
public class QualityServiceImpl implements QualityService {

	@Autowired
	QualityDAO dao;

	@Override
	public List<CommodityDirectorDTO> getCommodityDirector() {
		return dao.getCommodityDirector();
	}

	@Override
	public List<CommodityDirectorDTO> modifyCommodityDirector(CommodityDirectorDTO dto, String action) {
		if ("I".equals(action)) {
			dao.insertCommodityDirector(dto);
		} else if ("U".equals(action)) {
			dao.updateCommodityDirector(dto);
		} else if ("D".equals(action)) {
			dao.deleteCommodityDirector(dto);
		}
		return dao.getCommodityDirector();

	}

	@Override
	public List<QualityManagerDTO> getQualityManager() {
		return dao.getQualityManager();
	}

	@Override
	public List<QualityManagerDTO> modifyQualityManager(QualityManagerDTO dto, String action) {
		if ("I".equals(action)) {
			dao.insertQualityManager(dto);
		} else if ("U".equals(action)) {
			dao.updateQualityManager(dto);
		} else if ("D".equals(action)) {
			dao.deleteQualityManager(dto);
		}
		return dao.getQualityManager();
	}

}
