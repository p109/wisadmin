package com.snv.ngwisadmin.repository.workflow;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.workflow.WorkflowApprovalDTO;

public class WorkflowApprovalDTOMapper implements RowMapper<WorkflowApprovalDTO> {

	public WorkflowApprovalDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		WorkflowApprovalDTO dto = new WorkflowApprovalDTO();
		dto.setApprover(rs.getString("APPROVER"));
		dto.setName(rs.getString("STEP_NAME"));
		dto.setRequestId(rs.getInt("REQUEST_ID"));
		dto.setActionTime(rs.getTimestamp("T_STMP_ACTION").toString());
		dto.setStatus(rs.getString("STEP_STATUS"));
		dto.setStep(rs.getInt("SEQ_STEP"));
		return dto;
	}
}
