package com.snv.ngwisadmin.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class BatchScheduleDTO {

	@NotEmpty(message = "Model Year can not be empty")
	String modelYear;

	@Min(value = 1, message = "MIS should not be less than 1")
	@Max(value = 12, message = "MIS should not be greater than 12")
	int mis;

	@NotEmpty(message = "Condition Cutoff Date can not be empty")
	String conditionCutoff;
	@NotEmpty(message = "Sales Cutoff Date can not be empty")
	String salesCutoff;
	@NotEmpty(message = "Batch Start Date can not be empty")
	String batchStart;
	@NotEmpty(message = "User Access Date can not be empty")
	String userAccess;
	String user;
	String updateTime;

	String oldModelYear;
	int oldMis;

	boolean isError;
	String errorMessage;
	String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getModelYear() {
		return modelYear;
	}

	public boolean isError() {
		return isError;
	}

	public void setError(boolean isError) {
		this.isError = isError;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}

	public int getMis() {
		return mis;
	}

	public void setMis(int mis) {
		this.mis = mis;
	}

	public String getConditionCutoff() {
		return conditionCutoff;
	}

	public void setConditionCutoff(String conditionCutoff) {
		this.conditionCutoff = conditionCutoff;
	}

	public String getSalesCutoff() {
		return salesCutoff;
	}

	public void setSalesCutoff(String salesCutoff) {
		this.salesCutoff = salesCutoff;
	}

	public String getBatchStart() {
		return batchStart;
	}

	public void setBatchStart(String batchStart) {
		this.batchStart = batchStart;
	}

	public String getUserAccess() {
		return userAccess;
	}

	public void setUserAccess(String userAccess) {
		this.userAccess = userAccess;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getOldModelYear() {
		return oldModelYear;
	}

	public void setOldModelYear(String oldModelYear) {
		this.oldModelYear = oldModelYear;
	}

	public int getOldMis() {
		return oldMis;
	}

	public void setOldMis(int oldMis) {
		this.oldMis = oldMis;
	}

	public void printDates() {
		System.out.println("cond: " + conditionCutoff);
		System.out.println("sale: " + salesCutoff);
		return;
	}
}
