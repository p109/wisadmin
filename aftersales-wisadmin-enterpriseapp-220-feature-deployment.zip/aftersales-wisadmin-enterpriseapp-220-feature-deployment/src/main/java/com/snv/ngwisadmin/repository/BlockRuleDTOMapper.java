package com.snv.ngwisadmin.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.BlockRuleDTO;
import com.snv.ngwisadmin.util.Utility;

public class BlockRuleDTOMapper implements RowMapper<BlockRuleDTO> {

	@Override
	public BlockRuleDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		BlockRuleDTO dto = new BlockRuleDTO();
		
		dto.setId(rs.getInt("I_BLK_ID"));
		dto.setFg(rs.getString("C_FG"));
		dto.setCg(rs.getString("C_CG"));
		dto.setCc(rs.getString("C_CC"));
		dto.setOc(rs.getString("C_OC"));
		dto.setPlatform(rs.getString("C_PLATFORM"));
		dto.setFamily(rs.getString("C_FAMILY_CODE"));
		dto.setCondClass(rs.getString("C_COND_CLS"));
		dto.setOdomMin(rs.getInt("Q_ODOM_MIN"));
		if (rs.wasNull())
			dto.setOdomMin(-1);
		dto.setOdomMax(rs.getInt("Q_ODOM_MAX"));
		if (rs.wasNull())
			dto.setOdomMax(-1);
		dto.setLaborMin(rs.getFloat("Q_EXP_LABR_MIN"));
		if (rs.wasNull())
			dto.setLaborMin(-1);
		dto.setLaborMax(rs.getFloat("Q_EXP_LABR_MAX"));
		if (rs.wasNull())
			dto.setLaborMax(-1);
		
		dto.setBlockCondition(rs.getShort("L_BLOCK_COND"));
		dto.setBlockExpense(rs.getShort("L_BLOCK_EXP"));
		dto.setEffectiveStart(Utility.checkNull(rs.getDate("D_EFF_STRT")));
		dto.setEffectiveEnd(Utility.checkNull(rs.getDate("D_EFF_END")));
		dto.setSublet(rs.getString("L_SUBLET"));
		dto.setTransaction(rs.getString("C_TRAN"));
		dto.setDescription(rs.getString("X_DESC"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
	
	
}
