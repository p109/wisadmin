package com.snv.ngwisadmin.service.impl;

import java.util.List;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.componenttype.CTClassDTO;
import com.snv.ngwisadmin.model.componenttype.CTDescDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleMap;
import com.snv.ngwisadmin.repository.componenttype.CTMaintenanceDAO;
import com.snv.ngwisadmin.service.CTService;

@Service
public class CTServiceImpl implements CTService {

	@Autowired
	CTMaintenanceDAO dao;
	
	@Override
	public List<CTClassDTO> getCTClassDesc() {
		return dao.getCTClassDesc();
	}
	
	@Override
	public List<CTDescDTO> getCTDesc() {
		return dao.getCTDesc();
	}
	
	@Override
	public CTRuleMap getCTRule() {
		return dao.getCTRule();
	}
	
	@Override
	public List<CTDescDTO> insertCTDesc(CTDescDTO dto) {
		dao.insertCTDesc(dto);
		return dao.getCTDesc();
	}
	
	@Override
	public List<CTDescDTO> updateCTDesc(List<CTDescDTO> dtoList) {
		dao.updateCTDesc(dtoList);
		return dao.getCTDesc();
	}
	
	@Override
	public List<CTDescDTO> deleteCTDesc(CTDescDTO dto) {
		dao.deleteCTDesc(dto);
		return dao.getCTDesc();
	}
	
	@Override
	public List<CTClassDTO> insertCTClassDesc(CTClassDTO dto) {
		dao.insertCTClassDesc(dto);
		return dao.getCTClassDesc();
	}
	
	@Override
	public List<CTClassDTO> updateCTClassDesc(List<CTClassDTO> dtoList) {
		dao.updateCTClassDesc(dtoList);
		return dao.getCTClassDesc();
	}
	
	@Override
	public List<CTClassDTO> deleteCTClassDesc(CTClassDTO dto) {
		dao.deleteCTClassDesc(dto);
		return dao.getCTClassDesc();
	}
	
	@Override
	public CTRuleMap insertCTRule(CTRuleDTO dto) {
		dao.insertCTRule(dto);
		return dao.getCTRule();
	}
	
	@Override
	public CTRuleMap updateCTRule(List<CTRuleDTO> dtoList) {
		dao.updateCTRule(dtoList);
		return dao.getCTRule();
	}
	
	@Override
	public CTRuleMap deleteCTRule(CTRuleDTO dto) {
		dao.deleteCTRule(dto);
		return dao.getCTRule();
	}
	
	public void promoteCTRule() {
		dao.promoteCTRule();
		return;
	}

}
