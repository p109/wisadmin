package com.snv.ngwisadmin.repository;

import java.util.List;

import com.snv.ngwisadmin.model.BatchScheduleDTO;

public interface BatchScheduleDAO {

	public List<BatchScheduleDTO> getBatchSchedule();
	
	public boolean insertBatchSchedule(BatchScheduleDTO dto);
	
	public boolean updateBatchSchedule(BatchScheduleDTO dto);
	
	public boolean deleteBatchSchedule(BatchScheduleDTO dto);
}
