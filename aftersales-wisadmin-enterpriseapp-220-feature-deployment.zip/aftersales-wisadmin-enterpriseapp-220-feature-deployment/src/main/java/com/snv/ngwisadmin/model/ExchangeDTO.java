package com.snv.ngwisadmin.model;

public class ExchangeDTO {

	String curr;
	String effectiveDate;
	float rate;
	String user;
	String updateTime;
	String oldCurr;
	String oldEffectiveDate;
	
	public String getOldCurr() {
		return oldCurr;
	}
	public void setOldCurr(String oldCurr) {
		this.oldCurr = oldCurr;
	}
	public String getOldEffectiveDate() {
		return oldEffectiveDate;
	}
	public void setOldEffectiveDate(String oldEffectiveDate) {
		this.oldEffectiveDate = oldEffectiveDate;
	}
	public String getCurr() {
		return curr;
	}
	public void setCurr(String curr) {
		this.curr = curr;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	
	
}
