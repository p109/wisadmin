package com.snv.ngwisadmin.repository.componenttype;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.componenttype.CTRuleDTO;
import com.snv.ngwisadmin.util.Utility;

public class CTRuleDTOMapper implements RowMapper<CTRuleDTO> {

	@Override
	public CTRuleDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		CTRuleDTO dto = new CTRuleDTO();
		dto.setCt(rs.getString("C_CT"));
		dto.setCtClass(rs.getString("C_CT_CLASS"));
		dto.setId(rs.getInt("I_CT_RULE_ID"));
		dto.setEnginePlant(rs.getString("C_ENG_PLANT"));
		dto.setTransPlant(rs.getString("C_TRANS_PLANT"));
		dto.setBuildStart(Utility.checkNull(rs.getDate("D_BLD_BEFR")));
		dto.setBuildEnd(Utility.checkNull(rs.getDate("D_BLD_AFTR")));
		dto.setEffectiveStart(Utility.checkNull(rs.getDate("D_EFF_STRT")));
		dto.setEffectiveEnd(Utility.checkNull(rs.getDate("D_EFF_END")));
		dto.setScodePattern(rs.getString("C_SCODE_PAT").trim());
		dto.setProductLine(rs.getString("C_PROD_LINE"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		dto.setUser(rs.getString("I_LOGON"));
		//dto.setDescription(rs.getString("X_RULE_DESCRIPTION"));
		
		return dto;
	} 

}
