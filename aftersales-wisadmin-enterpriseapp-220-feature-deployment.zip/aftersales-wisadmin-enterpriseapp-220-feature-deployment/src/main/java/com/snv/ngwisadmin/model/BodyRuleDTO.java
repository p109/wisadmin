package com.snv.ngwisadmin.model;

import java.sql.Date;
import java.sql.Timestamp;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class BodyRuleDTO {

	@NotEmpty(message = "Model Year can not be empty")
	String modelYear;
	@NotEmpty(message = "Platform can not be empty")
	String platform;
	@NotEmpty(message = "Product line can not be empty")
	String productLine;
	@NotEmpty(message = "Family can not be empty")
	String family;
	@NotEmpty(message = "Line can not be empty")
	String line;
	@NotEmpty(message = "Series can not be empty")
	String series;
	@NotEmpty(message = "Body Style can not be empty")
	String bodyStyle;
	@NotEmpty(message = "Assembly Plant can not be empty")
	String assemblyPlant;
	@NotEmpty(message = "Block can not be empty")
	String block;
	@NotNull(message = "Sales Codes can not be null")
	String salesCodes;
	String user;
	String updateTime;
	@NotEmpty(message = "Corp Loc can not be empty")
	String corpLoc;
	// Int so can't apply empty or null check.In db it is non-nullable
	int id;
	@NotEmpty(message = "Effective Start can not be empty")
	String effectiveStart;
	String effectiveEnd;

	String wisBodyStyle;
	String classCode;
	Date effectiveStartDate;
	Date effectiveEndDate;
	Timestamp updateTimestamp;

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getBodyStyle() {
		return bodyStyle;
	}

	public void setBodyStyle(String bodyStyle) {
		this.bodyStyle = bodyStyle;
	}

	public String getAssemblyPlant() {
		return assemblyPlant;
	}

	public void setAssemblyPlant(String assemblyPlant) {
		this.assemblyPlant = assemblyPlant;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getSalesCodes() {
		return salesCodes;
	}

	public void setSalesCodes(String salesCodes) {
		this.salesCodes = salesCodes;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getCorpLoc() {
		return corpLoc;
	}

	public void setCorpLoc(String corpLoc) {
		this.corpLoc = corpLoc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEffectiveStart() {
		return effectiveStart;
	}

	public void setEffectiveStart(String effectiveStart) {
		this.effectiveStart = effectiveStart;
	}

	public String getEffectiveEnd() {
		return effectiveEnd;
	}

	public String getWisBodyStyle() {
		return wisBodyStyle;
	}

	public void setWisBodyStyle(String wisBodyStyle) {
		this.wisBodyStyle = wisBodyStyle;
	}

	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public void setEffectiveEnd(String effectiveEnd) {
		this.effectiveEnd = effectiveEnd;
	}

	public Date getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(Date effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public Date getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(Date effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

}
