package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.PlantCodeDTO;
import com.snv.ngwisadmin.model.PlantDTO;
import com.snv.ngwisadmin.service.PlantService;

@Controller
public class PlantController {

	@Autowired
	PlantService service;
	
	@RequestMapping(value = "/get-plant-desc", method = RequestMethod.GET)
	@ResponseBody
	public List<PlantDTO> getPlantDesc(@RequestParam String type)
	{
		return service.getPlantDesc(type);
	}
	
	@RequestMapping(value = "/get-plant-codes", method = RequestMethod.GET)
	@ResponseBody
	public List<PlantCodeDTO> getPlantCodes(@RequestParam String type)
	{
		return service.getPlantCodes(type);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/insert-plant-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<PlantDTO> insertPlantDesc(@RequestBody PlantDTO dto, @RequestParam String type)
	{
		return service.insertPlantDesc(type, dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-plant-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<PlantDTO> updatePlantDesc(@RequestBody List<PlantDTO> dtoList, 
			@RequestParam String type)
	{
		return service.updatePlantDesc(type, dtoList);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/delete-plant-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<PlantDTO> deletePlantDesc(@RequestBody PlantDTO dto, @RequestParam String type)
	{
		return service.deletePlantDesc(type, dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/insert-plant-code", method = RequestMethod.POST)
	@ResponseBody
	public List<PlantCodeDTO> insertPlantCode(@RequestBody PlantCodeDTO dto, 
			@RequestParam String type)
	{
		return service.insertPlantCode(type, dto);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-plant-code", method = RequestMethod.POST)
	@ResponseBody
	public List<PlantCodeDTO> updatePlantCode(@RequestBody List<PlantCodeDTO> dtoList,
			@RequestParam String type)
	{
		return service.updatePlantCode(type, dtoList);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/delete-plant-code", method = RequestMethod.POST)
	@ResponseBody
	public List<PlantCodeDTO> deletePlantCode(@RequestBody PlantCodeDTO dto,
			@RequestParam String type)
	{
		return service.deletePlantCode(type, dto);
	}
}
