package com.snv.ngwisadmin.repository.workflow;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.workflow.WorkflowStepDTO;

public class WorkflowStepDTOMapper implements RowMapper<WorkflowStepDTO> {

	public WorkflowStepDTO mapRow(ResultSet rs, int index) throws SQLException {
		WorkflowStepDTO dto = new WorkflowStepDTO();
		dto.setStep(rs.getInt("SEQ_STEP"));
		dto.setGroup(rs.getString("N_GROUP"));
		dto.setName(rs.getString("STEP_NAME"));
		return dto;
	}
}
