package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.BodyRuleDTO;
import com.snv.ngwisadmin.model.LaunchRuleDTO;
import com.snv.ngwisadmin.model.PlatformDescDTO;
import com.snv.ngwisadmin.model.PriceClassDescDTO;
import com.snv.ngwisadmin.model.ProductLineDTO;

public interface BodyService {

	public List<BodyRuleDTO> getBodyRules();
	
	public List<LaunchRuleDTO> getLaunchRules();
	
	public List<PlatformDescDTO> getPlatformDesc();
	
	public List<ProductLineDTO> getProductLine();
	
	public List<BodyRuleDTO> modifyBodyRules(BodyRuleDTO dto, String action);
	
	public List<LaunchRuleDTO> modifyLaunchRules(LaunchRuleDTO dto, String action);
	
	public List<BodyRuleDTO> copyBodyRules(String copyFrom, String copyTo);
	
	public List<ProductLineDTO> modifyProductLine(ProductLineDTO dto, String action);
	
	public List<PlatformDescDTO> modifyPlatformDesc(PlatformDescDTO dto, String action);

	public List<PriceClassDescDTO> getPriceClassDesc();

	public List<PriceClassDescDTO> modifyPriceClassDesc(PriceClassDescDTO dto, String action);
}
