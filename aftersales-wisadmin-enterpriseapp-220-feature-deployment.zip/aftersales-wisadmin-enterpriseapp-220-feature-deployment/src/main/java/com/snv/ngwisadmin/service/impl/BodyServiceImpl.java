package com.snv.ngwisadmin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.BodyRuleDTO;
import com.snv.ngwisadmin.model.LaunchRuleDTO;
import com.snv.ngwisadmin.model.PlatformDescDTO;
import com.snv.ngwisadmin.model.PriceClassDescDTO;
import com.snv.ngwisadmin.model.ProductLineDTO;
import com.snv.ngwisadmin.repository.body.BodyMaintenanceDAO;
import com.snv.ngwisadmin.service.BodyService;
import com.snv.ngwisadmin.util.Constants;

@Service
public class BodyServiceImpl implements BodyService {

	@Autowired
	BodyMaintenanceDAO dao;
	
	public List<BodyRuleDTO> getBodyRules()
	{
		return dao.getBodyRules();
	}
	
	public List<LaunchRuleDTO> getLaunchRules()
	{
		return dao.getLaunchRules();
	}
	
	public List<PlatformDescDTO> getPlatformDesc()
	{
		return dao.getPlatformDesc();
	}
	
	public List<ProductLineDTO> getProductLine()
	{
		return dao.getProductLine();
	}
	
	@Override
	public List<PriceClassDescDTO> getPriceClassDesc() {
		return dao.getPriceClassDesc();
	}
	
	public List<BodyRuleDTO> modifyBodyRules(BodyRuleDTO dto, String action)
	{
		if ("I".equals(action))
		{
			dao.insertBodyRule(dto);
		}
		else
		if ("U".equals(action))
		{
			dao.updateBodyRule(dto);
		}
		else
		if ("D".equals(action))
		{
			dao.deleteBodyRule(dto);
		}
		
		return dao.getBodyRules();
	}
	
	public List<LaunchRuleDTO> modifyLaunchRules(LaunchRuleDTO dto, String action)
	{
		if ("I".equals(action))
		{
			dao.insertLaunchRule(dto);
		}
		else
		if ("U".equals(action))
		{
			dao.updateLaunchRule(dto);
		}
		else
		if ("D".equals(action))
		{
			dao.deleteLaunchRule(dto);
		}
		
		return dao.getLaunchRules();
	}
	
	public List<BodyRuleDTO> copyBodyRules(String copyFrom, String copyTo)
	{
		dao.copyModelYears(copyFrom, copyTo);
		return dao.getBodyRules();
	}
	
	public List<ProductLineDTO> modifyProductLine(ProductLineDTO dto, String action)
	{
		if (Constants.INSERT.equals(action))
		{
			dao.insertProductLine(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updateProductLine(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteProductLine(dto);
		}
		return dao.getProductLine();
	}
	
	public List<PlatformDescDTO> modifyPlatformDesc(PlatformDescDTO dto, String action)
	{
		if (Constants.INSERT.equals(action))
		{
			dao.insertPlatformDesc(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updatePlatformDesc(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deletePlatformDesc(dto);
		}
		return dao.getPlatformDesc();
	}

	@Override
	public List<PriceClassDescDTO> modifyPriceClassDesc(PriceClassDescDTO dto, String action) {
		if (Constants.INSERT.equals(action))
		{
			dao.insertPriceClassDesc(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updatePriceClassDesc(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deletePriceClassDesc(dto);
		}
		return dao.getPriceClassDesc();
	
	}

	

}
