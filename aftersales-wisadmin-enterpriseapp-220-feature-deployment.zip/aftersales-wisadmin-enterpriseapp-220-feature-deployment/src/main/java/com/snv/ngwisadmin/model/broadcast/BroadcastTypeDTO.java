package com.snv.ngwisadmin.model.broadcast;

public class BroadcastTypeDTO {

	String broadcastType;
	String oldBroadcastType;
	String typeDescription;
	String user;
	String updateTime;
	
	public BroadcastTypeDTO() {
	}
	
	public BroadcastTypeDTO(String broadcastType, String typeDescription) {
		this.broadcastType=broadcastType;
		this.typeDescription=typeDescription;
	}
	public String getBroadcastType() {
		return broadcastType;
	}
	public void setBroadcastType(String broadcastType) {
		this.broadcastType = broadcastType;
	}
	public String getOldBroadcastType() {
		return oldBroadcastType;
	}
	public void setOldBroadcastType(String oldBroadcastType) {
		this.oldBroadcastType = oldBroadcastType;
	}
	public String getTypeDescription() {
		return typeDescription;
	}
	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
}
