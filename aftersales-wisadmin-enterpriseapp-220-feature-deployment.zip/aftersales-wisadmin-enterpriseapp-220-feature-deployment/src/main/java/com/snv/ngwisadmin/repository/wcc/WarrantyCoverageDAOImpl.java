package com.snv.ngwisadmin.repository.wcc;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.wcc.ConditionClassDTO;
import com.snv.ngwisadmin.model.wcc.ConditionCoverageDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeClassDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeRuleDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class WarrantyCoverageDAOImpl implements WarrantyCoverageDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	DataSource ds;
	
	@Autowired
	AuthenticationFacade auth;
	
	@Override
	public List<CoverageCodeDTO> getCoverageDesc() {
		String sql = "select * from wis.wcc_desc";
		List<CoverageCodeDTO> dtoList = jdbcTemplate.query(sql, new CoverageCodeDTOMapper());
		return dtoList;
	}
	
	public List<CoverageCodeRuleDTO> getCoverageRule() {
		String sql = "select * from wis.wcc_rule";
		List<CoverageCodeRuleDTO> dtoList = jdbcTemplate.query(sql, new CoverageCodeRuleDTOMapper());
		return dtoList;
	}
	
	public List<CoverageCodeClassDTO> getCoverageClass() {
		String sql = "select * from wis.wcc_ccls";
		List<CoverageCodeClassDTO> dtoList = jdbcTemplate.query(sql, new CoverageCodeClassDTOMapper());
		return dtoList;
	}
	
	public List<ConditionClassDTO> getConditionClass() {
		String sql = "select * from wis.cond_class_desc";
		List<ConditionClassDTO> dtoList = jdbcTemplate.query(sql, new ConditionClassDTOMapper());
		
		return dtoList;
	}
	
	public List<ConditionCoverageDTO> getConditionCoverage() {
		String sql = "select r.c_wcc, w.x_wcc, d.c_cond_cls, d.x_cond_cls " + 
				"from wis.cond_class_desc d, wis.wcc_rule r, wis.wcc_ccls c, wis.wcc_desc w " + 
				"where r.i_wcc_rule_id = c.i_wcc_rule_id and " +
				"trim(c.c_cond_cls) = trim(d.c_cond_cls) " +
				"and trim(r.c_wcc) = trim(w.c_wcc) order by r.c_wcc";
		List<ConditionCoverageDTO> dtoList = jdbcTemplate.query(sql, new ConditionCoverageDTOMapper());
		return dtoList;
	}

	@Override
	public boolean insertCoverageDesc(CoverageCodeDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("wcc_desc");
		Map<String, Object> params = new HashMap<>();
		
		params.put("C_WCC", dto.getWcc());
		params.put("X_WCC", dto.getWccDesc());
		params.put("I_LOGON", auth.getLoggedInUser().getUserId());
		params.put("T_STMP_UPD", new Timestamp(System.currentTimeMillis()));
		
		jdbcInsert.execute(params);
		return true;
	}
	
	public boolean insertCoverageRule(CoverageCodeRuleDTO dto) {
		int maxId = Utility.getMaxId("WCC", jdbcTemplate);
		maxId++;
		
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("wcc_rule");
		Map<String, Object> params = new HashMap<>();
		
		params.put("i_wcc_rule_id", maxId);
		params.put("c_wcc", dto.getWcc());
		params.put("d_eff_strt", Utility.toDate(dto.getEffectiveStart()));
		params.put("d_eff_end", Utility.toDate(dto.getEffectiveEnd()));
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		params.put("q_mnth_lim", dto.getMonthLimit());
		params.put("q_mile_lim", dto.getMileLimit());
		
		jdbcInsert.execute(params);
		return true;
	}
	
	public boolean insertCoverageClass(CoverageCodeClassDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("wcc_ccls");
		Map<String, Object> params = new HashMap<>();
		
		params.put("i_wcc_rule_id", dto.getId());
		params.put("c_cond_cls", dto.getConditionClass());
		params.put("c_tran", dto.getTransaction());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		
		jdbcInsert.execute(params);
		return true;
	}
	
	public boolean insertConditionClass(ConditionClassDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("cond_class_desc");
		Map<String, Object> params = new HashMap<>();
		
		params.put("c_cond_cls", dto.getCode());
		params.put("x_cond_cls", dto.getDesc());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		
		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean updateCoverageDesc(CoverageCodeDTO dto) {
		String sql = "update wis.wcc_desc set c_wcc = :wcc, x_wcc = :desc, i_logon = :user,"
				+ "t_stmp_upd = current_timestamp where c_wcc = :oldWcc";
		
		Map<String, Object> params = new HashMap<>();
		params.put("wcc", dto.getWcc());
		params.put("desc",dto.getWccDesc());
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldWcc", dto.getOldWcc());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean updateCoverageRule(CoverageCodeRuleDTO dto) {
		String sql = "update wis.wcc_rule set c_wcc = :wcc, d_eff_strt = :effStart, "
				+ "d_eff_end = :effEnd, i_logon = :user, t_stmp_upd = current_timestamp, "
				+ "q_mnth_lim = :monthLimit, q_mile_lim = :mileLimit where i_wcc_rule_id = :id";
		
		Map<String, Object> params = new HashMap<>();
		params.put("wcc", dto.getWcc());
		params.put("effStart", Utility.toDate(dto.getEffectiveStart()));
		params.put("effEnd", Utility.toDate(dto.getEffectiveEnd()));
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("monthLimit", dto.getMonthLimit());
		params.put("mileLimit", dto.getMileLimit());
		params.put("id", dto.getId());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean updateConditionClass(ConditionClassDTO dto) {
		String sql = "update wis.cond_class_desc set c_cond_cls = :class, x_cond_cls = :desc,"
				+ "i_logon = :user, t_stmp_upd = current_timestamp where trim(c_cond_cls) = :oldClass";
		
		Map<String, Object> params = new HashMap<>();
		params.put("class", dto.getCode());
		params.put("desc", dto.getDesc());
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldClass", dto.getOldCode());
		
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteCoverageDesc(CoverageCodeDTO dto) {
		String sql = "delete from wis.wcc_desc where c_wcc = :wcc";
		Map<String, Object> params = new HashMap<>();
		params.put("wcc", dto.getWcc());
		jdbcTemplate.update(sql, params);
		return true;
	}

	public boolean deleteCoverageRule(CoverageCodeRuleDTO dto) {
		String sql = "delete from wis.wcc_rule where i_wcc_rule_id = :id";
		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean deleteCoverageClass(CoverageCodeClassDTO dto) {
		String sql = "delete from wis.wcc_ccls where i_wcc_rule_id = :id and c_cond_cls = :cond "
				+ "and c_tran = :tran";
		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		params.put("cond", dto.getConditionClass());
		params.put("tran", dto.getTransaction());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean deleteConditionClass(ConditionClassDTO dto) {
		String sql = "delete from wis.cond_class_desc where trim(c_cond_cls) = :cond";
		Map<String, Object> params = new HashMap<>();
		params.put("cond", dto.getCode());
		jdbcTemplate.update(sql, params);
		return true;
	}
	
}
