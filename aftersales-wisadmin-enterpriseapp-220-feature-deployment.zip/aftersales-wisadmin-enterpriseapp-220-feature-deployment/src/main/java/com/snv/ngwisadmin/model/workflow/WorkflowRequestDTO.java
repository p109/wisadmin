package com.snv.ngwisadmin.model.workflow;

import javax.validation.constraints.NotEmpty;

public class WorkflowRequestDTO {
	String requestor;
	String requestTime;
	String completeTime;
	String status;
	@NotEmpty(message = "Request description can not be empty")
	String description;
	// Int so can't apply empty or null check.In db it is non-nullable
	int id;
	int step;

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}

	public String getCompleteTime() {
		return completeTime;
	}

	public void setCompleteTime(String completeTime) {
		this.completeTime = completeTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStep() {
		return step;
	}

	public void setStep(int step) {
		this.step = step;
	}

}
