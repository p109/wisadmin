package com.snv.ngwisadmin.security;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Component;

@Component
public class UserDetailsManager {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;
	
	@Bean("userManagerDetails")
    public UserDetailsService userDetailsService() {  
        System.out.println("Creating user details service");
		InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        System.out.println("In system memory");
        System.out.println(manager);
        String sql = "select g.role, a.i_logon from aqip.usr_grp g, aqip.usr_grp_asgn a " +
        		"where a.i_system = g.i_system and a.n_group = g.n_group and g.role is not null "
        		+ "order by a.i_logon";
        SqlRowSet rs = jdbcTemplate.queryForRowSet(sql, new HashMap<String, Object>());
        System.out.println("Jdbc queried");
        String userId = "";
        List<GrantedAuthority> authorityList = new ArrayList<>();
        try {
	        while (rs.next())
	        {
	        	if (rs.getString(2).equals(userId))
	        	{
	        		authorityList.add(new SimpleGrantedAuthority(rs.getString(1)));
	        	}
	        	else
	        	{
	        		//First user
	        		if (userId.equals(""))
	        		{
	        			userId = rs.getString(2);
	        			System.out.println("First user - " + userId);
	        		}
	        		else
	        		{
	        			//Add user to manager and start new user
	        			System.out.println("Creating user - " + userId);
	        			System.out.println("Authority list: " + authorityList.toString());
	        			manager.createUser(User.withUsername(userId).password("").authorities(authorityList).build());
	        			authorityList.clear();
	        			userId = rs.getString(2);
	        			System.out.println("New user - " + userId);
	        			authorityList.add(new SimpleGrantedAuthority(rs.getString(1)));
	        		}
	        	}
	        }
	        
	        //Add last user
	        if (!userId.equals(""))
	        {
	        	manager.createUser(User.withUsername(userId).password("").authorities(authorityList).build());
	        }
        } catch (Exception e)
        {
        	System.out.println("Caught exception: " + e.getMessage());
        }
        System.out.println("Out of list");
        return manager;  
    }
}
