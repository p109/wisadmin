package com.snv.ngwisadmin.repository.body;

import java.util.List;

import com.snv.ngwisadmin.model.BodyRuleDTO;
import com.snv.ngwisadmin.model.LaunchRuleDTO;
import com.snv.ngwisadmin.model.PlatformDescDTO;
import com.snv.ngwisadmin.model.PriceClassDescDTO;
import com.snv.ngwisadmin.model.ProductLineDTO;

public interface BodyMaintenanceDAO {

	public List<BodyRuleDTO> getBodyRules();
	
	public List<LaunchRuleDTO> getLaunchRules();
	
	public List<PlatformDescDTO> getPlatformDesc();
	
	public List<ProductLineDTO> getProductLine();
	
	public boolean insertBodyRule(BodyRuleDTO dto);
	
	public boolean updateBodyRule(BodyRuleDTO dto);
	
	public boolean deleteBodyRule(BodyRuleDTO dto);
	
	public boolean insertLaunchRule(LaunchRuleDTO dto);
	
	public boolean updateLaunchRule(LaunchRuleDTO dto);
	
	public boolean deleteLaunchRule(LaunchRuleDTO dto);
	
	public boolean copyModelYears(String copyFrom, String copyTo);
	
	public boolean insertProductLine(ProductLineDTO dto);
	
	public boolean updateProductLine(ProductLineDTO dto);
	
	public boolean deleteProductLine(ProductLineDTO dto);
	
	public boolean insertPlatformDesc(PlatformDescDTO dto);
	
	public boolean updatePlatformDesc(PlatformDescDTO dto);
	
	public boolean deletePlatformDesc(PlatformDescDTO dto);

	public List<PriceClassDescDTO> getPriceClassDesc();

	public boolean insertPriceClassDesc(PriceClassDescDTO dto);

	public boolean updatePriceClassDesc(PriceClassDescDTO dto);

	public boolean deletePriceClassDesc(PriceClassDescDTO dto);
}
