package com.snv.ngwisadmin.repository.workflow;

import java.util.List;

import com.snv.ngwisadmin.model.workflow.WorkflowInformation;
import com.snv.ngwisadmin.model.workflow.WorkflowRequestDTO;

public interface WorkflowDAO {

	public WorkflowInformation getWorkflowRequests();
	
	//Returns the id of the created request
	public int insertWorkflowRequest(WorkflowRequestDTO dto);
	
	//Returns the current step number, -1 if completed
	public int approveWorkflowRequest(WorkflowRequestDTO dto);
	
	public boolean rejectWorkflowRequest(WorkflowRequestDTO dto);
	
	public WorkflowRequestDTO getIndividualRequest(WorkflowRequestDTO dto);

	public List<String> getApproverList(int requestId);
	
	public List<String> getNotificationList();
}
