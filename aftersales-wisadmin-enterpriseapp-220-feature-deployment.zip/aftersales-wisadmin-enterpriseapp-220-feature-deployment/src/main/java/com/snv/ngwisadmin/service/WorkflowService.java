package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.workflow.WorkflowInformation;
import com.snv.ngwisadmin.model.workflow.WorkflowRequestDTO;

public interface WorkflowService {

	public WorkflowInformation getWorkflowRequests();
	
	public WorkflowInformation actionWorkflowRequest(WorkflowRequestDTO dto, String action);
	
	public WorkflowInformation insertWorkflowRequest(WorkflowRequestDTO dto);
	
	public void insertWorkflowRequestOnly(WorkflowRequestDTO dto);

	public List<String> getApproverList(int requestId);
}
