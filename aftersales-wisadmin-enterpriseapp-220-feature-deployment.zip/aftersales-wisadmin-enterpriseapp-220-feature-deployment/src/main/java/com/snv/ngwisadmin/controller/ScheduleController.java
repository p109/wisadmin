package com.snv.ngwisadmin.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.BatchScheduleDTO;
import com.snv.ngwisadmin.service.ScheduleService;

@Controller
public class ScheduleController {

	@Autowired
	ScheduleService service;

	@RequestMapping(value = "/get-batch-schedule", method = RequestMethod.GET)
	@ResponseBody
	public List<BatchScheduleDTO> getBatchSchedule() {
		return service.getBatchSchedule();
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-batch-schedule", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<List<BatchScheduleDTO>> modifyBatchSchedule(@Valid @RequestBody BatchScheduleDTO dto,
			@RequestParam String action) {
		// return service.modifyBatchSchedule(dto, action);
		return ResponseEntity.status(HttpStatus.OK).body(service.modifyBatchSchedule(dto, action));
	}
}
