package com.snv.ngwisadmin.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedCredentialsNotFoundException;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.ALBTokenPayload;
import com.snv.ngwisadmin.model.UserDTO;
import com.snv.ngwisadmin.security.JwtUtil;
import com.snv.ngwisadmin.util.Utility;

@Service
@Order(2)
public class ALBUserDetailService implements UserDetailsService 
{

	@Autowired
	JwtUtil jwtUtil;
	
	@Autowired
	@Qualifier("userManagerDetails")
	UserDetailsService udService;
	
	public UserDetails loadUserByUsername(String token) throws UsernameNotFoundException {
		
		UserDTO loggedInUser = null;
		//TODO: Fix token constant
		if(token == null || !"Token not found".equals(token)) {
			
			ALBTokenPayload payload = null;
			
			payload = jwtUtil.decode(token);
			System.out.println("T3679A2 -- Got token to put into a user");
			
			if(payload != null && payload.getUserId() != null) {
				String userId = payload.getUserId().trim().toUpperCase();
				System.out.println("T3679A2 user type: " + payload.getUserType());
				//TODO: Fix access denied handler
				if ("supplier".equals(payload.getUserType()))
				{
					throw new AccessDeniedException("Access denied to supplier");
				}
				if (!"workforce".equals(payload.getUserType()))
				{
					throw new AccessDeniedException("Access denied for user");
				}
//				loggedInUser = new AppUser(userId, true, Set.of("USER"));
				loggedInUser = new UserDTO();
				loggedInUser.setUserId(userId);
				loggedInUser.setUserType(payload.getUserType());
				loggedInUser.setExpiration(payload.getExpiration());
				//Needs to fetch authorities granted
				udService.loadUserByUsername(loggedInUser.getUserId());
				loggedInUser.setAuthorities(udService.loadUserByUsername(loggedInUser.getUserId()).getAuthorities());
			}else {
				throw new PreAuthenticatedCredentialsNotFoundException("Token not found");
			}
		}else {
			throw new PreAuthenticatedCredentialsNotFoundException("Token not found");
		}
		
		return loggedInUser;
		//return loggedInUser;
	}
}
