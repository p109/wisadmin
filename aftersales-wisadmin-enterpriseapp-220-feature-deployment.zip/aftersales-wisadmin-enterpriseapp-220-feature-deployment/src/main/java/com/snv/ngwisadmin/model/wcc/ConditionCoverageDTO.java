package com.snv.ngwisadmin.model.wcc;

import java.util.List;

//This will include the condition classes, WCC ids, and WCC coverages
//So that condition classes can be mapped to WCCs
public class ConditionCoverageDTO {

	String wcc;
	String wccDesc;
	String condClass;
	String classDesc;
	public String getWcc() {
		return wcc;
	}
	public void setWcc(String wcc) {
		this.wcc = wcc;
	}
	public String getWccDesc() {
		return wccDesc;
	}
	public void setWccDesc(String wccDesc) {
		this.wccDesc = wccDesc;
	}
	public String getCondClass() {
		return condClass;
	}
	public void setCondClass(String condClass) {
		this.condClass = condClass;
	}
	public String getClassDesc() {
		return classDesc;
	}
	public void setClassDesc(String classDesc) {
		this.classDesc = classDesc;
	}
}
