package com.snv.ngwisadmin.repository.broadcast;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.broadcast.BroadcastMessageDTO;
import com.snv.ngwisadmin.util.Utility;

public class BroadcastMessageDTOMapper implements RowMapper<BroadcastMessageDTO> {

	public BroadcastMessageDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		BroadcastMessageDTO dto = new BroadcastMessageDTO();
		
		dto.setBroadcastType(rs.getString("C_BRD_TYP"));
		dto.setEffectiveDate(Utility.checkNull(rs.getDate("D_EFF_DATE")));
		dto.setEmail(rs.getString("X_EMAIL"));
		dto.setId(rs.getInt("I_REP_ID"));
		dto.setMessage(rs.getString("X_MSG"));
		dto.setMessageType(rs.getString("C_TYP"));
		dto.setReportType(rs.getString("C_REP"));
		dto.setSubject(rs.getString("X_SUBJECT"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		dto.setUser(rs.getString("I_LOGON"));
		
		return dto;
	}
}
