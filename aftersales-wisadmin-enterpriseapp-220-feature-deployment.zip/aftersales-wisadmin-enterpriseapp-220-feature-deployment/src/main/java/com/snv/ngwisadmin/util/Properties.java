package com.snv.ngwisadmin.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:wisadmin.properties")
public class Properties {

	@Value("${jdbc.url}")
	private String jdbcUrl;
	
	@Value("$(jdbc.user}")
	private String jdbcUser;
	
}
