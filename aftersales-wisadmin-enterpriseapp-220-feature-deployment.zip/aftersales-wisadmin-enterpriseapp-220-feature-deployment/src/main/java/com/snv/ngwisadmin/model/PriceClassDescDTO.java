package com.snv.ngwisadmin.model;

public class PriceClassDescDTO {

	String priceClass;
	String priceClassDesc;
	String oldPriceClass;

	public String getPriceClass() {
		return priceClass;
	}

	public void setPriceClass(String priceClass) {
		this.priceClass = priceClass;
	}

	public String getPriceClassDesc() {
		return priceClassDesc;
	}

	public void setPriceClassDesc(String priceClassDesc) {
		this.priceClassDesc = priceClassDesc;
	}

	public String getOldPriceClass() {
		return oldPriceClass;
	}

	public void setOldPriceClass(String oldPriceClass) {
		this.oldPriceClass = oldPriceClass;
	}

}
