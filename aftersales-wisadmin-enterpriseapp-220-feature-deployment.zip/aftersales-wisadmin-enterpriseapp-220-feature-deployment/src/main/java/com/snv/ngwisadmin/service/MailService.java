package com.snv.ngwisadmin.service;

import java.util.List;

public interface MailService {

	public void sendMail(List<String> distribution, String title, String body);
}
