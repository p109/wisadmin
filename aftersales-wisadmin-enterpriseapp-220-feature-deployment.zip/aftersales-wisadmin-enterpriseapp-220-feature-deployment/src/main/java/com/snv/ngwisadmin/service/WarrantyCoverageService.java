package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.wcc.ConditionClassDTO;
import com.snv.ngwisadmin.model.wcc.ConditionCoverageDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeClassDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeRuleDTO;

public interface WarrantyCoverageService {

	public List<CoverageCodeDTO> getCoverageDesc();
	
	public List<CoverageCodeDTO> modifyCoverageDesc(CoverageCodeDTO dto, String action);
	
	public List<CoverageCodeRuleDTO> getCoverageRules();
	
	public List<CoverageCodeRuleDTO> modifyCoverageRule(CoverageCodeRuleDTO dto, String action);
	
	public List<CoverageCodeClassDTO> getCoverageClass();

	public List<CoverageCodeClassDTO> updateCoverageClass(List<CoverageCodeClassDTO> dto, String aciton);
	
	public List<CoverageCodeClassDTO> modifyCoverageClass(CoverageCodeClassDTO dto, String action);
	
	public List<ConditionCoverageDTO> getConditionCoverage();
	
	public List<ConditionClassDTO> getConditionClass();
	
	public List<ConditionClassDTO> modifyConditionClass(ConditionClassDTO dto, String action);
}
