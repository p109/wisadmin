package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.CanadaExchangeDTO;
import com.snv.ngwisadmin.model.ExchangeDTO;
import com.snv.ngwisadmin.service.ExchangeRateService;

@Controller
public class ExchangeRateController {

	@Autowired
	ExchangeRateService service;

	@RequestMapping(value = "/get-canada-rates", method = RequestMethod.GET)
	@ResponseBody
	public List<CanadaExchangeDTO> getCanadaRates() {
		return service.getCanadaRates();
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-canada-rate", method = RequestMethod.POST)
	@ResponseBody
	public List<CanadaExchangeDTO> modifyCanadaRate(@RequestParam String action, @RequestBody CanadaExchangeDTO dto) {
		return service.modifyCanadaRate(dto, action);
	}

	@RequestMapping(value = "/get-exchange-rates", method = RequestMethod.GET)
	@ResponseBody
	public List<ExchangeDTO> getExchangeRates() {
		return service.getExchangeRates();
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-exchange-rate", method = RequestMethod.POST)
	@ResponseBody
	public List<ExchangeDTO> modifyExchangeRate(@RequestParam String action, @RequestBody ExchangeDTO dto) {
		return service.modifyExchangeRate(dto, action);
	}
}
