package com.snv.ngwisadmin.repository.broadcast;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.broadcast.BroadcastMessageInputDTO;

public class BroadcastMessageInputDTOMapper implements RowMapper<BroadcastMessageInputDTO> {

	@Override
	public BroadcastMessageInputDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		BroadcastMessageInputDTO broadcastMessageInputDTO = new BroadcastMessageInputDTO();
		broadcastMessageInputDTO.setBroadcastType(rs.getString("C_BRD_TYP"));
		broadcastMessageInputDTO.setReportType(rs.getString("C_REP"));
		broadcastMessageInputDTO.setMessageType(rs.getString("C_TYP"));
		return broadcastMessageInputDTO;
	}

}
