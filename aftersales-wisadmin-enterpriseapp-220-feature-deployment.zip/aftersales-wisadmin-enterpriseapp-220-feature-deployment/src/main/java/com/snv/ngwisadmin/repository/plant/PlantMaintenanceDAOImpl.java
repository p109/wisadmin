package com.snv.ngwisadmin.repository.plant;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.PlantCodeDTO;
import com.snv.ngwisadmin.model.PlantDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Constants;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class PlantMaintenanceDAOImpl implements PlantMaintenanceDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	DataSource ds;
	
	@Autowired
	AuthenticationFacade auth;
	
	private Map<String, String> assemblyMap = new HashMap<>();
	private Map<String, String> engineMap = new HashMap<>();
	private Map<String, String> transMap = new HashMap<>();
	private Map<String, String> engineCodeMap = new HashMap<>();
	private Map<String, String> transCodeMap = new HashMap<>();
	
	//Initialize the maps used for inserts, updates, and deletes
	public PlantMaintenanceDAOImpl()
	{
		super();
		assemblyMap.put("plant", "i_plt_assy");
		assemblyMap.put("location", "c_plt_assy_loc");
		assemblyMap.put("description", "x_plt_assy");
		assemblyMap.put("corploc", "i_corploc");
		
		//There's no corp location for engines and transmissions
		engineMap.put("plant", "i_plt_eng");
		engineMap.put("location", "c_plt_eng_loc");
		engineMap.put("description", "x_plt_eng");
		engineMap.put("corploc", "blank");
		
		transMap.put("plant", "i_plt_trn");
		transMap.put("location", "c_plt_trn_loc");
		transMap.put("description", "x_plt_trn");
		transMap.put("corploc", "blank");
		
		//Plant codes
		engineCodeMap.put("scode", "c_eng_scode");
		engineCodeMap.put("plant", "c_plt_eng");
		engineCodeMap.put("ucode", "c_eng_unq_scode");
		engineCodeMap.put("id", "i_ep_rule_id");
		
		transCodeMap.put("scode", "c_trn_scode");
		transCodeMap.put("plant", "c_plt_trn");
		transCodeMap.put("ucode", "c_trn_unq_scode");
		transCodeMap.put("id", "i_tp_rule_id");
	}
	
	public List<PlantDTO> getPlantDesc(String type) {
		String table = getDescTable(type);
		String sql = "select * from wis." + table;
		List<PlantDTO> plantList = jdbcTemplate.query(sql, new PlantDTOMapper(type));
		return plantList;
	}
	
	public List<PlantCodeDTO> getPlantCodes(String type) {
		String table = getCodeTable(type);
		String sql = "select * from wis." + table;
		List<PlantCodeDTO> plantList = jdbcTemplate.query(sql, new PlantCodeDTOMapper(type));
		return plantList;
	}
	
	public boolean insertPlantDesc(String type, PlantDTO dto) {
		String table = getDescTable(type);
		Map<String, String> descMap = getDescMap(type);

		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName(table);
		Map<String, Object> params = new HashMap<>();
		params.put(descMap.get("plant"), dto.getPlant());
		params.put(descMap.get("location"), dto.getPlantLocation());
		params.put(descMap.get("description"), dto.getPlantDescription());
		params.put(descMap.get("corploc"), dto.getPlantLocation().substring(1));
		
		params.put("c_cd", "99ASSY");
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		
		jdbcInsert.execute(params);
		return true;
	}
	
	public boolean updatePlantDesc(String type, List<PlantDTO> dtoList) {
		String table = getDescTable(type);
		Map<String, String> descMap = getDescMap(type);
		
		String sql = "update wis." + table + " set ";
		
		//dynamically set update fields
		for (String key : descMap.keySet())
		{
			if ("corploc".equals(key) && ("T".equals(type) || "E".equals(type)))
				continue;
			sql = sql.concat(descMap.get(key) + " = :" + key + ",");
		}
		
		sql = sql.concat("i_logon = :user,t_stmp_upd = current_timestamp");
		sql = sql.concat(" where " + descMap.get("plant") + " = :oldPlant");
		sql = sql.concat(" and " + descMap.get("location") + " = :oldLocation");
		
		Map<String, Object> params = new HashMap<>();
		PlantDTO oldDto = dtoList.get(0);
		PlantDTO newDto = dtoList.get(1);
		params.put("plant", newDto.getPlant());
		params.put("location", newDto.getPlantLocation());
		params.put("corploc", newDto.getPlantLocation().substring(1));
		params.put("description", newDto.getPlantDescription());
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldPlant", oldDto.getPlant());
		params.put("oldLocation", oldDto.getPlantLocation());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean deletePlantDesc(String type, PlantDTO dto)
	{
		String table = getDescTable(type);
		Map<String, String> descMap = getDescMap(type);
		
		String sql = "delete from wis." + table + " where ";
		sql += descMap.get("plant") + " = :plant and " + descMap.get("location") + " = :location";
		
		Map<String, Object> params = new HashMap<>();
		params.put("plant", dto.getPlant());
		params.put("location", dto.getPlantLocation());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean insertPlantCode(String type, PlantCodeDTO dto)
	{
		String table = getCodeTable(type);
		Map<String, String> codeMap = getCodeMap(type);
		
		//Get new rule id
		int maxId = 0;
		if (type.equals(Constants.TRANS_PLANT))
			maxId = Utility.getMaxId("TP PLANT", jdbcTemplate);
		else
			maxId = Utility.getMaxId("EP PLANT", jdbcTemplate);
		
		maxId += 1;

		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName(table);
		Map<String, Object> params = new HashMap<>();
		
		params.put(codeMap.get("plant"), dto.getPlant());
		params.put(codeMap.get("scode"), dto.getSalesCode());
		params.put(codeMap.get("ucode"), dto.getPlantCode());
		params.put(codeMap.get("id"), maxId);
		
		params.put("i_mod_yr", dto.getModelYear());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		jdbcInsert.execute(params);
		return true;
	}
	
	public boolean updatePlantCode(String type, List<PlantCodeDTO> dtoList)
	{
		String table = getCodeTable(type);
		Map<String, String> codeMap = getCodeMap(type);
		
		String sql = "update wis." + table + " set ";
		//dynamically set update fields
		for (String key : codeMap.keySet())
		{
			//Not updating the id field
			if ("id".equals(key))
				continue;
			sql = sql.concat(codeMap.get(key) + " = :" + key + ",");
		}
		sql += "i_mod_yr = :my, i_logon = :user, t_stmp_upd = current_timestamp";
		sql += " where " + codeMap.get("id") + " = :id";
		
		PlantCodeDTO oldDto = dtoList.get(0);
		PlantCodeDTO newDto = dtoList.get(1);
		Map<String, Object> params = new HashMap<>();
		params.put("plant", newDto.getPlant());
		params.put("scode", newDto.getSalesCode());
		params.put("ucode", newDto.getPlantCode());
		params.put("id", oldDto.getId());
		params.put("my", newDto.getModelYear());
		params.put("user", auth.getLoggedInUser().getUserId());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean deletePlantCode(String type, PlantCodeDTO dto)
	{
		String table = getCodeTable(type);
		Map<String, String> codeMap = getCodeMap(type);
		
		String sql = "delete from wis." + table + " where " + codeMap.get("id") + " = :id";
		
		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	//Get table name of the plant description
	private String getDescTable(String type)
	{
		switch (type)
		{
			case Constants.ASSEMBLY_PLANT:
				return "ap_desc";
			case Constants.ENGINE_PLANT:
				return "ep_desc";
			case Constants.TRANS_PLANT:
				return "tp_desc";
		}
		return "";
	}
	
	//Get table name of the plant codes
	private String getCodeTable(String type)
	{
		switch (type)
		{
			case Constants.TRANS_PLANT:
				return "tp_ucode";
			case Constants.ENGINE_PLANT:
				return "ep_ucode";
		}
		
		return "";
	}
	
	//Get the description map for insert update or delete
	private Map<String, String> getDescMap(String type)
	{
		switch (type)
		{
			case "A":
				return assemblyMap;
			case "E":
				return engineMap;
			case "T":
				return transMap;
		}
		return new HashMap<String, String>();
	}
	
	private Map<String, String> getCodeMap(String type)
	{
		switch (type)
		{
			case "E":
				return engineCodeMap;
			case "T":
				return transCodeMap;
		}
		return new HashMap<String, String>();
	}
}
