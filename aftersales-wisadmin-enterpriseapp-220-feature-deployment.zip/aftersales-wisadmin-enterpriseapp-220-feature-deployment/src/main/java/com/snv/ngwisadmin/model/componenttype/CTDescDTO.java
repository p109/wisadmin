package com.snv.ngwisadmin.model.componenttype;

import javax.validation.constraints.NotEmpty;

public class CTDescDTO {
	@NotEmpty(message = "CT can not be empty")
	String ct;
	@NotEmpty(message = "CT Description can not be empty")
	String ctDesc;
	String user;
	String updateTime;

	public CTDescDTO() {
		ct = "";
		ctDesc = "";
		user = "";
		updateTime = "";
	}

	public String getCt() {
		return ct;
	}

	public void setCt(String ct) {
		this.ct = ct;
	}

	public String getCtDesc() {
		return ctDesc;
	}

	public void setCtDesc(String ctDesc) {
		this.ctDesc = ctDesc;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

}
