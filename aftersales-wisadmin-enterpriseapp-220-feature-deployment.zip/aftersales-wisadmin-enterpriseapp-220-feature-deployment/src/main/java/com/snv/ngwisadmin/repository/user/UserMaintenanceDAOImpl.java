package com.snv.ngwisadmin.repository.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.UserGroupDTO;
import com.snv.ngwisadmin.model.UserMembershipDTO;

@Repository
public class UserMaintenanceDAOImpl implements UserMaintenanceDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	DataSource ds;
	
	public List<UserGroupDTO> getUserGroup()
	{
		System.out.println("Get all users");
		String sql = "SELECT N_GROUP, X_GROUP FROM AQIP.USR_GRP WHERE trim(I_SYSTEM) = 'NGW'";
		List<UserGroupDTO> list = jdbcTemplate.query(sql, new HashMap<>(), new UserGroupDTOMapper());
		return list;
	}
	
	//Fetches all users and their assigned groups
	public List<UserMembershipDTO> getUserMembership()
	{
		String sql = "SELECT I_LOGON, N_GROUP FROM AQIP.USR_GRP_ASGN WHERE TRIM(I_SYSTEM) = 'NGW'";
		List<UserMembershipDTO> list = jdbcTemplate.query(sql, new HashMap<>(), 
				new UserMembershipDTOMapper());
		return list;
	}
	
	//Fetches a specific user's assigned groups
	public List<UserMembershipDTO> getUserMembership(String id)
	{
		System.out.println("Get for id:" + id);
		String sql = "SELECT I_LOGON, N_GROUP FROM AQIP.USR_GRP_ASGN WHERE TRIM(I_SYSTEM) = 'NGW'" +
				" AND TRIM(I_LOGON) = :logon";
		Map<String, Object> params = new HashMap<>();
		params.put("logon", id.toLowerCase());
		List<UserMembershipDTO> list = jdbcTemplate.query(sql, params, new UserMembershipDTOMapper());
		return list;
	}
	
	public boolean insertUserMemberList(List<UserMembershipDTO> dto)
	{
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("aqip")
				.withTableName("usr_grp_asgn");
		for (UserMembershipDTO user : dto)
		{
			Map<String, Object> params = new HashMap<>();
			params.put("I_LOGON", user.getUserId().toLowerCase());
			params.put("I_SYSTEM", "NGW");
			params.put("N_GROUP", user.getUserGroup());
			jdbcInsert.execute(params);
		}
		
		return true;
	}
	
	public boolean deleteUserMemberList(List<UserMembershipDTO> dto)
	{
		String sql = "DELETE FROM AQIP.USR_GRP_ASGN WHERE TRIM(I_LOGON) = :id AND " +
				"trim(N_GROUP) = :group";
		for (UserMembershipDTO user : dto)
		{
			Map<String, Object> params = new HashMap<>();
			params.put("id", user.getUserId().toLowerCase());
			params.put("group", user.getUserGroup());
			jdbcTemplate.update(sql, params);
		}
		
		return true;
	}
	
	public List<String> getUserRoles(String uid)
	{
		String sql = "select g.role from aqip.usr_grp g, aqip.usr_grp_asgn a " +
        		"where trim(a.i_logon) = :uid and a.i_system = g.i_system and "
				+ "a.n_group = g.n_group and g.role is not null ";
		Map<String, Object> params = new HashMap<>();
		params.put("uid", uid);
		return jdbcTemplate.queryForList(sql, params, String.class);
	}
}
