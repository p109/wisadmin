package com.snv.ngwisadmin.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.LdapUserDTO;
import com.snv.ngwisadmin.model.UserGroupDTO;
import com.snv.ngwisadmin.model.UserMembershipDTO;
import com.snv.ngwisadmin.service.UserMaintenanceService;

@Controller
public class UserMaintenanceController {

	@Autowired
	UserMaintenanceService service;
	
	@RequestMapping(value = "/get-user-group", method = RequestMethod.GET)
	@ResponseBody
	public List<UserGroupDTO> getUserGroup()
	{
		System.out.println("Get user group");
		return service.getUserGroup();
	}
	
	@RequestMapping(value = "/get-user-membership", method = RequestMethod.GET)
	@ResponseBody
	public List<UserMembershipDTO> getUserMembership(@RequestParam(required = false) String id)
	{
		System.out.println("Get user membership");
		return service.getUserMembership(id);
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_USER_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/update-user-membership", method = RequestMethod.POST)
	@ResponseBody
	public List<UserMembershipDTO> updateUserMembership(@RequestBody UserMembershipDTO[] user)
	{
		//Convert array into list
		List<UserMembershipDTO> userList = new ArrayList<>(Arrays.asList(user));
		
		//Run service methods against the list
		service.updateUserMembership(userList);
		return service.getUserMembership("");
	}
	
	@RequestMapping(value = "/get-user-details", method = RequestMethod.GET)
	@ResponseBody
	public LdapUserDTO getUserDetails(@RequestParam String id)
	{
		return service.getUserDetails(id);
	}
}
