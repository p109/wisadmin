package com.snv.ngwisadmin.repository.body;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.BodyRuleDTO;
import com.snv.ngwisadmin.util.Utility;

public class BodyRuleDTOMapper implements RowMapper<BodyRuleDTO> {

	public BodyRuleDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		BodyRuleDTO dto = new BodyRuleDTO();
		
		dto.setAssemblyPlant(rs.getString("I_ASSY_PLT"));
		dto.setBodyStyle(rs.getString("C_BDY_STYLE"));
		dto.setCorpLoc(rs.getString("I_CORPLOC"));
		dto.setBlock(rs.getString("L_BLOCK"));
		dto.setFamily(rs.getString("C_FAM"));
		dto.setLine(rs.getString("C_LINE"));
		dto.setModelYear(rs.getString("I_MOD_YR"));
		dto.setPlatform(rs.getString("C_PLATFORM"));
		dto.setProductLine(rs.getString("C_PROD_LINE"));
		dto.setSalesCodes(rs.getString("C_SCODE_PAT"));
		dto.setSeries(rs.getString("C_SERIES"));
		dto.setEffectiveStart(Utility.checkNull(rs.getDate("D_EFF_STRT")));
		dto.setEffectiveEnd(Utility.checkNull(rs.getDate("D_EFF_END")));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		dto.setId(rs.getInt("I_BDY_RULE_ID"));
		
		
		return dto;
	}
}
