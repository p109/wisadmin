package com.snv.ngwisadmin.exceptionhandler;

import java.util.Arrays;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.snv.ngwisadmin.model.BatchScheduleDTO;

@ControllerAdvice
public class ControllerAdvisor extends ResponseEntityExceptionHandler {

	@Override
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		BatchScheduleDTO response = null;
		if (ex.getBindingResult().getTarget() instanceof BatchScheduleDTO) {
			response = (BatchScheduleDTO) ex.getBindingResult().getTarget();
		}

		response.setError(true);
		response.setErrorMessage(ex.getBindingResult().getFieldError().getDefaultMessage());
		response.setStatus(status.value() + ":" + status.getReasonPhrase());
		return new ResponseEntity<>(Arrays.asList(response), status);
	}
}
