package com.snv.ngwisadmin.model.wcc;

import javax.validation.constraints.NotEmpty;

public class CoverageCodeDTO {
	@NotEmpty(message = "WCC can not be empty")
	String wcc;
	String oldWcc;
	@NotEmpty(message = "WCC description can not be empty")
	String wccDesc;
	String user;
	String updateTime;
	public String getWcc() {
		return wcc;
	}
	public void setWcc(String wcc) {
		this.wcc = wcc;
	}
	public String getOldWcc() {
		return oldWcc;
	}
	public void setOldWcc(String oldWcc) {
		this.oldWcc = oldWcc;
	}
	public String getWccDesc() {
		return wccDesc;
	}
	public void setWccDesc(String wccDesc) {
		this.wccDesc = wccDesc;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	
	
}
