package com.snv.ngwisadmin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.snv.ngwisadmin.model.LdapUserDTO;
import com.snv.ngwisadmin.model.UserDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.security.LdapClient;

//This handles top level navigation to each web page
@Controller
public class MainController {
	
	@Autowired
	AuthenticationFacade authFacade;
	
	@RequestMapping(value = "/ct-maintenance", method = RequestMethod.GET)
	public String getCTMaintenance() {
		return "html/CTMaintenance.html";
	}

	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public String getIndex() {
		InstanceProfileCredentialsProvider i = new InstanceProfileCredentialsProvider(false);
		System.out.println("Instance creds: " + i.getCredentials());
		
		return "html/index.html";
	}

	@RequestMapping(value = "/plant-maintenance", method = RequestMethod.GET)
	public String getPlantMaintenance() {
		return "html/plantMaintenance.html";
	}

	@RequestMapping(value = "/block-rule", method = RequestMethod.GET)
	public String getBlockRules() {
		return "html/blockRule.html";
	}

	@RequestMapping(value = "/body-maintenance", method = RequestMethod.GET)
	public String getBodyMaintenance() {
		return "html/bodyMaintenance.html";
	}
	
	@RequestMapping(value = "/broadcast-maintenance", method = RequestMethod.GET)
	public String getBroadcastMaintenance() {
		return "html/broadcastMaintenance.html";
	}

	@RequestMapping(value = "/exchange-rate", method = RequestMethod.GET)
	public String getExchangeRate() {
		return "html/exchangeRate.html";
	}

	@RequestMapping(value = "/schedule-maintenance", method = RequestMethod.GET)
	public String getScheduleMaintenance() {
		System.out.println("Inside schedule maintenance screen");
		return "html/scheduleMaintenance.html";
	}

	@RequestMapping(value = "/wcc-maintenance", method = RequestMethod.GET)
	public String getWccMaintenance() {
		return "html/wccMaintenance.html";
	}

	@RequestMapping(value = "/workflow", method = RequestMethod.GET)
	public String getWorkflow() {
		return "html/workflow.html";
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/workflow-approvals", method = RequestMethod.GET)
	public String getWorkflowApprovals() {
		return "html/workflowApprovals.html";
	}
	
	@RequestMapping(value = "/workflow-home", method = RequestMethod.GET)
	public String getWorkflowHome() {
		return "html/workflowHome.html";
	}
	
	@RequestMapping(value = "/quality-maintenance", method = RequestMethod.GET)
	public String getQualityMaintenance() {
		return "html/qualityMaintenance.html";
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_USER_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/user-maintenance", method = RequestMethod.GET)
	public String getUserMaintenance() {
		return "html/userMaintenance.html";
	}
}
