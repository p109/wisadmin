package com.snv.ngwisadmin.util;

public class Constants {

	public static final String INSERT = "I";
	public static final String UPDATE = "U";
	public static final String DELETE = "D";
	
	public static final String WORKFLOW_APPROVED = "A";
	public static final String WORKFLOW_REJECTED = "R";
	public static final String WORKFLOW_PENDING = "P";
	
	public static final String WORKFLOW_STEP_APPROVE = "A";
	public static final String WORKFLOW_STEP_REJECT = "R";
	
	public static final String BROADCAST_DESC = "B";
	public static final String BROADCAST_TYPE_DESC = "M";
	public static final String REPORT_DESC = "R";
	
	public static final String ENGINE_PLANT = "E";
	public static final String TRANS_PLANT = "T";
	public static final String ASSEMBLY_PLANT = "A";
	
	public static final String TOKEN_NOT_FOUND = "TOKEN NOT FOUND";
	public static final String USER_NOT_FOUND = "USER NOT FOUND";
	
}
