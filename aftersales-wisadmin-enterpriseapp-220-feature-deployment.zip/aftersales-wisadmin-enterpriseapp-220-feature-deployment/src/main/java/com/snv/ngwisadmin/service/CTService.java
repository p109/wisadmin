package com.snv.ngwisadmin.service;

import java.util.List;
import java.util.Vector;

import com.snv.ngwisadmin.model.componenttype.CTClassDTO;
import com.snv.ngwisadmin.model.componenttype.CTDescDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleMap;

public interface CTService {

	public List<CTClassDTO> getCTClassDesc();
	
	public List<CTDescDTO> getCTDesc();
	
	public CTRuleMap getCTRule();
	
	public List<CTDescDTO> insertCTDesc(CTDescDTO dto);
	
	public List<CTDescDTO> updateCTDesc(List<CTDescDTO> dtoList);
	
	public List<CTDescDTO> deleteCTDesc(CTDescDTO dto);
	
	public List<CTClassDTO> insertCTClassDesc(CTClassDTO dto);
	
	public List<CTClassDTO> updateCTClassDesc(List<CTClassDTO> dtoList);
	
	public List<CTClassDTO> deleteCTClassDesc(CTClassDTO dto);
	
	public CTRuleMap insertCTRule(CTRuleDTO dto);
	
	public CTRuleMap updateCTRule(List<CTRuleDTO> dtoList);
	
	public CTRuleMap deleteCTRule(CTRuleDTO dto);
	
	public void promoteCTRule();
}
