package com.snv.ngwisadmin.repository.workflow;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.workflow.WorkflowRequestDTO;
import com.snv.ngwisadmin.util.Utility;

public class WorkflowRequestDTOMapper implements RowMapper<WorkflowRequestDTO> {

	public WorkflowRequestDTO mapRow(ResultSet rs, int index) throws SQLException {
		WorkflowRequestDTO dto = new WorkflowRequestDTO();

		dto.setId(rs.getInt("REQUEST_ID"));
		dto.setDescription(rs.getString("REQUEST_DESC"));
		dto.setRequestor(rs.getString("REQUESTOR"));
		dto.setCompleteTime(Utility.checkNull(rs.getTimestamp("T_STMP_COMPLETE")));
		dto.setRequestTime(rs.getTimestamp("T_STMP_SUBMIT").toString());
		dto.setStatus(rs.getString("REQUEST_STATUS"));
		dto.setStep(rs.getInt("SEQ_STEP"));

		return dto;
	}
}
