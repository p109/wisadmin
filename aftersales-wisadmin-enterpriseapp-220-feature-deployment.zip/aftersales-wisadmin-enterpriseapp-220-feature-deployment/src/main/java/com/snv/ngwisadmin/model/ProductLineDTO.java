package com.snv.ngwisadmin.model;

import javax.validation.constraints.NotEmpty;

public class ProductLineDTO {
	@NotEmpty(message = "Product Line can not be empty")
	String productLine;
	@NotEmpty(message = "Description can not be empty")
	String description;
	String user;
	String updateTime;
	@NotEmpty(message = "Lop book can not be empty")
	String lopBook;
	@NotEmpty(message = "Platform can not be empty")
	String platform;
	String oldProductLine;
	String oldPlatform;

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getLopBook() {
		return lopBook;
	}

	public void setLopBook(String lopBook) {
		this.lopBook = lopBook;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getOldProductLine() {
		return oldProductLine;
	}

	public void setOldProductLine(String oldProductLine) {
		this.oldProductLine = oldProductLine;
	}

	public String getOldPlatform() {
		return oldPlatform;
	}

	public void setOldPlatform(String oldPlatform) {
		this.oldPlatform = oldPlatform;
	}

}
