package com.snv.ngwisadmin.repository.quality;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.QualityManagerDTO;

public class QualityManagerDTOMapper implements RowMapper<QualityManagerDTO> {

	@Override
	public QualityManagerDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		QualityManagerDTO dto = new QualityManagerDTO();
		dto.setQualityManager(rs.getString("C_QUAL_MGR"));
		dto.setQualityManagerDescription(rs.getString("X_QUAL_MGR"));
		dto.setCommodityDirector(rs.getString("C_CD"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		return dto;
	}

}
