package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.workflow.WorkflowInformation;
import com.snv.ngwisadmin.model.workflow.WorkflowRequestDTO;
import com.snv.ngwisadmin.service.WorkflowService;

@Controller
public class WorkflowController {

	@Autowired
	WorkflowService service;

	@RequestMapping(value = "/get-workflow-requests", method = RequestMethod.GET)
	@ResponseBody
	public WorkflowInformation getWorkflowRequests() {
		return service.getWorkflowRequests();
	}

	@RequestMapping(value = "/insert-workflow-request", method = RequestMethod.POST)
	@ResponseBody
	public WorkflowInformation insertWorkflowRequest(@RequestBody WorkflowRequestDTO dto) {
		return service.insertWorkflowRequest(dto);
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/action-workflow-request", method = RequestMethod.POST)
	@ResponseBody
	public WorkflowInformation actionWorkflowRequest(@RequestBody WorkflowRequestDTO dto, @RequestParam String action) {
		return service.actionWorkflowRequest(dto, action);
	}

	@RequestMapping(value = "/get-approver-list", method = RequestMethod.GET)
	@ResponseBody
	public List<String> getApproverList(int requestId) {
		System.out.println("Inside Get ApproverList to find approvers for request ID: " + requestId);
		return service.getApproverList(requestId);
	}

}
