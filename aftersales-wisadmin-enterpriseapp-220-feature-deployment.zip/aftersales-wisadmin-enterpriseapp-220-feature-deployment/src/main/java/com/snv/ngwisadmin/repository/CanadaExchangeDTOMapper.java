package com.snv.ngwisadmin.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.CanadaExchangeDTO;

public class CanadaExchangeDTOMapper implements RowMapper<CanadaExchangeDTO> {

	public CanadaExchangeDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		CanadaExchangeDTO dto = new CanadaExchangeDTO();
		dto.setModelYear(rs.getShort("I_MOD_YR"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		dto.setRate(rs.getFloat("Q_EXCHNG_RATE"));
		
		return dto;
	}
}
