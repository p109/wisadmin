package com.snv.ngwisadmin.repository.componenttype;

import java.util.List;
import java.util.Vector;

import com.snv.ngwisadmin.model.componenttype.CTClassDTO;
import com.snv.ngwisadmin.model.componenttype.CTDescDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleMap;

public interface CTMaintenanceDAO {

	public List<CTClassDTO> getCTClassDesc();
	
	public List<CTDescDTO> getCTDesc();
	
	public CTRuleMap getCTRule();
	
	public boolean insertCTDesc(CTDescDTO dto);
	
	public boolean insertCTClassDesc(CTClassDTO dto);
	
	public boolean insertCTRule(CTRuleDTO dto);
	
	public boolean updateCTDesc(List<CTDescDTO> dtoList);
	
	public boolean updateCTClassDesc(List<CTClassDTO> dtoList);
	
	public boolean updateCTRule(List<CTRuleDTO> dtoList);
	
	public boolean deleteCTDesc(CTDescDTO dto);
	
	public boolean deleteCTClassDesc(CTClassDTO dto);
	
	public boolean deleteCTRule(CTRuleDTO dto);
	
	public boolean promoteCTRule();
}
