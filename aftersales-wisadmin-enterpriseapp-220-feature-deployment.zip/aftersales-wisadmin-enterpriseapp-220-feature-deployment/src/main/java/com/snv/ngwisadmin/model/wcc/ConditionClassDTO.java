package com.snv.ngwisadmin.model.wcc;

import javax.validation.constraints.NotEmpty;

public class ConditionClassDTO {
    @NotEmpty(message = "The Condition Class can not be empty")
    String code;
    String desc;
    String user;
    String updateTime;
    String oldCode;
    String oldDesc;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getOldCode() {
		return oldCode;
	}
	public void setOldCode(String oldCode) {
		this.oldCode = oldCode;
	}
	public String getOldDesc() {
		return oldDesc;
	}
	public void setOldDesc(String oldDesc) {
		this.oldDesc = oldDesc;
	}
    
    
}