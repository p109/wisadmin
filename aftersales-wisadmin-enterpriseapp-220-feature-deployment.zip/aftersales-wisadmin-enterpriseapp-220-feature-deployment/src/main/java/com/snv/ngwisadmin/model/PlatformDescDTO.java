package com.snv.ngwisadmin.model;

import javax.validation.constraints.NotEmpty;

public class PlatformDescDTO {

	@NotEmpty(message = "Platform can not be empty")
	String platform;
	@NotEmpty(message = "Platform description can not be empty")
	String description;
	String user;
	String updateTime;
	String oldPlatform;
	
	
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getOldPlatform() {
		return oldPlatform;
	}
	public void setOldPlatform(String oldPlatform) {
		this.oldPlatform = oldPlatform;
	}
	
	
}
