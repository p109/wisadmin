package com.snv.ngwisadmin.repository.plant;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.PlantCodeDTO;

public class PlantCodeDTOMapper implements RowMapper<PlantCodeDTO> {

	String plantType;
	
	public PlantCodeDTOMapper(String plantType) {
		super();
		this.plantType = plantType;
	}
	
	public PlantCodeDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		PlantCodeDTO dto = new PlantCodeDTO();
		
		if ("E".equals(plantType))
		{
			dto.setPlant(rs.getString("C_PLT_ENG"));
			dto.setPlantCode(rs.getString("C_ENG_UNQ_SCODE"));
			dto.setSalesCode(rs.getString("C_ENG_SCODE"));
			dto.setId(rs.getInt("I_EP_RULE_ID"));
		}
		else
		if ("T".equals(plantType))
		{
			dto.setPlant(rs.getString("C_PLT_TRN"));
			dto.setPlantCode(rs.getString("C_TRN_UNQ_SCODE"));
			dto.setSalesCode(rs.getString("C_TRN_SCODE"));
			dto.setId(rs.getInt("I_TP_RULE_ID"));
		}
		
		dto.setModelYear(rs.getString("I_MOD_YR"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTimestamp(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
