package com.snv.ngwisadmin.security;

import org.springframework.security.core.Authentication;

import com.snv.ngwisadmin.model.UserDTO;

public interface AuthenticationFacade {
	public Authentication getAuthentication();
	
	public UserDTO getLoggedInUser();
}
