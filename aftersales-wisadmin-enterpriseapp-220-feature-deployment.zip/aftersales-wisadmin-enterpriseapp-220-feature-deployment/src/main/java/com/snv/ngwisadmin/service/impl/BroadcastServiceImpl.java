package com.snv.ngwisadmin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.broadcast.BroadcastMessageDTO;
import com.snv.ngwisadmin.model.broadcast.BroadcastMessageMap;
import com.snv.ngwisadmin.model.broadcast.BroadcastTypeDTO;
import com.snv.ngwisadmin.repository.broadcast.BroadcastDAO;
import com.snv.ngwisadmin.service.BroadcastService;
import com.snv.ngwisadmin.util.Constants;

@Service
public class BroadcastServiceImpl implements BroadcastService {

	@Autowired
	BroadcastDAO dao;
	
	@Override
	public List<BroadcastTypeDTO> getBroadcastType(String type) {
		// TODO Auto-generated method stub
		return dao.getBroadcastType(type);
	}

	@Override
	public List<BroadcastMessageDTO> getBroadcastMessage() {
		// TODO Auto-generated method stub
		return dao.getBroadcastMessage();
	}

	@Override
	public List<BroadcastTypeDTO> modifyBroadcastType(BroadcastTypeDTO dto,
			String type, String action) {
		if (Constants.INSERT.equals(action))
		{
			dao.insertBroadcastType(dto, type);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updateBroadcastType(dto, type);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteBroadcastType(dto, type);
		}
		return dao.getBroadcastType(type);
	}

	@Override
	public List<BroadcastMessageDTO> modifyBroadcastMessage(
			BroadcastMessageDTO dto, String action) {
		if (Constants.INSERT.equals(action))
		{
			dao.insertBroadcastMessage(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updateBroadcastMessage(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteBroadcastMessage(dto);
		}
		return dao.getBroadcastMessage();
	}

	@Override
	public BroadcastMessageMap getInputParametersForBroadcastMessage() {
		return dao.getInputParametersForBroadcastMessage();
	}

}
