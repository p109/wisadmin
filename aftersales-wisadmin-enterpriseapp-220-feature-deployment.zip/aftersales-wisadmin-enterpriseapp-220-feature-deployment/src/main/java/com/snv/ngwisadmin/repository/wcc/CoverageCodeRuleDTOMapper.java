package com.snv.ngwisadmin.repository.wcc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.wcc.CoverageCodeRuleDTO;
import com.snv.ngwisadmin.util.Utility;

public class CoverageCodeRuleDTOMapper implements RowMapper<CoverageCodeRuleDTO> {

	public CoverageCodeRuleDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		CoverageCodeRuleDTO dto = new CoverageCodeRuleDTO();
		dto.setId(rs.getInt("I_WCC_RULE_ID"));
		dto.setWcc(rs.getString("C_WCC"));
		dto.setEffectiveStart(Utility.checkNull(rs.getDate("D_EFF_STRT")));
		dto.setEffectiveEnd(Utility.checkNull(rs.getDate("D_EFF_END")));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		dto.setMonthLimit(rs.getInt("Q_MNTH_LIM"));
		dto.setMileLimit(rs.getInt("Q_MILE_LIM"));
		
		return dto;
	}
}
