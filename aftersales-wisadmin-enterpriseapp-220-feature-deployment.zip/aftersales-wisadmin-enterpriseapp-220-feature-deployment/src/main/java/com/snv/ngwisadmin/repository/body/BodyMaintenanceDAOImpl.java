package com.snv.ngwisadmin.repository.body;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.BodyRuleDTO;
import com.snv.ngwisadmin.model.LaunchRuleDTO;
import com.snv.ngwisadmin.model.PlatformDescDTO;
import com.snv.ngwisadmin.model.PriceClassDescDTO;
import com.snv.ngwisadmin.model.ProductLineDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class BodyMaintenanceDAOImpl implements BodyMaintenanceDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	DataSource ds;

	@Autowired
	AuthenticationFacade auth;

	public List<BodyRuleDTO> getBodyRules() {
		String sql = "select * from wis.bdy_rule";
		List<BodyRuleDTO> dtoList = jdbcTemplate.query(sql, new BodyRuleDTOMapper());
		return dtoList;
	}

	public List<LaunchRuleDTO> getLaunchRules() {
		String sql = "select * from wis.lnch_rule";
		List<LaunchRuleDTO> dtoList = jdbcTemplate.query(sql, new LaunchRuleDTOMapper());
		return dtoList;
	}

	public List<PlatformDescDTO> getPlatformDesc() {
		String sql = "select * from wis.pltfrm_desc";
		List<PlatformDescDTO> dtoList = jdbcTemplate.query(sql, new PlatformDescDTOMapper());
		return dtoList;
	}

	public List<ProductLineDTO> getProductLine() {
		String sql = "select * from wis.pl_desc";
		List<ProductLineDTO> dtoList = jdbcTemplate.query(sql, new ProductLineDTOMapper());
		return dtoList;
	}

	public boolean insertBodyRule(BodyRuleDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("bdy_rule");
		Map<String, Object> params = new HashMap<>();

		int maxId = Utility.getMaxId("BODY RULE", jdbcTemplate);
		maxId++;

		params.put("i_bdy_rule_id", maxId);
		params.put("i_mod_yr", dto.getModelYear());
		params.put("c_fam", dto.getFamily());
		params.put("c_line", dto.getLine());
		params.put("c_series", dto.getSeries());
		params.put("c_bdy_style", dto.getBodyStyle());
		params.put("i_assy_plt", dto.getAssemblyPlant());
		params.put("c_scode_pat", dto.getSalesCodes());
		params.put("c_prod_line", dto.getProductLine());
		params.put("c_wis_prc_cls", null);
		params.put("c_wis_bdy_style", null);
		params.put("l_block", dto.getBlock());
		params.put("d_eff_strt", Utility.toDate(dto.getEffectiveStart()));
		params.put("d_eff_end", Utility.toDate(dto.getEffectiveEnd()));
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		params.put("c_platform", dto.getPlatform());
		params.put("i_corploc", dto.getCorpLoc());
		jdbcInsert.execute(params);

		return true;
	}

	public boolean updateBodyRule(BodyRuleDTO dto) {
		String sql = "update wis.bdy_rule set i_mod_yr = :my, c_fam = :fam, c_line = :line,"
				+ "c_series = :series, c_bdy_style = :bdy, i_assy_plt = :assy, "
				+ "c_scode_pat = :scode, c_prod_line = :pl, c_wis_prc_cls = :price, "
				+ "c_wis_bdy_style = :bdyTwo, l_block = :block, d_eff_strt = :effStart, "
				+ "d_eff_end = :effEnd, i_logon = :user, t_stmp_upd = current_timestamp,"
				+ "c_platform = :platform, i_corploc = :loc where i_bdy_rule_id = :id";

		Map<String, Object> params = new HashMap<>();
		params.put("my", dto.getModelYear());
		params.put("fam", dto.getFamily());
		params.put("line", dto.getLine());
		params.put("series", dto.getSeries());
		params.put("bdy", dto.getBodyStyle());
		params.put("assy", dto.getAssemblyPlant());
		params.put("scode", dto.getSalesCodes());
		params.put("pl", dto.getProductLine());
		params.put("price", null);
		params.put("bdyTwo", null);
		params.put("block", dto.getBlock());
		params.put("effStart", Utility.toDate(dto.getEffectiveStart()));
		params.put("effEnd", Utility.toDate(dto.getEffectiveEnd()));
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("platform", dto.getPlatform());
		params.put("loc", dto.getCorpLoc());
		params.put("id", dto.getId());

		jdbcTemplate.update(sql, params);
		return true;
	}

	public boolean deleteBodyRule(BodyRuleDTO dto) {
		String sql = "delete from wis.bdy_rule where i_bdy_rule_id = :id";

		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		jdbcTemplate.update(sql, params);

		return true;
	}

	public boolean insertLaunchRule(LaunchRuleDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("lnch_rule");

		Map<String, Object> params = new HashMap<>();

		int maxId = Utility.getMaxId("LAUNCH RULE", jdbcTemplate);
		maxId++;

		params.put("i_lnch_rule_id", maxId);
		params.put("i_mod_yr", dto.getModelYear());
		params.put("c_mkt", dto.getMarket());
		params.put("c_fam", dto.getFamily());
		params.put("c_line", dto.getLine());
		params.put("c_series", dto.getSeries());
		params.put("c_bdy_style", dto.getBodyStyle());
		params.put("i_assy_plt", dto.getAssemblyPlant());
		params.put("c_scode_pat", dto.getSalesCode());
		params.put("d_vhcl_lnch", Utility.toDate(dto.getLaunchDate()));
		params.put("d_eff_strt", Utility.toDate(dto.getEffectiveStart()));
		params.put("d_eff_end", Utility.toDate(dto.getEffectiveEnd()));
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		params.put("x_desc", dto.getDescription());
		params.put("i_corploc", dto.getCorpLoc());

		jdbcInsert.execute(params);

		return true;
	}

	public boolean updateLaunchRule(LaunchRuleDTO dto) {
		// T6245PS: Remove x_rule_description column as snowflake database doesn't have
		// this column
		/*
		 * String sql =
		 * "update wis.lnch_rule set i_mod_yr = :my, c_mkt = :mkt, c_fam = :fam," +
		 * "c_line = :line, c_series = :series, c_bdy_style = :bdyStyle, " +
		 * "i_assy_plt = :assy, c_scode_pat = :scode, d_vhcl_lnch = :launch," +
		 * "d_eff_strt = :effStart, d_eff_end = :effEnd, i_logon = :user, x_rule_description = :desc,"
		 * +
		 * "i_corploc = :loc, t_stmp_upd = current_timestamp where i_lnch_rule_id = :id"
		 * ;
		 */

		String sql = "update wis.lnch_rule set i_mod_yr = :my, c_mkt = :mkt, c_fam = :fam,"
				+ "c_line = :line, c_series = :series, c_bdy_style = :bdyStyle, "
				+ "i_assy_plt = :assy, c_scode_pat = :scode, d_vhcl_lnch = :launch,"
				+ "d_eff_strt = :effStart, d_eff_end = :effEnd, i_logon = :user,"
				+ "i_corploc = :loc, t_stmp_upd = current_timestamp where i_lnch_rule_id = :id";

		Map<String, Object> params = new HashMap<>();

		params.put("my", dto.getModelYear());
		params.put("mkt", dto.getMarket());
		params.put("fam", dto.getFamily());
		params.put("line", dto.getLine());
		params.put("series", dto.getSeries());
		params.put("bdyStyle", dto.getBodyStyle());
		params.put("assy", dto.getAssemblyPlant());
		params.put("scode", dto.getSalesCode());
		params.put("launch", Utility.toDate(dto.getLaunchDate()));
		params.put("effStart", Utility.toDate(dto.getEffectiveStart()));
		params.put("effEnd", Utility.toDate(dto.getEffectiveEnd()));
		params.put("user", auth.getLoggedInUser().getUserId());
		// params.put("desc", dto.getDescription());
		params.put("loc", dto.getCorpLoc());
		params.put("id", dto.getId());

		jdbcTemplate.update(sql, params);
		return true;
	}

	public boolean deleteLaunchRule(LaunchRuleDTO dto) {
		String sql = "delete from wis.lnch_rule where i_lnch_rule_id = :id";

		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());

		jdbcTemplate.update(sql, params);
		return true;
	}

	/*
	 * public boolean copyModelYears(String copyFrom, String copyTo) { String sql =
	 * "select * from wis.bdy_rule where i_mod_yr = :my"; Map<String, Object> params
	 * = new HashMap<>(); params.put("my", copyFrom); List<BodyRuleDTO> dtoList =
	 * jdbcTemplate.query(sql, params, new BodyRuleDTOMapper()); for (BodyRuleDTO
	 * dto : dtoList) { dto.setModelYear(copyTo);
	 * dto.setUser(auth.getLoggedInUser().getUserId()); insertBodyRule(dto);
	 * 
	 * }
	 * 
	 * return true; }
	 */

	public boolean copyModelYears(String copyFrom, String copyTo) {
		String sql = "select * from wis.bdy_rule where i_mod_yr = :my";
		Map<String, Object> selectParams = new HashMap<>();
		selectParams.put("my", copyFrom);
		List<BodyRuleDTO> dtoList = jdbcTemplate.query(sql, selectParams, new BodyRuleDTOMapper());

		String insertSql = "insert into wis.bdy_rule(i_bdy_rule_id, i_mod_yr,c_fam,c_line,c_series,c_bdy_style,i_assy_plt,c_scode_pat,c_prod_line,c_wis_prc_cls,c_wis_bdy_style,l_block,d_eff_strt,d_eff_end,i_logon,t_stmp_upd,c_platform,i_corploc) "
				+ "values (:id,:modelYear,:family,:line,:series,:bodyStyle,:assemblyPlant,:salesCodes,:productLine,:classCode,:wisBodyStyle,:block,:effectiveStartDate,:effectiveEndDate,:user,:updateTimestamp,:platform,:corpLoc)";

		int maxId = Utility.getMaxId("BODY RULE", jdbcTemplate);
		for (BodyRuleDTO dto : dtoList) {
			maxId++;
			dto.setId(maxId);
			dto.setModelYear(copyTo);
			dto.setUser(auth.getLoggedInUser().getUserId());
			dto.setWisBodyStyle(null);
			dto.setClassCode(null);
			dto.setEffectiveStartDate(Utility.toDate(dto.getEffectiveStart()));
			dto.setEffectiveEndDate(Utility.toDate(dto.getEffectiveEnd()));
			dto.setUpdateTimestamp(new Timestamp(System.currentTimeMillis()));

		}

		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(dtoList.toArray());
		jdbcTemplate.batchUpdate(insertSql, batch);
		System.out.println("Copied model years data successfully");
		return true;
	}

	public boolean insertProductLine(ProductLineDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("pl_desc");
		Map<String, Object> params = new HashMap<>();

		params.put("c_pl", dto.getProductLine());
		params.put("x_pl", dto.getDescription());
		params.put("c_lop_book", dto.getLopBook());
		params.put("c_pltfrm", dto.getPlatform());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));

		jdbcInsert.execute(params);
		return true;
	}

	public boolean updateProductLine(ProductLineDTO dto) {
		String sql = "update wis.pl_desc set c_pl = :pl, x_pl = :desc, c_lop_book = :lop,"
				+ "c_pltfrm = :platform, i_logon = :user, t_stmp_upd = current_timestamp "
				+ "where c_pl = :oldPl and c_pltfrm = :oldPlatform";

		Map<String, Object> params = new HashMap<>();

		params.put("pl", dto.getProductLine());
		params.put("desc", dto.getDescription());
		params.put("lop", dto.getLopBook());
		params.put("platform", dto.getPlatform());
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldPl", dto.getOldProductLine());
		params.put("oldPlatform", dto.getOldPlatform());

		jdbcTemplate.update(sql, params);

		return true;
	}

	public boolean deleteProductLine(ProductLineDTO dto) {
		String sql = "delete from wis.pl_desc where c_pl = :pl and c_pltfrm = :platform";

		Map<String, Object> params = new HashMap<>();
		params.put("pl", dto.getProductLine());
		params.put("platform", dto.getPlatform());

		jdbcTemplate.update(sql, params);
		return true;
	}

	public boolean insertPlatformDesc(PlatformDescDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("pltfrm_desc");

		Map<String, Object> params = new HashMap<>();
		params.put("c_pltfrm", dto.getPlatform());
		params.put("x_pltfrm", dto.getDescription());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));

		jdbcInsert.execute(params);
		return true;
	}

	public boolean updatePlatformDesc(PlatformDescDTO dto) {
		String sql = "update wis.pltfrm_desc set c_pltfrm = :platform, x_pltfrm = :desc,"
				+ "i_logon = :user, t_stmp_upd = current_timestamp where c_pltfrm = :oldPlatform";

		Map<String, Object> params = new HashMap<>();
		params.put("platform", dto.getPlatform());
		params.put("desc", dto.getDescription());
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldPlatform", dto.getOldPlatform());

		jdbcTemplate.update(sql, params);
		return true;
	}

	public boolean deletePlatformDesc(PlatformDescDTO dto) {
		String sql = "delete from wis.pltfrm_desc where c_pltfrm = :platform";

		Map<String, Object> params = new HashMap<>();
		params.put("platform", dto.getPlatform());

		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public List<PriceClassDescDTO> getPriceClassDesc() {
		String sql = "select * from wis.pc_desc";
		List<PriceClassDescDTO> dtoList = jdbcTemplate.query(sql, new PriceClassDescDTOMapper());
		return dtoList;
	}

	@Override
	public boolean insertPriceClassDesc(PriceClassDescDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("pc_desc");

		Map<String, Object> params = new HashMap<>();
		params.put("c_pc", dto.getPriceClass());
		params.put("x_pc", dto.getPriceClassDesc());
		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean updatePriceClassDesc(PriceClassDescDTO dto) {
		String sql = "update wis.pc_desc set c_pc = :pc, x_pc = :desc where c_pc = :oldPc";

		Map<String, Object> params = new HashMap<>();
		params.put("pc", dto.getPriceClass());
		params.put("desc", dto.getPriceClassDesc());
		params.put("oldPc", dto.getOldPriceClass());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deletePriceClassDesc(PriceClassDescDTO dto) {
		String sql = "delete from wis.pc_desc where c_pc = :pc";

		Map<String, Object> params = new HashMap<>();
		params.put("pc", dto.getPriceClass());
		jdbcTemplate.update(sql, params);
		return true;
	}
}
