package com.snv.ngwisadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.CommodityDirectorDTO;
import com.snv.ngwisadmin.model.QualityManagerDTO;
import com.snv.ngwisadmin.service.QualityService;

@Controller
public class QualityController {
	
	@Autowired
	QualityService service;
	
	@RequestMapping(value = "/get-commodity-director", method = RequestMethod.GET)
	@ResponseBody
	public List<CommodityDirectorDTO> getCommodityDirector() {
		return service.getCommodityDirector();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-commodity-director", method = RequestMethod.POST)
	@ResponseBody
	public List<CommodityDirectorDTO> modifyCommodityDirector(@RequestParam String action, @RequestBody CommodityDirectorDTO dto) {
		return service.modifyCommodityDirector(dto, action);
	}
	
	@RequestMapping(value = "/get-quality-manager", method = RequestMethod.GET)
	@ResponseBody
	public List<QualityManagerDTO> getQualityManager() {
		return service.getQualityManager();
	}
	
	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-quality-manager", method = RequestMethod.POST)
	@ResponseBody
	public List<QualityManagerDTO> modifyQualityManager(@RequestParam String action, @RequestBody QualityManagerDTO dto) {
		return service.modifyQualityManager(dto, action);
	}

}
