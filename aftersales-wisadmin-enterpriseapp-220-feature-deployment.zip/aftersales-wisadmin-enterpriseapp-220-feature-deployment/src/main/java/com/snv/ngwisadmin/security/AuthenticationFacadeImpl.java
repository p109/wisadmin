package com.snv.ngwisadmin.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.UserDTO;

@Service
public class AuthenticationFacadeImpl implements AuthenticationFacade {

	public Authentication getAuthentication() {
		return SecurityContextHolder.getContext().getAuthentication();
	}
	
	public UserDTO getLoggedInUser() {
		//System.out.println("Inside getLoggedInUser");
		Authentication auth = getAuthentication();
		if(auth != null) {
			Object object = auth.getPrincipal();
			if(object instanceof UserDTO) {
				UserDTO appUser = (UserDTO) object;
				return appUser;
			}
		}
		return null;
	}
}
