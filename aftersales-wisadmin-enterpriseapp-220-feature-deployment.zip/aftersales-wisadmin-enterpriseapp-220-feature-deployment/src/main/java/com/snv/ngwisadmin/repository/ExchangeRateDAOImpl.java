package com.snv.ngwisadmin.repository;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.CanadaExchangeDTO;
import com.snv.ngwisadmin.model.ExchangeDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class ExchangeRateDAOImpl implements ExchangeRateDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	DataSource ds;

	@Autowired
	AuthenticationFacade auth;

	public List<CanadaExchangeDTO> getCanadaExchange() {
		String sql = "select * from wis.exchng_rate";
		List<CanadaExchangeDTO> dtoList = jdbcTemplate.query(sql, new CanadaExchangeDTOMapper());
		return dtoList;
	}

	public boolean insertCanadaExchange(CanadaExchangeDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("exchng_rate");

		Map<String, Object> params = new HashMap<>();
		params.put("i_mod_yr", dto.getModelYear());
		// C stands for Canada
		params.put("c_mkt", "C");
		params.put("q_exchng_rate", dto.getRate());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));

		jdbcInsert.execute(params);
		return true;
	}

	public boolean updateCanadaExchange(CanadaExchangeDTO dto) {
		String sql = "update wis.exchng_rate set i_mod_yr = :my, q_exchng_rate = :rate, "
				+ "i_logon = :user, t_stmp_upd = current_timestamp where i_mod_yr = :oldMy";

		Map<String, Object> params = new HashMap<>();
		params.put("my", dto.getModelYear());
		params.put("rate", dto.getRate());
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldMy", dto.getOldModelYear());

		jdbcTemplate.update(sql, params);
		return true;
	}

	public boolean deleteCanadaExchange(CanadaExchangeDTO dto) {
		String sql = "delete from wis.exchng_rate where i_mod_yr = :my";

		Map<String, Object> params = new HashMap<>();
		params.put("my", dto.getModelYear());

		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public List<ExchangeDTO> getExchange() {
		String sql = "select * from wis.curr_exchange_rate";
		List<ExchangeDTO> dtoList = jdbcTemplate.query(sql, new ExchangeDTOMapper());
		return dtoList;
	}

	@Override
	public boolean insertExchange(ExchangeDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis")
				.withTableName("curr_exchange_rate");

		Map<String, Object> params = new HashMap<>();
		params.put("curr", dto.getCurr());
		params.put("efctv_dt", Utility.toDate(dto.getEffectiveDate()));
		params.put("peg_rate", dto.getRate());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean updateExchange(ExchangeDTO dto) {
		String sql = "update wis.curr_exchange_rate set curr = :curr,efctv_dt=:date, peg_rate = :rate, "
				+ "i_logon = :user, t_stmp_upd = current_timestamp where curr = :oldCurr and efctv_dt=:oldDate";

		Map<String, Object> params = new HashMap<>();
		params.put("curr", dto.getCurr());
		params.put("date", Utility.toDate(dto.getEffectiveDate()));
		params.put("rate", dto.getRate());
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldCurr", dto.getOldCurr());
		params.put("oldDate", dto.getOldEffectiveDate());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteExchange(ExchangeDTO dto) {
		String sql = "delete from wis.curr_exchange_rate where curr = :curr and efctv_dt=:date";

		Map<String, Object> params = new HashMap<>();
		params.put("curr", dto.getCurr());
		params.put("date", dto.getEffectiveDate());
		jdbcTemplate.update(sql, params);
		return true;
	}
}
