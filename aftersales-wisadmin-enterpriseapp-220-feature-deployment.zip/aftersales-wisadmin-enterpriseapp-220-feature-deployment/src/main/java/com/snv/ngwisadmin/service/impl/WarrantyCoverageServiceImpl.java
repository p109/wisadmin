package com.snv.ngwisadmin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.wcc.ConditionClassDTO;
import com.snv.ngwisadmin.model.wcc.ConditionCoverageDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeClassDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeDTO;
import com.snv.ngwisadmin.model.wcc.CoverageCodeRuleDTO;
import com.snv.ngwisadmin.repository.wcc.WarrantyCoverageDAO;
import com.snv.ngwisadmin.service.WarrantyCoverageService;
import com.snv.ngwisadmin.util.Constants;

@Service
public class WarrantyCoverageServiceImpl implements WarrantyCoverageService {

	@Autowired
	WarrantyCoverageDAO dao;
	
	@Override
	public List<CoverageCodeDTO> getCoverageDesc() {
		return dao.getCoverageDesc();
	}

	@Override
	public List<CoverageCodeDTO> modifyCoverageDesc(CoverageCodeDTO dto,
			String action) {
		if (Constants.INSERT.equals(action))
		{
			dao.insertCoverageDesc(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updateCoverageDesc(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteCoverageDesc(dto);
		}
		return dao.getCoverageDesc();
	}
	
	public List<CoverageCodeRuleDTO> getCoverageRules() {
		return dao.getCoverageRule();
	}
	
	public List<CoverageCodeRuleDTO> modifyCoverageRule(CoverageCodeRuleDTO dto, String action)
	{
		if (Constants.INSERT.equals(action))
		{
			dao.insertCoverageRule(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updateCoverageRule(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteCoverageRule(dto);
		}
		
		return dao.getCoverageRule();
	}
	
	public List<CoverageCodeClassDTO> getCoverageClass() {
		return dao.getCoverageClass();
	}
	
	public List<CoverageCodeClassDTO> modifyCoverageClass(CoverageCodeClassDTO dto, 
			String action)
	{
		if (Constants.INSERT.equals(action))
		{
			dao.insertCoverageClass(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteCoverageClass(dto);
		}
		
		return dao.getCoverageClass();
	}
	
	public List<CoverageCodeClassDTO> updateCoverageClass(List<CoverageCodeClassDTO> dto,
			String action)
	{
		if (Constants.UPDATE.equals(action))
		{
			dao.deleteCoverageClass(dto.get(0));
			dao.insertCoverageClass(dto.get(1));
		}
		
		return dao.getCoverageClass();
	}
	
	public List<ConditionClassDTO> getConditionClass() {
		return dao.getConditionClass();
	}

	public List<ConditionCoverageDTO> getConditionCoverage() {
		return dao.getConditionCoverage();
	}
	
	public List<ConditionClassDTO> modifyConditionClass(ConditionClassDTO dto, String action)
	{
		if (Constants.INSERT.equals(action))
		{
			dao.insertConditionClass(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updateConditionClass(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteConditionClass(dto);
		}
		return dao.getConditionClass();
	}
}
