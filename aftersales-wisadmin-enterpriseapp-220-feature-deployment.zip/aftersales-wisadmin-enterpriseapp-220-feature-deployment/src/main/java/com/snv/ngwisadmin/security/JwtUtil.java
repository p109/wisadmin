package com.snv.ngwisadmin.security;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import com.snv.ngwisadmin.model.ALBTokenPayload;

@Component
public class JwtUtil {

	private String jwtPublicKeyUrl = "https://public-keys.auth.elb.us-east-1.amazonaws.com/";
	
	byte[] secret=null;
	private ConfigurableJWTProcessor<SecurityContext> jwtProcessor;
	private final RestOperationsResourceRetriever jwkSetRetriever = new RestOperationsResourceRetriever();
	
	private void configureJWTProcessor() throws MalformedURLException {
		this.jwtProcessor = new DefaultJWTProcessor<>();
		JWKSource<SecurityContext> jwkSource = new RemoteJWKSet<>(new URL(jwtPublicKeyUrl), this.jwkSetRetriever);
		JWSAlgorithm jWSAlgorithm = JWSAlgorithm.parse(JWSAlgorithm.ES256.toString());
		JWSKeySelector<SecurityContext> jwsKeySelector = new ALBKeySelector<>(jWSAlgorithm,jwkSource);
		this.jwtProcessor.setJWSKeySelector(jwsKeySelector);
	}
	
	public ALBTokenPayload decode(String token) {
		ALBTokenPayload payload = new ALBTokenPayload();
		try {
			
			this.configureJWTProcessor();
			JWTClaimsSet claims = jwtProcessor.process(token, null);
			Map<String, Object> claimMap = claims.getClaims();
			for (String claim : claimMap.keySet())
			{
				System.out.println("Key: " + claim);
			}
			payload.setUserId((String) claims.getClaim("sub"));
			payload.setUserType((String) claims.getClaim("user_type"));
			payload.setExpiration((Date) claims.getClaim("exp"));
			
		} catch (ParseException | BadJOSEException | JOSEException e) {
			System.err.println("Error Occured while decoding JWT token : " + e.getMessage()); 
		} catch (MalformedURLException e) {
			System.err.println("MalformedURLException while decoding JWT token : " + e.getMessage());
		}
		
		return payload;
	}
}
