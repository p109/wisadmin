package com.snv.ngwisadmin.model.workflow;

import java.util.List;

public class WorkflowInformation {

	List<WorkflowApprovalDTO> approvedList;
	List<WorkflowRequestDTO> requestList;
	List<WorkflowStepDTO> stepList;
	public List<WorkflowApprovalDTO> getApprovedList() {
		return approvedList;
	}
	public void setApprovedList(List<WorkflowApprovalDTO> approvedList) {
		this.approvedList = approvedList;
	}
	public List<WorkflowRequestDTO> getRequestList() {
		return requestList;
	}
	public void setRequestList(List<WorkflowRequestDTO> requestList) {
		this.requestList = requestList;
	}
	public List<WorkflowStepDTO> getStepList() {
		return stepList;
	}
	public void setStepList(List<WorkflowStepDTO> stepList) {
		this.stepList = stepList;
	}
	
	
}
