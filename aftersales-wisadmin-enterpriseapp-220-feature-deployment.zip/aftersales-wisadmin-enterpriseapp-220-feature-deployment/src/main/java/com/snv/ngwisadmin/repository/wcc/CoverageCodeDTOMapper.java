package com.snv.ngwisadmin.repository.wcc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.wcc.CoverageCodeDTO;

public class CoverageCodeDTOMapper implements RowMapper<CoverageCodeDTO> {

	public CoverageCodeDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		CoverageCodeDTO dto = new CoverageCodeDTO();
		dto.setWcc(rs.getString("C_WCC"));
		dto.setWccDesc(rs.getString("X_WCC"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
