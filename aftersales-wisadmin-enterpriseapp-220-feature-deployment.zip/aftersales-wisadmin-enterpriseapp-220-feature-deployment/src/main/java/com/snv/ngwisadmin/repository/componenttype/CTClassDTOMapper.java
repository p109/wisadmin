package com.snv.ngwisadmin.repository.componenttype;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.componenttype.CTClassDTO;

public class CTClassDTOMapper implements RowMapper<CTClassDTO> {

	boolean fullData;
	
	@Override
	public CTClassDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		CTClassDTO dto = new CTClassDTO();
		dto.setCtClass(rs.getString("C_CT_CLASS"));
		dto.setClassDesc(rs.getString("X_CT_CLASS").trim());
		
		if (fullData)
		{
			dto.setUser(rs.getString("I_LOGON"));
			dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		}
		return dto;
	}
	
	public CTClassDTOMapper(boolean fullData) {
		super();
		this.fullData = fullData;
	}
}
