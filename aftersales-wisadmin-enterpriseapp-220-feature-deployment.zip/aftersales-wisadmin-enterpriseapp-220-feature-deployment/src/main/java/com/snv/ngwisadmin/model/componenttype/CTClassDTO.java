package com.snv.ngwisadmin.model.componenttype;

import javax.validation.constraints.NotEmpty;

public class CTClassDTO {

	@NotEmpty(message = "CT Class can not be empty")
	private String ctClass;
	@NotEmpty(message = "Class Description can not be empty")
	private String classDesc;
	private String user;
	private String updateTime;

	public CTClassDTO() {
		ctClass = "";
		classDesc = "";
		user = "";
		updateTime = "";
	}

	public CTClassDTO(String ctClass, String classDesc, String user, String updateTime) {
		this.ctClass = ctClass;
		this.classDesc = classDesc;
		this.user = user;
		this.updateTime = updateTime;
	}

	public String getCtClass() {
		return ctClass;
	}

	public void setCtClass(String ctClass) {
		this.ctClass = ctClass;
	}

	public String getClassDesc() {
		return classDesc;
	}

	public void setClassDesc(String classDesc) {
		this.classDesc = classDesc;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
}
