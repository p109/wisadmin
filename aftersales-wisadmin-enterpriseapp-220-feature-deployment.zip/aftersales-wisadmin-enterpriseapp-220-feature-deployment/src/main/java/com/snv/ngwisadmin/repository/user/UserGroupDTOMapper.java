package com.snv.ngwisadmin.repository.user;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.UserGroupDTO;

public class UserGroupDTOMapper implements RowMapper<UserGroupDTO> {

	public UserGroupDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		UserGroupDTO dto = new UserGroupDTO();
		dto.setGroupName(rs.getString("N_GROUP"));
		dto.setGroupDesc(rs.getString("X_GROUP"));
		return dto;
	}
}
