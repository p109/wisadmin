package com.snv.ngwisadmin.repository;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.BatchScheduleDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Utility;


@Repository
public class BatchScheduleDAOImpl implements BatchScheduleDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	DataSource ds;
	
	@Autowired
	AuthenticationFacade auth;
	
	public List<BatchScheduleDTO> getBatchSchedule()
	{
		String sql = "select * from wis.run_mth";
		List<BatchScheduleDTO> dtoList = jdbcTemplate.query(sql, new BatchScheduleDTOMapper());
		return dtoList;
	}
	
	public boolean insertBatchSchedule(BatchScheduleDTO dto)
	{
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("run_mth");
		Map<String, Object> params = new HashMap<>();
		
		params.put("i_mod_yr", dto.getModelYear());
		params.put("i_report_mis", dto.getMis());
		params.put("d_cond_cutoff", Utility.toDate(dto.getConditionCutoff()));
		params.put("d_sale_cutoff", Utility.toDate(dto.getSalesCutoff()));
		params.put("d_schd_load", Utility.toDate(dto.getBatchStart()));
		params.put("d_user_notify", Utility.toDate(dto.getUserAccess()));
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		
		jdbcInsert.execute(params);
		return true;
	}
	
	public boolean updateBatchSchedule(BatchScheduleDTO dto)
	{
		String sql = "update wis.run_mth set i_mod_yr = :my, i_report_mis = :mis, "
				+ "d_cond_cutoff = :cond, d_sale_cutoff = :sale, d_schd_load = :load,"
				+ "d_user_notify = :access, i_logon = :user, t_stmp_upd = current_timestamp"
				+ " where i_mod_yr = :oldMy and i_report_mis = :oldMis";
		
		Map<String, Object> params = new HashMap<>();
		params.put("my", dto.getModelYear());
		params.put("mis", dto.getMis());
		params.put("cond", Utility.toDate(dto.getConditionCutoff()));
		params.put("sale", Utility.toDate(dto.getSalesCutoff()));
		params.put("load", Utility.toDate(dto.getBatchStart()));
		params.put("access", Utility.toDate(dto.getUserAccess()));
		params.put("user", auth.getLoggedInUser().getUserId());
		params.put("oldMy", dto.getOldModelYear());
		params.put("oldMis", dto.getOldMis());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean deleteBatchSchedule(BatchScheduleDTO dto)
	{
		String sql = "delete from wis.run_mth where i_mod_yr = :my and i_report_mis = :mis";
		
		Map<String, Object> params = new HashMap<>();
		params.put("my", dto.getModelYear());
		params.put("mis", dto.getMis());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
}
