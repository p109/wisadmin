package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.LdapUserDTO;
import com.snv.ngwisadmin.model.UserGroupDTO;
import com.snv.ngwisadmin.model.UserMembershipDTO;

public interface UserMaintenanceService {

	public List<UserGroupDTO> getUserGroup();
	
	public List<UserMembershipDTO> getUserMembership(String id);
	
	public boolean updateUserMembership(List<UserMembershipDTO> userGroups);
	
	public LdapUserDTO getUserDetails(String id);
}
