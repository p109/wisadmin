package com.snv.ngwisadmin.repository.quality;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.CommodityDirectorDTO;
import com.snv.ngwisadmin.model.QualityManagerDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;

@Repository
public class QualityDAOImpl implements QualityDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	DataSource ds;
	
	@Autowired
	AuthenticationFacade auth;

	@Override
	public List<CommodityDirectorDTO> getCommodityDirector() {
		String sql = "select * from wis.cd_desc";
		List<CommodityDirectorDTO> dtoList = jdbcTemplate.query(sql, new CommodityDirectorDTOMapper());
		return dtoList;
	}

	@Override
	public boolean insertCommodityDirector(CommodityDirectorDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("cd_desc");
		Map<String, Object> params = new HashMap<>();
		params.put("c_cd", dto.getId());
		params.put("x_cd", dto.getDirectorName());
		params.put("c_cd_typ", dto.getDirectorType());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean updateCommodityDirector(CommodityDirectorDTO dto) {
		String sql = "update wis.cd_desc set c_cd = :id, x_cd = :name,c_cd_typ = :type where c_cd = :oldId";
		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		params.put("name", dto.getDirectorName());
		params.put("type", dto.getDirectorType());
		params.put("oldId", dto.getOldId());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteCommodityDirector(CommodityDirectorDTO dto) {
		String sql = "delete from wis.cd_desc where c_cd = :id";
		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public List<QualityManagerDTO> getQualityManager() {
		String sql = "select * from wis.qm_desc";
		List<QualityManagerDTO> dtoList = jdbcTemplate.query(sql, new QualityManagerDTOMapper());
		return dtoList;
	}

	@Override
	public boolean insertQualityManager(QualityManagerDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("qm_desc");
		Map<String, Object> params = new HashMap<>();
		params.put("c_qual_mgr", dto.getQualityManager());
		params.put("x_qual_mgr", dto.getQualityManagerDescription());
		params.put("c_cd", dto.getCommodityDirector());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean updateQualityManager(QualityManagerDTO dto) {
		String sql = "update wis.qm_desc set c_qual_mgr = :manager, x_qual_mgr = :desc,c_cd = :commodityDir where c_qual_mgr = :oldManager";
		Map<String, Object> params = new HashMap<>();
		params.put("manager", dto.getQualityManager());
		params.put("desc", dto.getQualityManagerDescription());
		params.put("commodityDir", dto.getCommodityDirector());
		params.put("oldManager", dto.getOldManager());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteQualityManager(QualityManagerDTO dto) {
		String sql = "delete from wis.qm_desc where c_qual_mgr = :manager";
		Map<String, Object> params = new HashMap<>();
		params.put("manager", dto.getQualityManager());
		jdbcTemplate.update(sql, params);
		return true;
	}

}
