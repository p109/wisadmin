package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.PlantCodeDTO;
import com.snv.ngwisadmin.model.PlantDTO;

public interface PlantService {
	
	public List<PlantDTO> getPlantDesc(String type);
	
	public List<PlantCodeDTO> getPlantCodes(String type);
	
	public List<PlantDTO> insertPlantDesc(String type, PlantDTO dto);
	
	public List<PlantDTO> updatePlantDesc(String type, List<PlantDTO> dtoList);
	
	public List<PlantDTO> deletePlantDesc(String type, PlantDTO dto);
	
	public List<PlantCodeDTO> insertPlantCode(String type, PlantCodeDTO dto);
	
	public List<PlantCodeDTO> updatePlantCode(String type, List<PlantCodeDTO> dtoList);
	
	public List<PlantCodeDTO> deletePlantCode(String type, PlantCodeDTO dto);
	
}
