package com.snv.ngwisadmin.security;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.web.authentication.preauth.RequestHeaderAuthenticationFilter;

import com.snv.ngwisadmin.util.Constants;

public class RequestHeaderFilter extends RequestHeaderAuthenticationFilter{

	public RequestHeaderFilter(String tokenName) {
		super.setPrincipalRequestHeader(tokenName);
		super.setExceptionIfHeaderMissing(false);
	}
	
	@Override
	protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
		
		System.out.println("Getting pre authentication");
		System.out.println(request.getRequestURI());
		Object token = super.getPreAuthenticatedPrincipal(request);
		
		if(token instanceof String) {
			return ((String) token).trim();
		}
		return Constants.TOKEN_NOT_FOUND;
	}
}
