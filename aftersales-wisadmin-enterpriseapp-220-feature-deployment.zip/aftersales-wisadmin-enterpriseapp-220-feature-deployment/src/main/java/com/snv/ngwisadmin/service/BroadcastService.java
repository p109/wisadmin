package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.broadcast.BroadcastMessageDTO;
import com.snv.ngwisadmin.model.broadcast.BroadcastMessageMap;
import com.snv.ngwisadmin.model.broadcast.BroadcastTypeDTO;

public interface BroadcastService {

	public List<BroadcastTypeDTO> getBroadcastType(String type);
	
	public List<BroadcastMessageDTO> getBroadcastMessage();
	
	public List<BroadcastTypeDTO> modifyBroadcastType(BroadcastTypeDTO dto, String type, String action);
	
	public List<BroadcastMessageDTO> modifyBroadcastMessage(BroadcastMessageDTO dto, String action);

	public BroadcastMessageMap getInputParametersForBroadcastMessage();
}
