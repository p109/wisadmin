package com.snv.ngwisadmin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;











import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.snv.ngwisadmin.repository.BatchScheduleDAO;
import com.snv.ngwisadmin.service.ScheduleService;
import com.snv.ngwisadmin.util.Constants;
import com.snv.ngwisadmin.model.BatchScheduleDTO;



@Service
public class ScheduleServiceImpl implements ScheduleService {

	@Autowired
	BatchScheduleDAO dao;
	
	public List<BatchScheduleDTO> getBatchSchedule()
	{
		/*
		 * AmazonSQS sqs =
		 * AmazonSQSClientBuilder.standard().withRegion("us-east-1").build();
		 * //BasicAWSCredentials creds = new BasicAWSCredentials();
		 * 
		 * SendMessageRequest send_msg_request = new SendMessageRequest() .withQueueUrl(
		 * "https://sqs.us-east-1.amazonaws.com/946714343468/awseb-e-hvttxq6pwh-stack-AWSEBWorkerQueue-1DSPSHDXYT2Z2")
		 * .withMessageBody("hello world") .withDelaySeconds(5);
		 * sqs.sendMessage(send_msg_request);
		 * 
		 * List<Message> messages = sqs.receiveMessage(
		 * "https://sqs.us-east-1.amazonaws.com/946714343468/awseb-e-hvttxq6pwh-stack-AWSEBWorkerQueue-1DSPSHDXYT2Z2"
		 * ).getMessages(); System.out.println("Message length: " + messages.size());
		 * for (Message message : messages) { System.out.println(message.getBody()); }
		 */
		
		return dao.getBatchSchedule();
	}
	
	public List<BatchScheduleDTO> modifyBatchSchedule(BatchScheduleDTO dto, String action)
	{
		if (Constants.INSERT.equals(action))
		{
			dao.insertBatchSchedule(dto);
		}
		if (Constants.UPDATE.equals(action))
		{
			dao.updateBatchSchedule(dto);
		}
		if (Constants.DELETE.equals(action))
		{
			dao.deleteBatchSchedule(dto);
		}
		
		return dao.getBatchSchedule();
	}
}
