package com.snv.ngwisadmin.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

import com.snv.ngwisadmin.util.Constants;

public class DefaultAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler{

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
		String message = exception.getMessage();
		if(message != null) {
			switch(message) {
			case Constants.TOKEN_NOT_FOUND: 
				Cookie albCookie = new Cookie("AWSELBAuthSessionCookie-0", "-1");
				// Setting Cookie Max Age to -1, to get it deleted from browser.
				albCookie.setMaxAge(0);
				response.addCookie(albCookie);
				response.sendError(HttpStatus.GATEWAY_TIMEOUT.value(), "Token is not present");
				break;
			case Constants.USER_NOT_FOUND:
				response.sendError(HttpStatus.NETWORK_AUTHENTICATION_REQUIRED.value(), "User is not present");
				break;
			default: 
				response.sendError(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Server error");
			}
		}
	}
}
