package com.snv.ngwisadmin.security;

import java.io.IOException;
import java.net.URL;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Collections;
import java.util.List;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.KeySourceException;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jose.util.Base64;
import com.nimbusds.jose.util.Resource;

public class ALBKeySelector<S extends SecurityContext> extends JWSVerificationKeySelector<S> {

	private final RemoteJWKSet<S> jwkset;
	private final String baseURL;
	
	private static final String PUBLIC_KEY_START = "-----BEGIN PUBLIC KEY-----";
	private static final String PUBLIC_KEY_END = "-----END PUBLIC KEY-----";
	
	public ALBKeySelector(JWSAlgorithm jwsAlg, JWKSource<S> jwkSource) {
		super(jwsAlg, jwkSource);
		this.jwkset = (RemoteJWKSet<S>)jwkSource;
		this.baseURL = jwkset.getJWKSetURL().toString();
	}
	
	//getExpectedJWSAlgorithm is deprecated and I found nothing on a google search
	
	@SuppressWarnings("deprecation")
	public List<Key> selectJWSKeys(JWSHeader jwsHeader, S context) throws KeySourceException {
		
		if(!getExpectedJWSAlgorithm().equals(jwsHeader.getAlgorithm())) {
			return Collections.emptyList();
		}
		
		String kid = jwsHeader.getKeyID();
		Resource rawPublicKey = null;
		
		try {
			rawPublicKey = jwkset.getResourceRetriever().retrieveResource(new URL(baseURL + kid));
			
		} catch (IOException e) {
			System.err.println("Error occured in ALBKeySelector: " + e.getMessage());
			return Collections.emptyList();
		}
		
		return Collections.singletonList(parse(rawPublicKey.getContent()));
	}
	
	private static ECPublicKey parse(final String pemEncodedCert) {

		if (pemEncodedCert == null || pemEncodedCert.isEmpty()) {
			return null;
		}

		final int markerStart = pemEncodedCert.indexOf(PUBLIC_KEY_START);

		if (markerStart < 0) {
			return null;
		}

		String buf = pemEncodedCert.substring(markerStart + PUBLIC_KEY_START.length());

		final int markerEnd = buf.indexOf(PUBLIC_KEY_END);

		if (markerEnd < 0) {
			return null;
		}

		buf = buf.substring(0, markerEnd);

		buf = buf.replaceAll("\\s", "");

		return parse(new Base64(buf).decode());
	}
	
	private static ECPublicKey parse(final byte[] derEncodedCert) {

		if (derEncodedCert == null || derEncodedCert.length == 0) {
			return null;
		}

		final PublicKey key;
		try {
			X509EncodedKeySpec spec = new X509EncodedKeySpec(derEncodedCert);
			KeyFactory kf = KeyFactory.getInstance("EC");
			key = kf.generatePublic(spec);
		} catch (NoSuchAlgorithmException|InvalidKeySpecException e) {
			return null;
		}

		if (! (key instanceof ECPublicKey)) {
			return null;
		}

		return (ECPublicKey)key;
	}
}
