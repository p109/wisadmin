package com.snv.ngwisadmin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.SmartValidator;

import com.snv.ngwisadmin.model.BlockRuleDTO;

public class InputValidator {

	@Autowired
	static
	SmartValidator validator;
	
	public static boolean validateBlockRule(BlockRuleDTO dto)
	{
		//BindingResult result = ;
		//validator.validate(dto, result, BlockRuleDTO.class);
		return true;
	}
}
