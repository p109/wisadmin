package com.snv.ngwisadmin.repository.body;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.PriceClassDescDTO;

public class PriceClassDescDTOMapper implements RowMapper<PriceClassDescDTO> {

	@Override
	public PriceClassDescDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		PriceClassDescDTO dto = new PriceClassDescDTO();
		dto.setPriceClass(rs.getString("C_PC"));
		dto.setPriceClassDesc(rs.getString("X_PC"));
		return dto;
	}

}
