package com.snv.ngwisadmin.repository.plant;

import java.util.List;

import com.snv.ngwisadmin.model.PlantCodeDTO;
import com.snv.ngwisadmin.model.PlantDTO;

public interface PlantMaintenanceDAO {
	
	public List<PlantDTO> getPlantDesc(String type);
	
	public List<PlantCodeDTO> getPlantCodes(String type);
	
	public boolean insertPlantDesc(String type, PlantDTO dto);
	
	public boolean updatePlantDesc(String type, List<PlantDTO> dtoList);
	
	public boolean deletePlantDesc(String type, PlantDTO dto);
	
	public boolean insertPlantCode(String type, PlantCodeDTO dto);
	
	public boolean updatePlantCode(String type, List<PlantCodeDTO> dto);
	
	public boolean deletePlantCode(String type, PlantCodeDTO dto);
}
