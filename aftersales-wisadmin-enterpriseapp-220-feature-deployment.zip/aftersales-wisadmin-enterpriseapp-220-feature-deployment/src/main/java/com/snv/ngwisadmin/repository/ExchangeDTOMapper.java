package com.snv.ngwisadmin.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.ExchangeDTO;
import com.snv.ngwisadmin.util.Utility;

public class ExchangeDTOMapper implements RowMapper<ExchangeDTO> {

	@Override
	public ExchangeDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ExchangeDTO exchangeDto = new ExchangeDTO();
		exchangeDto.setCurr(rs.getString("CURR"));
		exchangeDto.setEffectiveDate(Utility.checkNull(rs.getDate("EFCTV_DT")));
		exchangeDto.setRate(rs.getFloat("PEG_RATE"));
		exchangeDto.setUser(rs.getString("I_LOGON"));
		exchangeDto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		return exchangeDto;
	}

}
