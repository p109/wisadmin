package com.snv.ngwisadmin.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class LaunchRuleDTO {

	// Int so can't apply empty or null check.In db it is non-nullable
	int id;
	@NotEmpty(message = "Model Year can not be empty")
	String modelYear;
	@NotEmpty(message = "Market can not be empty")
	String market;
	@NotEmpty(message = "Family can not be empty")
	String family;
	@NotEmpty(message = "Line can not be empty")
	String line;
	@NotEmpty(message = "Series can not be empty")
	String series;
	@NotEmpty(message = "Body Style can not be empty")
	String bodyStyle;
	@NotEmpty(message = "Asssembly Plant can not be empty")
	String assemblyPlant;
	@NotNull(message = "Sales Code can not be empty")
	String salesCode;
	@NotEmpty(message = "Launch Code can not be empty")
	String launchDate;
	@NotEmpty(message = "Effective Start Date can not be empty")
	String effectiveStart;
	String effectiveEnd;

	String user;
	String updateTime;
	@NotEmpty(message = "Corp Loc can not be empty")
	String corpLoc;
	String description;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getBodyStyle() {
		return bodyStyle;
	}

	public void setBodyStyle(String bodyStyle) {
		this.bodyStyle = bodyStyle;
	}

	public String getAssemblyPlant() {
		return assemblyPlant;
	}

	public void setAssemblyPlant(String assemblyPlant) {
		this.assemblyPlant = assemblyPlant;
	}

	public String getSalesCode() {
		return salesCode;
	}

	public void setSalesCode(String salesCode) {
		this.salesCode = salesCode;
	}

	public String getLaunchDate() {
		return launchDate;
	}

	public void setLaunchDate(String launchDate) {
		this.launchDate = launchDate;
	}

	public String getEffectiveStart() {
		return effectiveStart;
	}

	public void setEffectiveStart(String effectiveStart) {
		this.effectiveStart = effectiveStart;
	}

	public String getEffectiveEnd() {
		return effectiveEnd;
	}

	public void setEffectiveEnd(String effectiveEnd) {
		this.effectiveEnd = effectiveEnd;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getCorpLoc() {
		return corpLoc;
	}

	public void setCorpLoc(String corpLoc) {
		this.corpLoc = corpLoc;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
