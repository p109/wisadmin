package com.snv.ngwisadmin.repository;

import java.util.List;

import com.snv.ngwisadmin.model.BlockRuleDTO;

public interface BlockRuleDAO {

	public List<BlockRuleDTO> getBlockRules();
	
	public boolean insertBlockRule(BlockRuleDTO dto);
	
	public boolean updateBlockRule(List<BlockRuleDTO> dtoList);
	
	public boolean deleteBlockRule(BlockRuleDTO dto);
}
