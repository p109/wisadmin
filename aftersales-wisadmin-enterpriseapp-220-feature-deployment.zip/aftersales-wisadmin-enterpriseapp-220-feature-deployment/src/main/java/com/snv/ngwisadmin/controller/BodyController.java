package com.snv.ngwisadmin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.snv.ngwisadmin.model.BodyRuleDTO;
import com.snv.ngwisadmin.model.LaunchRuleDTO;
import com.snv.ngwisadmin.model.PlatformDescDTO;
import com.snv.ngwisadmin.model.PriceClassDescDTO;
import com.snv.ngwisadmin.model.ProductLineDTO;
import com.snv.ngwisadmin.service.BodyService;

@Controller
public class BodyController {

	@Autowired
	BodyService service;

	@RequestMapping(value = "/get-body-rules", method = RequestMethod.GET)
	@ResponseBody
	public List<BodyRuleDTO> getBodyRules() {
		return service.getBodyRules();
	}

	@RequestMapping(value = "/get-launch-rules", method = RequestMethod.GET)
	@ResponseBody
	public List<LaunchRuleDTO> getLaunchRules() {
		return service.getLaunchRules();
	}

	@RequestMapping(value = "/get-platform-desc", method = RequestMethod.GET)
	@ResponseBody
	public List<PlatformDescDTO> getPlatformDesc() {
		return service.getPlatformDesc();
	}

	@RequestMapping(value = "/get-product-desc", method = RequestMethod.GET)
	@ResponseBody
	public List<ProductLineDTO> getProductLine() {
		return service.getProductLine();
	}

	@RequestMapping(value = "/get-price-class-desc", method = RequestMethod.GET)
	@ResponseBody
	public List<PriceClassDescDTO> getPriceClassDesc() {
		return service.getPriceClassDesc();
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-body-rules", method = RequestMethod.POST)
	@ResponseBody
	public List<BodyRuleDTO> modifyBodyRules(@RequestParam String action, @RequestBody BodyRuleDTO dto) {
		return service.modifyBodyRules(dto, action);
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-launch-rules", method = RequestMethod.POST)
	@ResponseBody
	public List<LaunchRuleDTO> modifyLaunchRules(@RequestParam String action, @RequestBody LaunchRuleDTO dto) {
		return service.modifyLaunchRules(dto, action);
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/launch-mass-copy", method = RequestMethod.POST)
	@ResponseBody
	public List<BodyRuleDTO> copyBodyRules(@RequestBody Map<String, String> copyMap) {
		return service.copyBodyRules(copyMap.get("copyFrom"), copyMap.get("copyTo"));
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-product-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<ProductLineDTO> modifyProductDesc(@RequestBody ProductLineDTO dto, @RequestParam String action) {
		return service.modifyProductLine(dto, action);
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-platform-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<PlatformDescDTO> modifyPlatformDesc(@RequestBody PlatformDescDTO dto, @RequestParam String action) {
		return service.modifyPlatformDesc(dto, action);
	}

	@PreAuthorize("hasAnyAuthority('ROLE_RULE_ADMIN', 'ROLE_SUPER_ADMIN')")
	@RequestMapping(value = "/modify-price-class-desc", method = RequestMethod.POST)
	@ResponseBody
	public List<PriceClassDescDTO> modifyPriceClassDesc(@RequestBody PriceClassDescDTO dto,
			@RequestParam String action) {
		return service.modifyPriceClassDesc(dto, action);
	}
}
