package com.snv.ngwisadmin.repository.componenttype;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.componenttype.CTDescDTO;

public class CTDescDTOMapper implements RowMapper<CTDescDTO> {


	@Override
	public CTDescDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		CTDescDTO dto = new CTDescDTO();
		dto.setCt(rs.getString("C_CT"));
		dto.setCtDesc(rs.getString("X_CT").trim());
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		return dto;
	}
}
