package com.snv.ngwisadmin.security;

import java.io.IOException;
import java.net.URL;
import java.util.Collections;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

import com.nimbusds.jose.util.Resource;
import com.nimbusds.jose.util.ResourceRetriever;

public class RestOperationsResourceRetriever implements ResourceRetriever {

	private RestOperations restOperations = new RestTemplate();

	@Override
	public Resource retrieveResource(URL url) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		ResponseEntity<String> response;
		try {
			RequestEntity<Void> request = new RequestEntity<>(headers, HttpMethod.GET, url.toURI());
			response = this.restOperations.exchange(request, String.class);
		} catch (Exception ex) {
			throw new IOException(ex);
		}

		if (response.getStatusCodeValue() != 200) {
			throw new IOException(response.toString());
		}
		return new Resource(response.getBody(), "UTF-8");
	}
}
