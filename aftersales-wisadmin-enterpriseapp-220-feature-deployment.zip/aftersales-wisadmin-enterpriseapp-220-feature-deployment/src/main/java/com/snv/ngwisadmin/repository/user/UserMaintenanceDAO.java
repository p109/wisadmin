package com.snv.ngwisadmin.repository.user;

import java.util.List;

import com.snv.ngwisadmin.model.UserGroupDTO;
import com.snv.ngwisadmin.model.UserMembershipDTO;

public interface UserMaintenanceDAO {

	public List<UserGroupDTO> getUserGroup();
	
	public List<UserMembershipDTO> getUserMembership();
	
	public List<UserMembershipDTO> getUserMembership(String id);
	
	public boolean insertUserMemberList(List<UserMembershipDTO> dto);
	
	public boolean deleteUserMemberList(List<UserMembershipDTO> dto);
	
	public List<String> getUserRoles(String uid);
}
