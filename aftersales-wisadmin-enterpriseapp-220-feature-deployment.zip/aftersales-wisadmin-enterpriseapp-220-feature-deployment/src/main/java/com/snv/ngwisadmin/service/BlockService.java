package com.snv.ngwisadmin.service;

import java.util.List;

import com.snv.ngwisadmin.model.BlockRuleDTO;

public interface BlockService {

	public List<BlockRuleDTO> getBlockRules();
	
	public List<BlockRuleDTO> insertBlockRule(BlockRuleDTO dto);
	
	public List<BlockRuleDTO> updateBlockRule(List<BlockRuleDTO> dtoList);
	
	public List<BlockRuleDTO> deleteBlockRule(BlockRuleDTO dto);
}
