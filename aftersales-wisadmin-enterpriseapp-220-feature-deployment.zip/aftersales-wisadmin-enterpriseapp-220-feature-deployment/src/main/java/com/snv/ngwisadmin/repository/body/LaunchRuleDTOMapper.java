package com.snv.ngwisadmin.repository.body;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.LaunchRuleDTO;
import com.snv.ngwisadmin.util.Utility;

public class LaunchRuleDTOMapper implements RowMapper<LaunchRuleDTO> {

	public LaunchRuleDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		LaunchRuleDTO dto = new LaunchRuleDTO();
		
		dto.setAssemblyPlant(rs.getString("I_ASSY_PLT"));
		dto.setBodyStyle(rs.getString("C_BDY_STYLE"));
		dto.setCorpLoc(rs.getString("I_CORPLOC"));
		//Commenting as this column was not available in Snowflake
		//dto.setDescription(rs.getString("X_RULE_DESCRIPTION"));
		dto.setEffectiveEnd(Utility.checkNull(rs.getDate("D_EFF_END")));
		dto.setEffectiveStart(Utility.checkNull(rs.getDate("D_EFF_STRT")));
		dto.setFamily(rs.getString("C_FAM"));
		dto.setId(rs.getInt("I_LNCH_RULE_ID"));
		dto.setLaunchDate(Utility.checkNull(rs.getDate("D_VHCL_LNCH")));
		dto.setLine(rs.getString("C_LINE"));
		dto.setMarket(rs.getString("C_MKT"));
		dto.setModelYear(rs.getString("I_MOD_YR"));
		dto.setSalesCode(rs.getString("C_SCODE_PAT"));
		dto.setSeries(rs.getString("C_SERIES"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		dto.setUser(rs.getString("I_LOGON"));
		
		return dto;
	}
}
