package com.snv.ngwisadmin.util;

public class TableConstants {
	public static final String DATA_SOURCE = "ds";
	public static final String SCHEMA_NAME = "wis";

	public static class Report {
		public static final String TABLE_NAME = "REPORT";
		public static final String I_REP_ID = "I_REP_ID";
		public static final String C_BRD_TYP = "C_BRD_TYP";
		public static final String C_REP = "C_REP";
		public static final String C_TYP = "C_TYP";
		public static final String X_SUBJECT = "X_SUBJECT";
		public static final String X_MSG = "X_MSG";
		public static final String D_EFF_DATE = "D_EFF_DATE";
		public static final String X_EMAIL = "X_EMAIL";
		public static final String I_LOGON = "I_LOGON";
		public static final String T_STMP_UPD = "T_STMP_UPD";
	}

}
