package com.snv.ngwisadmin.repository;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.BlockRuleDTO;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class BlockRuleDAOImpl implements BlockRuleDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	DataSource ds;
	
	public List<BlockRuleDTO> getBlockRules() {
		String sql = "select * from wis.block";
		List<BlockRuleDTO> dtoList = jdbcTemplate.query(sql, new BlockRuleDTOMapper());
		return dtoList;
	}
	
	public boolean insertBlockRule(BlockRuleDTO dto) {
		int maxId = Utility.getMaxId("BLOCK", jdbcTemplate);
		maxId++;
		
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("block");
		Map<String, Object> params = new HashMap<>();
		params.put("i_blk_id", maxId);
		params.put("c_fg", dto.getFg());
		params.put("c_cg", dto.getCg());
		params.put("c_cc", dto.getCc());
		params.put("c_oc", dto.getOc());
		params.put("c_platform", dto.getPlatform());
		params.put("c_family_code", dto.getFamily());
		params.put("c_cond_cls", dto.getCondClass());
		
		params.put("q_odom_min", checkNullInput(dto.getOdomMin()));
		
		params.put("q_odom_max", checkNullInput(dto.getOdomMax()));
		params.put("q_exp_labr_min", checkNullInput(dto.getLaborMin()));
		params.put("q_exp_labr_max", checkNullInput(dto.getLaborMax()));
		params.put("l_block_exp", dto.getBlockExpense());
		params.put("l_block_cond", dto.getBlockCondition());
		params.put("d_eff_strt", Utility.toDate(dto.getEffectiveStart()));
		params.put("d_eff_end", Utility.toDate(dto.getEffectiveEnd()));
		params.put("x_desc", dto.getDescription());
		params.put("i_logon", "T3679A2");
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		params.put("l_sublet", dto.getSublet());
		params.put("c_tran", dto.getTransaction());
		
		jdbcInsert.execute(params);
		return true;
	}
	
	public boolean updateBlockRule(List<BlockRuleDTO> dtoList)
	{
		BlockRuleDTO oldDto = dtoList.get(0);
		BlockRuleDTO newDto = dtoList.get(1);
		
		String sql = "update wis.block set c_fg = :fg, c_cg = :cg, c_cc = :cc, c_oc = :oc," +
				"c_platform = :platform, c_family_code = :family, c_cond_cls = :condClass," +
				"q_odom_min = :odomMin, q_odom_max = :odomMax, q_exp_labr_min = :laborMin," +
				"q_exp_labr_max = :laborMax, l_block_exp = :blockExp, d_eff_strt = :effStart," +
				"d_eff_end = :effEnd, x_desc = :desc, i_logon = :user, l_sublet = :sublet," +
				"c_tran = :tran, t_stmp_upd = current_timestamp, l_block_cond = :blockCond" +
				" where i_blk_id = :id";
		
		Map<String, Object> params = new HashMap<>();
		params.put("fg", newDto.getFg());
		params.put("cg", newDto.getCg());
		params.put("cc", newDto.getCc());
		params.put("oc", newDto.getOc());
		params.put("platform", newDto.getPlatform());
		params.put("family", newDto.getFamily());
		params.put("condClass", newDto.getCondClass());
		params.put("odomMin", checkNullInput(newDto.getOdomMin()));
		params.put("odomMax", checkNullInput(newDto.getOdomMax()));
		params.put("laborMin", checkNullInput(newDto.getLaborMin()));
		params.put("laborMax", checkNullInput(newDto.getLaborMax()));
		params.put("effStart", Utility.toDate(newDto.getEffectiveStart()));
		params.put("effEnd", Utility.toDate(newDto.getEffectiveEnd()));
		params.put("desc", newDto.getDescription());
		params.put("blockCond", newDto.getBlockCondition());
		params.put("user", "T3679A2");
		params.put("sublet", newDto.getSublet());
		params.put("blockExp", newDto.getBlockExpense());
		params.put("tran", newDto.getTransaction());
		params.put("id", oldDto.getId());
		
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	public boolean deleteBlockRule(BlockRuleDTO dto)
	{
		String sql = "delete from wis.block where i_blk_id = :id";
		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		jdbcTemplate.update(sql, params);
		return true;
	}
	
	private Integer checkNullInput(int input)
	{
		if (input == -1)
			return null;
		else
			return input;
	}
	
	private Float checkNullInput(float input)
	{
		if (input == -1)
			return null;
		else
			return input;
	}
}
