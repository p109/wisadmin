package com.snv.ngwisadmin.repository.wcc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.wcc.ConditionCoverageDTO;

public class ConditionCoverageDTOMapper implements RowMapper<ConditionCoverageDTO> {
	public ConditionCoverageDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		ConditionCoverageDTO dto = new ConditionCoverageDTO();
		dto.setWcc(rs.getString("C_WCC"));
		dto.setWccDesc(rs.getString("X_WCC"));
		dto.setCondClass(rs.getString("C_COND_CLS"));
		dto.setClassDesc(rs.getString("X_COND_CLS"));
		return dto;
	}
}
