package com.snv.ngwisadmin.repository.componenttype;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.componenttype.CTClassDTO;
import com.snv.ngwisadmin.model.componenttype.CTDescDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleDTO;
import com.snv.ngwisadmin.model.componenttype.CTRuleMap;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class CTMaintenanceDAOImpl implements CTMaintenanceDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	DataSource ds;

	@Autowired
	AuthenticationFacade auth;

	// Returns all ct class descriptions from table
	@Override
	public List<CTClassDTO> getCTClassDesc() {
		String sql = "SELECT * FROM WIS.CT_CLS_DESC";
		List<CTClassDTO> ctList = jdbcTemplate.query(sql, new CTClassDTOMapper(true));
		return ctList;
	}

	// Returns all ct desc from table
	@Override
	public List<CTDescDTO> getCTDesc() {
		String sql = "SELECT * FROM WIS.CT_DESC";
		List<CTDescDTO> ctList = jdbcTemplate.query(sql, new CTDescDTOMapper());
		return ctList;
	}

	// Returns all ct rules from db
	@Override
	public CTRuleMap getCTRule() {
		String sql = "SELECT * FROM WIS.CT_RULE";
		CTRuleMap map = new CTRuleMap();
		List<CTRuleDTO> ruleList = jdbcTemplate.query(sql, new CTRuleDTOMapper());
		sql = "SELECT c_ct_class, x_ct_class FROM WIS.CT_CLS_DESC";
		List<CTClassDTO> ctList = jdbcTemplate.query(sql, new CTClassDTOMapper(false));
		map.setRuleList(ruleList);
		map.setClassList(ctList);
		return map;
	}

	public boolean promoteCTRule() {
		String sql = "SELECT * FROM WISRPTA.CT_RULE order by i_ct_rule_id";
		List<CTRuleDTO> ruleList = jdbcTemplate.query(sql, new CTRuleDTOMapper());
		Map<String, Object> params = new HashMap<>();
		sql = "DELETE FROM WISLOAD.RUL_SCODE_INTPL";
		jdbcTemplate.update(sql, params);
		sql = "DELETE FROM WISLOAD.RUL_SCODE_OUTPL";
		jdbcTemplate.update(sql, params);
		sql = "DELETE FROM WISLOAD.CT_SCODE_PAT";
		jdbcTemplate.update(sql, params);
		int sCount = 1;
		Map<String, Integer> inMap = new HashMap<>();
		Map<String, Integer> outMap = new HashMap<>();
		String readCode = "";
		String lastOperator = "";
		for (CTRuleDTO rule : ruleList) {
			System.out.println("Processing rule: " + rule.getId());
			String pattern = rule.getScodePattern();
			lastOperator = "";
			readCode = "";

			if (pattern.length() == 3) {
				if ("".equals(lastOperator)) {
					sql = "INSERT INTO WISLOAD.RUL_SCODE_INTPL VALUES (" + sCount + ",'" + pattern + "')";
					jdbcTemplate.update(sql, params);
					sql = "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + sCount + "," + rule.getId() + ")";
					jdbcTemplate.update(sql, params);
				}

				inMap.put(pattern, sCount);
				sCount++;
			} else {
				List<String> parenList = new ArrayList<String>();
				boolean notIndicator = false;
				boolean inParen = false;
				// If not is inside paren function
				boolean notParen = false;
				readCode = "";
				String parenOperator = "";
				// Operator that comes after parentheses
				String afterOperator = "";
				for (int i = 0; i < pattern.length(); i++) {
					String myChar = pattern.substring(i, i + 1);
					if ("<".equals(myChar)) {
						if (!"".equals(readCode)) {
							if (!notIndicator) {
								sql = "INSERT INTO WISLOAD.RUL_SCODE_INTPL VALUES (" + sCount + ",'" + readCode + "')";
								jdbcTemplate.update(sql, params);
								readCode = "";
							}
						} else {
							if (i != 0) {
								afterOperator = "<";
							}
						}
						if (inParen) {
							notParen = true;
							parenOperator = "<";
							parenList.add(readCode);
							readCode = "";
						} else {
							notIndicator = true;
						}
						lastOperator = "<";
					} else if ("&".equals(myChar)) {
						// we have a sales code
						if (!"".equals(readCode)) {
							if (inParen) {
								parenList.add(readCode);
								readCode = "";
								parenOperator = "&";
							} else {
								sql = "INSERT INTO WISLOAD.RUL_SCODE_INTPL VALUES (" + sCount + ",'" + readCode + "')";
								jdbcTemplate.update(sql, params);
								lastOperator = "&";
								readCode = "";
							}
						} else {
							afterOperator = "&";
						}
					} else if ("+".equals(myChar)) {
						if (!"".equals(readCode)) {
							if (inParen) {
								parenOperator = "+";
								parenList.add(readCode);
								readCode = "";
							} else {
								sCount = insertTupl(readCode, sCount, rule.getId(), false, true, inMap);
								lastOperator = "+";
								readCode = "";
							}
						} else {
							afterOperator = "+";
						}
					} else if ("(".equals(myChar)) {
						inParen = true;
						if (notIndicator) {
							notParen = true;
						}
					} else if (")".equals(myChar)) {
						inParen = false;
						notIndicator = false;
						parenList.add(readCode);
						readCode = "";
					} else {
						readCode += myChar;
					}
				}

				if (parenList.size() != 0) {
					// There are only parentheses
					if ("".equals(afterOperator)) {
						if ("+".equals(parenOperator)) {
							for (String scode : parenList) {
								// If the sales code tupl already exists, then reuse it
								if (notParen) {
									sCount = insertTupl(scode, sCount, rule.getId(), true, true, outMap);
								} else {
									sCount = insertTupl(scode, sCount, rule.getId(), false, true, inMap);
								}
							}
						}

						if ("&".equals(parenOperator)) {
							for (String scode : parenList) {
								sCount = insertTupl(scode, sCount, rule.getId(), false, false, inMap);
							}
							sql = "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + sCount + "," + rule.getId() + ")";
							jdbcTemplate.update(sql, params);
							sCount++;
						}

						if ("<".equals(parenOperator)) {
							// The first code in the sequence is in the intupl
							// All sequences after that are not, out tupl
							// Don't do multiple nots it won't work
							boolean notFirst = false;
							for (String scode : parenList) {
								if (notFirst) {
									sCount = insertTupl(scode, sCount, rule.getId(), true, false, outMap);
								} else {
									sCount = insertTupl(scode, sCount, rule.getId(), false, false, inMap);
								}
								notFirst = true;
							}
						}
					} else if ("&".equals(afterOperator)) {
						if ("+".equals(parenOperator)) {
							for (String scode : parenList) {
								sCount = insertTupl(scode, sCount, rule.getId(), false, false, inMap);
								sCount = insertTupl(readCode, sCount, rule.getId(), false, false, inMap);
								sql = "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + sCount + "," + rule.getId() + ")";
								jdbcTemplate.update(sql, params);
								sCount++;
							}
						} else {
							for (String scode : parenList) {
								sCount = insertTupl(scode, sCount, rule.getId(), false, false, inMap);
							}
							sCount = insertTupl(readCode, sCount, rule.getId(), false, false, inMap);
							sql = "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + sCount + "," + rule.getId() + ")";
							jdbcTemplate.update(sql, params);
							sCount++;
						}
					} else if ("<".equals(afterOperator)) {
						if ("+".equals(parenOperator)) {
							for (String scode : parenList) {
								// If the sales code tupl already exists, then reuse it
								sCount = insertTupl(scode, sCount, rule.getId(), false, false, inMap);
								sCount = insertTupl(readCode, sCount, rule.getId(), true, false, outMap);
							}
						}

						if ("&".equals(parenOperator)) {
							for (String scode : parenList) {
								sCount = insertTupl(scode, sCount, rule.getId(), false, false, inMap);
							}
							sCount = insertTupl(readCode, sCount, rule.getId(), true, false, outMap);
						}
					}
				} else {
					if ("<".equals(lastOperator)) {
						sCount = insertTupl(readCode, sCount, rule.getId(), true, false, outMap);
					} else if ("+".equals(lastOperator)) {
						sCount = insertTupl(readCode, sCount, rule.getId(), false, true, inMap);
					} else if ("&".equals(lastOperator)) {
						sCount = insertTupl(readCode, sCount, rule.getId(), false, false, inMap);
						sCount++;
					}
				}
			}
		}
		return true;
	}

	// Inserts the tupl value into the tables. Returns the ct counter
	private int insertTupl(String tupl, int count, int ruleId, boolean notIndicator, boolean addPattern,
			Map<String, Integer> codeMap) {
		Map<String, Object> params = new HashMap<>();
		String sql;
		if (notIndicator) {
			/*
			 * if (codeMap.get(tupl) != null) { sql =
			 * "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + codeMap.get(tupl) + "," +
			 * ruleId + ")"; jdbcTemplate.update(sql, params); } else {
			 */
			sql = "INSERT INTO WISLOAD.RUL_SCODE_OUTPL VALUES (" + count + ",'" + tupl + "')";
			jdbcTemplate.update(sql, params);
			sql = "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + count + "," + ruleId + ")";
			jdbcTemplate.update(sql, params);
			// codeMap.put(tupl, count);
			count++;
			/* } */
		} else {
			if (addPattern && codeMap.get(tupl) != null) {
				sql = "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + codeMap.get(tupl) + "," + ruleId + ")";
				jdbcTemplate.update(sql, params);
			} else {
				sql = "INSERT INTO WISLOAD.RUL_SCODE_INTPL VALUES (" + count + ",'" + tupl + "')";
				jdbcTemplate.update(sql, params);
				// For OR clause want to add pattern to list, but not AND clause
				if (addPattern) {
					sql = "INSERT INTO WISLOAD.CT_SCODE_PAT VALUES (" + count + "," + ruleId + ")";
					jdbcTemplate.update(sql, params);
					codeMap.put(tupl, count);
					count++;
				}
			}
		}
		return count;
	}

	// Insert one record
	@Override
	public boolean insertCTDesc(CTDescDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("ct_desc");
		Map<String, Object> params = new HashMap<>();
		params.put("c_ct", dto.getCt());
		params.put("x_ct", dto.getCtDesc());
		// T3679A2 -- force logon
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean insertCTClassDesc(CTClassDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("ct_cls_desc");
		Map<String, Object> params = new HashMap<>();
		params.put("c_ct_class", dto.getCtClass());
		params.put("x_ct_class", dto.getClassDesc());
		// T3679A2 -- force logon
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean insertCTRule(CTRuleDTO dto) {
		// Increase by 1 for new row
		int maxId = Utility.getMaxId("CT RULE", jdbcTemplate);
		maxId += 1;

		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("ct_rule");
		Map<String, Object> params = new HashMap<>();
		params.put("i_ct_rule_id", maxId);
		params.put("c_ct_class", dto.getCtClass());
		params.put("c_ct", dto.getCt());
		params.put("c_prod_line", dto.getProductLine());
		params.put("c_eng_plant", dto.getEnginePlant());
		params.put("c_trans_plant", dto.getTransPlant());
		params.put("c_scode_pat", dto.getScodePattern());
		params.put("d_bld_befr", Utility.toDate(dto.getBuildStart()));
		params.put("d_bld_aftr", Utility.toDate(dto.getBuildEnd()));
		params.put("d_eff_strt", Utility.toDate(dto.getEffectiveStart()));
		params.put("d_eff_end", Utility.toDate(dto.getEffectiveEnd()));
		params.put("i_logon", dto.getUser());
		params.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));
		params.put("x_rule_description", "");

		String combo = checkCombo(dto.getScodePattern());

		params.put("l_combo", combo);

		jdbcInsert.execute(params);
		return true;

	}

	// Delete one record
	@Override
	public boolean deleteCTDesc(CTDescDTO dto) {
		String sql = "DELETE FROM WIS.CT_DESC WHERE C_CT = :c_ct";
		Map<String, Object> params = new HashMap<>();
		params.put("c_ct", dto.getCt());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteCTClassDesc(CTClassDTO dto) {
		String sql = "delete from wis.ct_cls_desc where c_ct_class = :c_ct_cls";
		Map<String, Object> params = new HashMap<>();
		params.put("c_ct_cls", dto.getCtClass());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteCTRule(CTRuleDTO dto) {
		String sql = "delete from wis.ct_rule where i_ct_rule_id = :rule_id";
		Map<String, Object> params = new HashMap<>();
		params.put("rule_id", dto.getId());
		jdbcTemplate.update(sql, params);
		return true;
	}

	// Old DTO must be first, new DTO second
	@Override
	public boolean updateCTDesc(List<CTDescDTO> dtoList) {
		String sql = "UPDATE WIS.CT_DESC SET c_ct = :c_ct, x_ct = :x_ct,"
				+ "i_logon = :i_logon, t_stmp_upd = current_timestamp" + " WHERE C_CT = :old_ct";
		Map<String, Object> params = new HashMap<>();
		CTDescDTO oldDto = dtoList.get(0);
		CTDescDTO newDto = dtoList.get(1);
		params.put("c_ct", newDto.getCt());
		params.put("x_ct", newDto.getCtDesc());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("old_ct", oldDto.getCt());

		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean updateCTClassDesc(List<CTClassDTO> dtoList) {
		String sql = "update wis.ct_cls_desc set c_ct_class = :c_ct_cls, x_ct_class = :x_ct_cls,"
				+ "i_logon = :i_logon, t_stmp_upd = current_timestamp" + " where c_ct_class = :old_cls";
		Map<String, Object> params = new HashMap<>();
		CTClassDTO oldDto = dtoList.get(0);
		CTClassDTO newDto = dtoList.get(1);
		params.put("c_ct_cls", newDto.getCtClass());
		params.put("x_ct_cls", newDto.getClassDesc());
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("old_cls", oldDto.getCtClass());

		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean updateCTRule(List<CTRuleDTO> dtoList) {
		String sql = "update wis.ct_rule set c_ct_class = :c_ct_cls, c_ct = :c_ct,"
				+ "l_combo = :combo, c_prod_line = :prod_line, c_eng_plant = :eng_plant,"
				+ "c_trans_plant = :trans_plant, c_scode_pat = :scode_pat, d_bld_befr = :build_start,"
				+ "d_bld_aftr = :build_end, d_eff_strt = :eff_start, d_eff_end = :eff_end,"
				+ "i_logon = :i_logon, t_stmp_upd = current_timestamp" + " where i_ct_rule_id = :rule_id";

		Map<String, Object> params = new HashMap<>();
		CTRuleDTO oldDto = dtoList.get(0);
		CTRuleDTO newDto = dtoList.get(1);

		params.put("c_ct_cls", newDto.getCtClass());
		params.put("c_ct", newDto.getCt());
		params.put("l_combo", checkCombo(newDto.getScodePattern()));
		params.put("prod_line", newDto.getProductLine());
		params.put("eng_plant", newDto.getEnginePlant());
		params.put("trans_plant", newDto.getTransPlant());
		params.put("scode_pat", newDto.getScodePattern());
		params.put("build_end", Utility.toDate(newDto.getBuildEnd()));
		params.put("build_start", Utility.toDate(newDto.getBuildStart()));
		params.put("eff_start", Utility.toDate(newDto.getEffectiveStart()));
		params.put("eff_end", Utility.toDate(newDto.getEffectiveEnd()));
		params.put("i_logon", auth.getLoggedInUser().getUserId());
		params.put("rule_id", oldDto.getId());

		String combo = checkCombo(newDto.getScodePattern());

		params.put("combo", combo);
		for (String key : params.keySet()) {
			System.out.println("key is: " + key);
			System.out.println("params is" + params.get(key));
		}

		jdbcTemplate.update(sql, params);
		return true;
	}

	private String checkCombo(String scode) {
		if (scode.contains("&") || scode.contains("<") || scode.contains("(") || scode.contains("+")) {
			return "1";
		} else {
			return "0";
		}
	}
}
