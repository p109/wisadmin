package com.snv.ngwisadmin.repository.wcc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.wcc.CoverageCodeClassDTO;

public class CoverageCodeClassDTOMapper implements RowMapper<CoverageCodeClassDTO> {

	public CoverageCodeClassDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		CoverageCodeClassDTO dto = new CoverageCodeClassDTO();
		
		dto.setId(rs.getInt("I_WCC_RULE_ID"));
		dto.setConditionClass(rs.getString("C_COND_CLS"));
		dto.setTransaction(rs.getString("C_TRAN"));
		dto.setUser(rs.getString("I_LOGON"));
		dto.setUpdateTime(rs.getTimestamp("T_STMP_UPD").toString());
		
		return dto;
	}
}
