package com.snv.ngwisadmin.security;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsByNameServiceWrapper;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedCredentialsNotFoundException;

import com.snv.ngwisadmin.model.ALBTokenPayload;
import com.snv.ngwisadmin.model.UserDTO;
import com.snv.ngwisadmin.service.impl.ALBUserDetailService;

@EnableWebSecurity
@Configuration
@Order(1)
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class AppSecurityConfig extends WebSecurityConfigurerAdapter {

	private static final String HEADER_TOKEN = "x-amzn-oidc-data";
	
	@Autowired
	AppAccessDeniedHandler appAccessDeniedHandler;
	
	//Security Test
	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	JwtUtil jwtUtil;
	
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/favicon.ico","/js/**.js","/css/**.css","/html/**.html");
	}
	

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		System.out.println("Configuring http security");
		http
			.authorizeRequests()
			.antMatchers(HttpMethod.OPTIONS, "/**").hasAnyAuthority("ROLE_USER,ROLE_USER_ADMIN,ROLE_RULE_ADMIN,ROLE_SUPER_ADMIN")
			.anyRequest().authenticated()
		.and()
			.exceptionHandling().accessDeniedHandler(appAccessDeniedHandler)
		.and()
			.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		.and().headers().frameOptions().sameOrigin()
		.and()
			.addFilterBefore(requestHeaderFilter(), RequestHeaderFilter.class)
			.cors()
		.and()
			.csrf()
			.disable();
	}
	
	RequestHeaderFilter requestHeaderFilter() throws Exception {
		RequestHeaderFilter filter = new RequestHeaderFilter(HEADER_TOKEN);
		filter.setAuthenticationManager(authenticationManager());
		filter.setAuthenticationFailureHandler(new DefaultAuthenticationFailureHandler());
		return filter;
	}
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder builder, ALBUserDetailService userDetailService) {
		builder.authenticationProvider(preAuthProvider(userDetailService));
	}
	
	@Bean
	PreAuthenticatedAuthenticationProvider preAuthProvider(ALBUserDetailService userDetailService) {
		PreAuthenticatedAuthenticationProvider provider = new PreAuthenticatedAuthenticationProvider();
		provider.setPreAuthenticatedUserDetailsService(userDetailsByNameServiceWrapper(userDetailService));
		return provider;
	}
	
	@Bean
	UserDetailsByNameServiceWrapper<PreAuthenticatedAuthenticationToken> userDetailsByNameServiceWrapper(ALBUserDetailService userDetailService){
		UserDetailsByNameServiceWrapper<PreAuthenticatedAuthenticationToken> wrapper = new UserDetailsByNameServiceWrapper<>();
		wrapper.setUserDetailsService(userDetailService);
		return wrapper;
	}
}
