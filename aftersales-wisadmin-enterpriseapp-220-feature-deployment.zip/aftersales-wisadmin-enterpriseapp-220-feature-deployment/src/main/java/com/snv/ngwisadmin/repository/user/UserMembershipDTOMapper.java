package com.snv.ngwisadmin.repository.user;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.snv.ngwisadmin.model.UserMembershipDTO;

public class UserMembershipDTOMapper implements RowMapper<UserMembershipDTO> {

	public UserMembershipDTO mapRow(ResultSet rs, int index) throws SQLException
	{
		UserMembershipDTO dto = new UserMembershipDTO();
		dto.setUserId(rs.getString("I_LOGON"));
		dto.setUserGroup(rs.getString("N_GROUP"));
		return dto;
	}
}
