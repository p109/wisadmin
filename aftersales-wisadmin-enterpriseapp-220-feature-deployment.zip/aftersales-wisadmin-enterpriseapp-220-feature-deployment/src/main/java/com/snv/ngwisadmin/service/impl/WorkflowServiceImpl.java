package com.snv.ngwisadmin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snv.ngwisadmin.model.LdapUserDTO;
import com.snv.ngwisadmin.model.workflow.WorkflowInformation;
import com.snv.ngwisadmin.model.workflow.WorkflowRequestDTO;
import com.snv.ngwisadmin.repository.workflow.WorkflowDAO;
import com.snv.ngwisadmin.security.LdapClient;
import com.snv.ngwisadmin.service.MailService;
import com.snv.ngwisadmin.service.WorkflowService;
import com.snv.ngwisadmin.util.Constants;

@Service
public class WorkflowServiceImpl implements WorkflowService {

	@Autowired
	WorkflowDAO dao;
	
	@Autowired
	MailService mailService;
	
	@Autowired
	LdapClient ldapClient;

	@Override
	public WorkflowInformation getWorkflowRequests() {
		return dao.getWorkflowRequests();
	}

	@Override
	public WorkflowInformation actionWorkflowRequest(WorkflowRequestDTO dto, String action) {
		// TODO T3679A2 -- Must be authorized to perform this action

		if (Constants.WORKFLOW_STEP_APPROVE.equals(action)) {
			int stepNum = dao.approveWorkflowRequest(dto);
			
			//stepNum -1 when completed
			//stepNum greater than -1 when more steps are pending
			//stepNum -2 to not send any emails
			if (stepNum == -1)
			{
				//Send mail to the requestor
				List<String> mailingList = new ArrayList<>();
				List<LdapUserDTO> userList = ldapClient.search(dto.getRequestor());
				if (userList.size() > 0)
				{
					mailingList.add(userList.get(0).getEmail());
					mailService.sendMail(mailingList, "WIS Request " + dto.getId() + " Completed",
							"Hello " + userList.get(0).getFullName() + ",\n\n" +
							"Your request #" + dto.getId() + " for WIS has been completed.\n" +
							"Request Description: " + dto.getDescription());
				}
				
				//Send mail to the notification group
				mailingList.clear();
				userList.clear();
				List<String> notifId = dao.getNotificationList();
				for (String nid : notifId)
				{
					userList = ldapClient.search(nid);
					if (userList.size() > 0)
					{
						mailingList.add(userList.get(0).getEmail());
					}
				}
				mailService.sendMail(mailingList, "WIS Request " + dto.getId() + " Completed",
						"A new WIS request has just been completed.\n" +
						"Request: " + dto.getDescription());
			}
			else
			if (stepNum > -1)
			{
				//Request has more steps
				//Send mail to next set of approvers
				List<String> approverId = dao.getApproverList(dto.getId());
				List<String> mailingList = new ArrayList<>();
				for (String aid : approverId)
				{
					List<LdapUserDTO> userList = ldapClient.search(aid);
					if (userList.size() > 0)
					{
						mailingList.add(userList.get(0).getEmail());
					}
				}
				
				mailService.sendMail(mailingList, "WIS Request " + dto.getId() + " Approval", 
						"Request #" + dto.getId() + " is awaiting your approval.\n" +
				"Request: " + dto.getDescription() + "\n" +
				"Go onto WIS Admin -> Workflow Requests to approve or deny this request");
			}
		}
		if (Constants.WORKFLOW_STEP_REJECT.equals(action)) {
			dao.rejectWorkflowRequest(dto);
			
			//Send mail to requestor
			List<String> mailingList = new ArrayList<>();
			List<LdapUserDTO> userList = ldapClient.search(dto.getRequestor());
			if (userList.size() > 0)
			{
				mailingList.add(userList.get(0).getEmail());
				mailService.sendMail(mailingList, "WIS Request " + dto.getId() + " Rejected",
						"Hello " + userList.get(0).getFullName() + ",\n\n" +
						"Your request #" + dto.getId() + " for WIS has been rejected.\n" +
						"Request Description: " + dto.getDescription());
			}
		}

		return dao.getWorkflowRequests();
	}

	@Override
	public WorkflowInformation insertWorkflowRequest(WorkflowRequestDTO dto) {
		insertWorkflowRequestOnly(dto);
		return dao.getWorkflowRequests();
	}
	
	//When we don't need a table update
	public void insertWorkflowRequestOnly(WorkflowRequestDTO dto) {
		int dtoId = dao.insertWorkflowRequest(dto);
		//After inserting, send mail to approvers
		List<String> approverId = dao.getApproverList(dtoId);
		List<String> mailingList = new ArrayList<>();
		for (String aid : approverId)
		{
			List<LdapUserDTO> userList = ldapClient.search(aid);
			if (userList.size() > 0)
			{
				mailingList.add(userList.get(0).getEmail());
			}
		}
		
		mailService.sendMail(mailingList, "WIS Request " + dtoId + " Approval", 
				"A new request #" + dtoId + " has been submitted and is awaiting your approval.\n" +
		"Request: " + dto.getDescription() + "\n" +
		"Go onto WIS Admin -> Workflow Requests to approve or deny this request");
		return;
	}

	@Override
	public List<String> getApproverList(int requestId) {
		return dao.getApproverList(requestId);
	}

}
