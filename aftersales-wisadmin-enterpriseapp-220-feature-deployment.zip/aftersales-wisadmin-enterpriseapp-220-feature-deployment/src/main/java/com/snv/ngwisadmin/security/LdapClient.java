package com.snv.ngwisadmin.security;

import java.util.List;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.LdapTemplate;

import com.snv.ngwisadmin.model.LdapUserDTO;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

public class LdapClient {

	@Autowired
	private ContextSource contextSource;
	
	@Autowired
	private LdapTemplate ldapTemplate;
	
	//Finds a user's name and email from corporate directory
	public List<LdapUserDTO> search(String username)
	{
		return ldapTemplate.search(
		         query().where("uid").is(username).or("alternateUserID").is(username),
		         new AttributesMapper<LdapUserDTO>() {
		            public LdapUserDTO mapFromAttributes(Attributes attrs)
		               throws NamingException {
		                LdapUserDTO luser = new LdapUserDTO();
		                
		                luser.setFullName(attrs.get("cn").get().toString());
		                luser.setEmail(attrs.get("mail").get().toString());
		                
		            	return luser;
		            }
		         });
	}
}
