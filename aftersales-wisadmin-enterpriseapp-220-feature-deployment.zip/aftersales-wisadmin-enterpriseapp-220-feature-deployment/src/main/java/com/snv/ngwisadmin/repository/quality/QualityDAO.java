package com.snv.ngwisadmin.repository.quality;

import java.util.List;

import com.snv.ngwisadmin.model.CommodityDirectorDTO;
import com.snv.ngwisadmin.model.QualityManagerDTO;

public interface QualityDAO {

	List<CommodityDirectorDTO> getCommodityDirector();

	boolean insertCommodityDirector(CommodityDirectorDTO dto);

	boolean updateCommodityDirector(CommodityDirectorDTO dto);

	boolean deleteCommodityDirector(CommodityDirectorDTO dto);

	List<QualityManagerDTO> getQualityManager();

	boolean insertQualityManager(QualityManagerDTO dto);

	boolean updateQualityManager(QualityManagerDTO dto);

	boolean deleteQualityManager(QualityManagerDTO dto);

}
