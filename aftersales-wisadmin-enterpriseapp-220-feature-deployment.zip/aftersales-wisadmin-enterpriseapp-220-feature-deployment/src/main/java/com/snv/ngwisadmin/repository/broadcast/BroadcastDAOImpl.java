package com.snv.ngwisadmin.repository.broadcast;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.snv.ngwisadmin.model.broadcast.BroadcastMessageDTO;
import com.snv.ngwisadmin.model.broadcast.BroadcastMessageInputDTO;
import com.snv.ngwisadmin.model.broadcast.BroadcastMessageInputSetDto;
import com.snv.ngwisadmin.model.broadcast.BroadcastMessageMap;
import com.snv.ngwisadmin.model.broadcast.BroadcastTypeDTO;
import com.snv.ngwisadmin.security.AuthenticationFacade;
import com.snv.ngwisadmin.util.Constants;
import com.snv.ngwisadmin.util.TableConstants;
import com.snv.ngwisadmin.util.Utility;

@Repository
public class BroadcastDAOImpl implements BroadcastDAO {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	DataSource ds;
	
	@Autowired
	AuthenticationFacade auth;

	private Map<String, String> reportMap = new HashMap<>();
	private Map<String, String> broadcastMap = new HashMap<>();
	private Map<String, String> messageMap = new HashMap<>();

	public BroadcastDAOImpl() {
		super();
		reportMap.put("type", "c_rep");
		reportMap.put("desc", "x_rep");

		broadcastMap.put("type", "c_brd_typ");
		broadcastMap.put("desc", "x_brd_typ");

		messageMap.put("type", "c_typ");
		messageMap.put("desc", "x_typ");
	}

	@Override
	public List<BroadcastTypeDTO> getBroadcastType(String type) {
		String table = getBroadcastTable(type);

		String sql = "select * from wis." + table;

		List<BroadcastTypeDTO> myList = jdbcTemplate.query(sql, new BroadcastTypeDTOMapper(type));

		return myList;
	}

	@Override
	public List<BroadcastMessageDTO> getBroadcastMessage() {
		String sql = "select * from wis.report";

		List<BroadcastMessageDTO> myList = jdbcTemplate.query(sql, new BroadcastMessageDTOMapper());
		return myList;
	}

	@Override
	public boolean insertBroadcastType(BroadcastTypeDTO dto, String type) {
		String table = getBroadcastTable(type);
		Map<String, String> map = getBroadcastMap(type);

		Map<String, Object> paramMap = new HashMap<>();

		paramMap.put(map.get("type"), dto.getBroadcastType());
		paramMap.put(map.get("desc"), dto.getTypeDescription());
		paramMap.put("i_logon", auth.getLoggedInUser().getUserId());
		paramMap.put("t_stmp_upd", new Timestamp(System.currentTimeMillis()));

		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName(table);
		jdbcInsert.execute(paramMap);
		return true;
	}

	@Override
	public boolean updateBroadcastType(BroadcastTypeDTO dto, String type) {
		String table = getBroadcastTable(type);
		Map<String, String> map = getBroadcastMap(type);
		Map<String, Object> params = new HashMap<>();
		String sql = "update wis." + table + " set " + map.get("type") + " = :type ," + map.get("desc")
				+ "=:desc ,t_stmp_upd=:updatedTime where " + map.get("type") + " = :oldBroadcastType";
		params.put("type", dto.getBroadcastType());
		params.put("desc", dto.getTypeDescription());
		params.put("updatedTime", new Timestamp(System.currentTimeMillis()));
		params.put("oldBroadcastType", dto.getOldBroadcastType());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteBroadcastType(BroadcastTypeDTO dto, String type) {
		String table = getBroadcastTable(type);
		Map<String, String> map = getBroadcastMap(type);
		Map<String, Object> params = new HashMap<>();
		String sql = "delete from wis." + table + " where " + map.get("type") + " = :type";
		params.put("type", dto.getBroadcastType());
		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean insertBroadcastMessage(BroadcastMessageDTO dto) {
		SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(ds).withSchemaName("wis").withTableName("report");
		Map<String, Object> params = new HashMap<>();

		int maxId = Utility.getMaxId("REPORT", jdbcTemplate);

		params.put(TableConstants.Report.I_REP_ID, maxId + 1);
		params.put(TableConstants.Report.C_BRD_TYP, dto.getBroadcastType());
		params.put(TableConstants.Report.C_REP, dto.getReportType());
		params.put(TableConstants.Report.C_TYP, dto.getMessageType());
		params.put(TableConstants.Report.X_SUBJECT, dto.getSubject());
		params.put(TableConstants.Report.X_MSG, dto.getMessage());
		params.put(TableConstants.Report.D_EFF_DATE, Utility.toDate(dto.getEffectiveDate()));
		params.put(TableConstants.Report.X_EMAIL, dto.getEmail());
		params.put(TableConstants.Report.I_LOGON, auth.getLoggedInUser().getUserId());
		params.put(TableConstants.Report.T_STMP_UPD, new Timestamp(System.currentTimeMillis()));

		jdbcInsert.execute(params);
		return true;
	}

	@Override
	public boolean updateBroadcastMessage(BroadcastMessageDTO dto) {

		String sql = "update wis.report set c_brd_typ = :broadcastType, c_rep=:reportType ,c_typ=:messageType, x_subject=:subject, x_msg=:message, d_eff_date=:effectiveDate, x_email=:email,t_stmp_upd=:updatedTime where i_rep_id = :id";
		Map<String, Object> params = new HashMap<>();
		params.put("broadcastType", dto.getBroadcastType());
		params.put("reportType", dto.getReportType());
		params.put("messageType", dto.getMessageType());
		params.put("subject", dto.getSubject());
		params.put("message", dto.getMessage());
		params.put("effectiveDate", dto.getEffectiveDate());
		params.put("email", dto.getEmail());
		params.put("updatedTime", new Timestamp(System.currentTimeMillis()));
		params.put("id", dto.getId());

		jdbcTemplate.update(sql, params);
		return true;
	}

	@Override
	public boolean deleteBroadcastMessage(BroadcastMessageDTO dto) {
		String sql = "delete from wis.report where i_rep_id = :id";
		Map<String, Object> params = new HashMap<>();
		params.put("id", dto.getId());
		jdbcTemplate.update(sql, params);
		return true;
	}

	private Map<String, String> getBroadcastMap(String type) {
		switch (type) {
		case Constants.BROADCAST_DESC:
			return broadcastMap;
		case Constants.REPORT_DESC:
			return reportMap;
		case Constants.BROADCAST_TYPE_DESC:
			return messageMap;
		}
		return new HashMap<String, String>();
	}

	private String getBroadcastTable(String type) {
		switch (type) {
		case Constants.BROADCAST_DESC:
			return "brd_typ_desc";
		case Constants.REPORT_DESC:
			return "rep_desc";
		case Constants.BROADCAST_TYPE_DESC:
			return "typ_desc";
		}
		return "";
	}

	@Override
	public BroadcastMessageMap getInputParametersForBroadcastMessage() {
		BroadcastMessageMap msgMap = new BroadcastMessageMap();
		Map<String, String> broadcastTypeMap = new HashMap<>();
		Map<String, String> reportTypeMap = new HashMap<>();
		Map<String, String> messageTypeMap = new HashMap<>();

		BroadcastMessageInputSetDto broadcastMessageInputSetDto = new BroadcastMessageInputSetDto();

		String sql = "SELECT C_BRD_TYP, C_REP, C_TYP FROM WIS.REPORT";
		List<BroadcastMessageInputDTO> broadcastInputMessageParamsList = jdbcTemplate.query(sql,
				new BroadcastMessageInputDTOMapper());
		for (BroadcastMessageInputDTO input : broadcastInputMessageParamsList) {
			if (!input.getBroadcastType().isEmpty()) {
				broadcastMessageInputSetDto.getBroadcastTypeSet().add(input.getBroadcastType());
			}
			if (!input.getReportType().isEmpty()) {
				broadcastMessageInputSetDto.getReportTypeSet().add(input.getReportType());
			}
			if (!input.getMessageType().isEmpty()) {
				broadcastMessageInputSetDto.getMessageTypeSet().add(input.getMessageType());
			}
		}

		List<String> broadcastTypes = new ArrayList<>(broadcastMessageInputSetDto.getBroadcastTypeSet());
		SqlParameterSource bParameters = new MapSqlParameterSource("broadcastTypes", broadcastTypes);
		String brodcastDescriptionSql = "SELECT C_BRD_TYP,X_BRD_TYP FROM WIS.BRD_TYP_DESC WHERE C_BRD_TYP IN (:broadcastTypes)";
		List<BroadcastTypeDTO> broadcastTypeList = jdbcTemplate.query(brodcastDescriptionSql, bParameters,
				(rs, rowNum) -> new BroadcastTypeDTO(rs.getString("C_BRD_TYP"), rs.getString("X_BRD_TYP")));

		for (BroadcastTypeDTO btype : broadcastTypeList) {
			broadcastTypeMap.put(btype.getBroadcastType(), btype.getTypeDescription());
		}

		List<String> reportTypes = new ArrayList<>(broadcastMessageInputSetDto.getReportTypeSet());
		SqlParameterSource rParameters = new MapSqlParameterSource("reportTypes", reportTypes);
		String reportDescriptionSql = "SELECT C_REP,X_REP FROM WIS.REP_DESC WHERE C_REP IN (:reportTypes)";
		List<BroadcastTypeDTO> reportTypeList = jdbcTemplate.query(reportDescriptionSql, rParameters,
				(rs, rowNum) -> new BroadcastTypeDTO(rs.getString("C_REP"), rs.getString("X_REP")));

		for (BroadcastTypeDTO rtype : reportTypeList) {
			reportTypeMap.put(rtype.getBroadcastType(), rtype.getTypeDescription());
		}

		List<String> messageTypes = new ArrayList<>(broadcastMessageInputSetDto.getMessageTypeSet());
		SqlParameterSource mParameters = new MapSqlParameterSource("messageTypes", messageTypes);
		String messageDescriptionSql = "SELECT C_TYP,X_TYP FROM WIS.TYP_DESC WHERE C_TYP IN (:messageTypes)";
		List<BroadcastTypeDTO> messageTypeList = jdbcTemplate.query(messageDescriptionSql, mParameters,
				(rs, rowNum) -> new BroadcastTypeDTO(rs.getString("C_TYP"), rs.getString("X_TYP")));

		for (BroadcastTypeDTO mtype : messageTypeList) {
			messageTypeMap.put(mtype.getBroadcastType(), mtype.getTypeDescription());
		}

		msgMap.setBroadcastTypeMap(broadcastTypeMap);
		msgMap.setReportTypeMap(reportTypeMap);
		msgMap.setMessageTypeMap(messageTypeMap);
		return msgMap;
	}

}
