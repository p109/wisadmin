$(document).ready(function() {
	var myTable;
	var data;
	var selectedData = {};
	var dropSelection;
	
	//store these constants for UI and table updates
	var MONTHSCHEDULE = 'monthschedule';
	
	var scheduleBaseElements = ["#mySchedule", "#misSchedule", "#condSchedule", "#salesSchedule",
	                            "#batchSchedule", "#accessSchedule"];
	
	var scheduleInputElements = appendElements(scheduleBaseElements, "Input");
	var scheduleOutputElements = appendElements(scheduleBaseElements, "Output");
	
	var scheduleElements = ["modelYear", "mis", "conditionCutoff", "salesCutoff", "batchStart",
	                        "userAccess"];
	
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#scheduleSelect').on('change',function() {
		dropSelection = $(this).val();
		if (dropSelection == MONTHSCHEDULE)
		{
			fetchTableData("get-batch-schedule", dropSelection);
		}
		
	});
	
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('#scheduleInputDiv').show();
		$('#insertSchedule').show();
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('.output-div').show();
		$('#scheduleInputDiv').show();
		$('#updateSchedule').show();
		$('.copy-div').show();
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.output-div').show();
		$('#scheduleInputDiv').show();
		$('#deleteSchedule').show();
		
	});
	
	$('.copy-btn').on('click', function() {
		copyInputVals(scheduleOutputElements, scheduleInputElements);
	});
	
	$('#scheduleInsertBtn').on('click', function() {
		if (validateForm('#scheduleInputDiv'))
		{
			var sendData = getInputData(scheduleElements, scheduleInputElements);
			postData(sendData, "modify-batch-schedule?action=I");
		}
		
	});
	
	$('#scheduleUpdateBtn').on('click', function() {
		if (validateForm('#scheduleInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(scheduleElements, scheduleInputElements);
			sendData.oldModelYear = selectedData.modelYear;
			sendData.oldMis = selectedData.mis;
			postData(sendData, "modify-batch-schedule?action=U");
		}
	});
	
	$('#scheduleDeleteBtn').on('click', function() {
		if ($('#scheduleInputDiv').valid() && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(scheduleElements, scheduleOutputElements);
			postData(sendData, "modify-batch-schedule?action=D");
		}
	});
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		
		//Body rule
		if (selection == MONTHSCHEDULE)
		{
			myTable = $('#scheduleTable').DataTable({
				data: data,
				columns: [
				   {title: 'Model Year', data: 'modelYear'},
				   {title: 'MIS', data: 'mis'},
				   {title: 'Condition Cutoff', data: 'conditionCutoff'},
				   {title: 'Sales Cutoff', data: 'salesCutoff'},
				   {title: 'Batch Start', data: 'batchStart'},
				   {title: 'User Access', data: 'userAccess'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		//Row selection
		$('#scheduleTable tbody').on( 'click', 'tr', function () {

			clearInputVals(scheduleInputElements);
			clearInputVals(scheduleOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            setInputVals(selectedData, scheduleElements, scheduleOutputElements);
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {

		clearInputVals(scheduleInputElements);
		clearInputVals(scheduleOutputElements);
		selectedData = {};
		if (myTable != null)
		{
			$('#scheduleTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	//Pass in I, D, or U in the url action parameter
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(dropSelection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
		
	}
	
});