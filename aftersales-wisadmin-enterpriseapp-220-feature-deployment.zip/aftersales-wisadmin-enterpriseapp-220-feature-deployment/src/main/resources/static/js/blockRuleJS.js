$(document).ready(function() {
	var myTable;
	var data;
	var selectedData = {};
	
	
	
	//Get table data initially as there are no selections on the page
	fetchTableData("get-block-rules");
	
	var blockInputElements = ["#fgInput", "#cgInput", "#ccInput", "#ocInput", "#platformInput",
	                          "#familyInput", "#condClsInput", "#odomMinInput", "#odomMaxInput",
	                          "#laborMinInput", "#laborMaxInput", "#blockExpInput", "#blockCondInput",
	                          "#subletInput", "#transInput", "#effStartInput", 
	                          "#effEndInput", "#descriptionInput"];
	
	var blockOutputElements = ["#fgOutput", "#cgOutput", "#ccOutput", "#ocOutput", "#platformOutput",
	                          "#familyOutput", "#condClsOutput", "#odomMinOutput", "#odomMaxOutput",
	                          "#laborMinOutput", "#laborMaxOutput", "#blockExpOutput", "#blockCondOutput",
	                          "#subletOutput", "#transOutput", "#effStartOutput", 
	                          "#effEndOutput", "#descriptionOutput"];
	
	var blockElements = ["fg", "cg", "cc", "oc", "platform", "family", "condClass", 
	                     "odomMin", "odomMax", "laborMin", "laborMax", "blockExpense",
	                     "blockCondition", "sublet", "transaction", "effectiveStart",
	                     "effectiveEnd", "description"];
	
	//-------------------------UI functions----------------------------
	
	//Show / hide data update input fields
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		$('#blockInputDiv').show();
		$('.input-div').show();
		$('#insertBlockRule').show();
		
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('#blockInputDiv').show();
		$('.copy-div').show();
		$('.output-div').show();
		$('#updateBlockRule').show();
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		$('#blockInputDiv').show();
		$('.output-div').show();
		$('#deleteBlockRule').show();
	});
	
	$('#copyBtn').on('click', function() {
		copyInputVals(blockOutputElements, blockInputElements);
	});
	
	$('#blockInsertBtn').on('click', function() {
		
		if (validateForm('#blockInputDiv'))
		{
			var insertData = getInputData(blockElements, blockInputElements);
			insertData = convertToObject(insertData);
			postData(insertData, "insert-block-rule");
		}
	});
	
	$('#blockUpdateBtn').on('click', function() {
		if (validateForm('#blockInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var updateData = [];
			updateData.push({"id": selectedData.id});
			updateData.push(getInputData(blockElements, blockInputElements));
			updateData[1] = convertToObject(updateData[1]);
			postData(updateData, "update-block-rule");
		}
	});
	
	$('#blockDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = ({"id": selectedData.id});
			postData(deleteData, "delete-block-rule");
		}
	});
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable();
			}
		});
	}
	
	//Refresh table with new data
	function updateTable() {
		
		data = convertToTable(data);
			
		myTable = $('#blockTable').DataTable({
			data: data,
			scrollX: true,
			scrollY: "25em",
			columns: [
			     {title: 'Description', data: 'description'},
			     {title: 'Labor Operation', data: 'lop', className: "no-wrap", width: "150px"},
			     {title: 'Platform', data: 'platform'},
			     {title: 'Family Code', data: 'family'},
			     {title: 'Condition Class', data: 'condClass'},
			     {title: 'Minimum Odometer', data: 'odomMin'},
			     {title: 'Maximum Odometer', data: 'odomMax'},
			     {title: 'Minimum Labor Expense', data: 'laborMin'},
			     {title: 'Maximum Labor Expense', data: 'laborMax'},
			     {title: 'Block Expense', data: 'blockExpense',
			    	 render: function(data, type, row, meta) {
			    		 return renderCheckbox(data)}, display: 'display'
			     },
			     {title: 'Block Condition', data: 'blockCondition',
			    	 render: function(data, type, row, meta) {
			    		 return renderCheckbox(data)
			    	 }},
			     {title: 'Transaction Type', data: 'transaction'},
			     {title: 'Sublet', data: 'sublet'},
			     {title: 'Effective Start', data: 'effectiveStart', width: "80px"},
			     {title: 'Effective End', data: 'effectiveEnd', width: "80px"},
			     {title: 'Updated By', data: 'user'},
			     {title: 'Updated On', data: 'updateTime'},
			     {title: 'fg', data: 'fg', searchable: false, visible: false},
			     {title: 'cg', data: 'cg', searchable: false, visible: false},
			     {title: 'cc', data: 'cc', searchable: false, visible: false},
			     {title: 'oc', data: 'oc', searchable: false, visible: false}
			],
			dom: 'Bfrtip',
			buttons: [{
				extend: 'print',
				exportOptions: {
					stripHtml: false
				}
			}]
		});
		
		//Row selection
		$('#blockTable tbody').on( 'click', 'tr', function () {
	        clearInputVals(blockOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            setInputVals(selectedData, blockElements, blockOutputElements);
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {
		clearInputVals(blockInputElements);
		clearInputVals(blockOutputElements);
		
		if (myTable != null)
		{
			$('#blockTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable();
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
	//Convert an array of objects to table data
	//Blanks can not return for numeric types, so converting -1 to blank
	function convertToTable(dataArray) {
		for (var i = 0; i < dataArray.length; i++)
		{
			dataArray[i].lop = dataArray[i].fg + "-" + dataArray[i].cg + "-" + 
				dataArray[i].cc + "-" + dataArray[i].oc;
			
			if (dataArray[i].odomMin == -1)
				dataArray[i].odomMin = "";
			if (dataArray[i].odomMax == -1)
				dataArray[i].odomMax = "";
			if (dataArray[i].laborMin == -1)
				dataArray[i].laborMin = "";
			if (dataArray[i].laborMax == -1)
				dataArray[i].laborMax = "";
		}
		
		return dataArray;
	}
	
	function convertToObject(dataObj) {
		if (dataObj.blockCondition == true)
			dataObj.blockCondition = 1;
		else
			dataObj.blockCondition = 0;
		
		if (dataObj.blockExpense == true)
			dataObj.blockExpense = 1;
		else
			dataObj.blockExpense = 0;
		
		if (dataObj.odomMin == "")
			dataObj.odomMin = -1;
		if (dataObj.odomMax == "")
			dataObj.odomMax = -1;
		if (dataObj.laborMin == "")
			dataObj.laborMin = -1;
		if (dataObj.laborMax == "")
			dataObj.laborMax = -1;
		
		return dataObj;
	}
});