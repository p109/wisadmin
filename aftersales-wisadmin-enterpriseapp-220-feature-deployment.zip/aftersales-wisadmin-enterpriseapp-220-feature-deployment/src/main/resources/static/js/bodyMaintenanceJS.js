$(document).ready(function() {
	var myTable;
	var data;
	var selectedData;
	var dropSelection;
	
	//store these constants for UI and table updates
	var BODYRULE = 'bodyrule';
	var LAUNCHRULE = 'launchrule';
	var PLATFORMDESC = 'platformdesc';
	var PRODUCTDESC = 'productdesc';
	var PRICECLASSDESC= 'pricedesc';
	
	var bodyBaseElements = ["#myBody", "#plBody", "#platformBody", 
	                         "#familyBody", "#lineBody", "#seriesBody",
	                         "#bsBody", "#assyBody", "#scodeBody",
	                         "#blockBody", "#effStartBody", "#effEndBody",
	                         "#descriptionBody", "#locBody"];
	                         
	var massElements=["#massFrom","#massTo"];
	
	
	
	var launchBaseElements = ["#myLaunch", "#marketLaunch", "#familyLaunch", "#lineLaunch",
	                          "#seriesLaunch", "#bsLaunch", "#assyLaunch", "#scodeLaunch", 
	                          "#dateLaunch", "#effStartLaunch", "#effEndLaunch", "#locLaunch"];                     
	
	var productBaseElements = ["#plProduct", "#lopProduct", "#platformProduct", 
	                           "#descriptionProduct"];
	
	var platformBaseElements = ["#platformPlatform", "#descriptionPlatform"];
	
	var priceBaseElements=["#priceClassPrice","#priceClassDescriptionPrice"];
	
	
	var bodyInputElements = appendElements(bodyBaseElements, "Input");
	var bodyOutputElements = appendElements(bodyBaseElements, "Output");
	
	var launchInputElements = appendElements(launchBaseElements, "Input");
	var launchOutputElements = appendElements(launchBaseElements, "Output");
	
	var productInputElements = appendElements(productBaseElements, "Input");
	var productOutputElements = appendElements(productBaseElements, "Output");
	
	var platformInputElements = appendElements(platformBaseElements, "Input");
	var platformOutputElements = appendElements(platformBaseElements, "Output");
	
	var priceInputElements = appendElements(priceBaseElements, "Input");
	var priceOutputElements = appendElements(priceBaseElements, "Output");
	
	
	var bodyElements = ["modelYear", "productLine", "platform", "family", "line", "series",
	                    "bodyStyle", "assemblyPlant", "salesCodes", "block", "effectiveStart",
	                    "effectiveEnd", "description", "corpLoc"];
	
	var launchElements = ["modelYear", "market", "family", "line", "series", "bodyStyle",
	                      "assemblyPlant", "salesCode", "launchDate", "effectiveStart",
	                      "effectiveEnd", "corpLoc"];
	
	var productElements = ["productLine", "lopBook", "platform", "description"];
	
	var platformElements = ["platform", "description"];
	
	var priceElements= ["priceClass","priceClassDesc"];
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#bodySelect').on('change',function() {
		dropSelection = $(this).val();
		if (dropSelection == BODYRULE)
		{
			fetchTableData("get-body-rules", dropSelection);
		}
		if (dropSelection == LAUNCHRULE)
		{
			fetchTableData("get-launch-rules", dropSelection);
		}
		if (dropSelection == PLATFORMDESC)
		{
			fetchTableData("get-platform-desc", dropSelection);
		}
		if (dropSelection == PRODUCTDESC)
		{
			fetchTableData("get-product-desc", dropSelection);
		}
		if (dropSelection == PRICECLASSDESC)
		{
			fetchTableData("get-price-class-desc", dropSelection);
		}
		
	});
	
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		if (dropSelection == BODYRULE)
		{
			$('#bodyInputDiv').show();
			$('#insertBodyRule').show();
		}
		if (dropSelection == LAUNCHRULE)
		{
			$('#launchInputDiv').show();
			$('#insertLaunchRule').show();
		}
		if (dropSelection == PRODUCTDESC)
		{
			$('#productInputDiv').show();
			$('#insertProductLine').show();
		}
		if (dropSelection == PLATFORMDESC)
		{
			$('#platformInputDiv').show();
			$('#insertPlatformDesc').show();
		}
		if (dropSelection == PRICECLASSDESC)
		{
			$('#priceInputDiv').show();
			$('#insertPriceDesc').show();
		}
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('.output-div').show();
		$('.copy-div').show();
		if (dropSelection == BODYRULE)
		{
			$('#bodyInputDiv').show();
			$('#updateBodyRule').show();
		}
		if (dropSelection == LAUNCHRULE)
		{
			$('#launchInputDiv').show();
			$('#updateLaunchRule').show();
		}
		if (dropSelection == PRODUCTDESC)
		{
			$('#productInputDiv').show();
			$('#updateProductLine').show();
		}
		if (dropSelection == PLATFORMDESC)
		{
			$('#platformInputDiv').show();
			$('#updatePlatformDesc').show();
		}
		if (dropSelection == PRICECLASSDESC)
		{
			$('#priceInputDiv').show();
			$('#updatePriceDesc').show();
		}
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.output-div').show();
		if (dropSelection == BODYRULE)
		{
			$('#bodyInputDiv').show();
			$('#deleteBodyRule').show();
		}
		if (dropSelection == LAUNCHRULE)
		{
			$('#launchInputDiv').show();
			$('#deleteLaunchRule').show();
		}
		if (dropSelection == PRODUCTDESC)
		{
			$('#productInputDiv').show();
			$('#deleteProductLine').show();
		}
		if (dropSelection == PLATFORMDESC)
		{
			$('#platformInputDiv').show();
			$('#deletePlatformDesc').show();
		}
		if (dropSelection == PRICECLASSDESC)
		{
			$('#priceInputDiv').show();
			$('#deletePriceDesc').show();
		}
	});
	
	$('#massCopyBtn').on('click', function() {
		if (dropSelection == BODYRULE)
		{
			$('.toggle-div').hide();
			$('#massCopyDiv').show();
		}
		else{
			$('#massCopyDiv').hide();
		}
	});
	
	$('.copy-btn').on('click', function() {
		copyInputVals(bodyOutputElements, bodyInputElements);
		copyInputVals(launchOutputElements, launchInputElements);
		copyInputVals(productOutputElements, productInputElements);
		copyInputVals(platformOutputElements, platformInputElements);
		copyInputVals(priceOutputElements, priceInputElements);
	});
	
	$('#bodyInsertBtn').on('click', function() {
		var sendData = getInputData(bodyElements, bodyInputElements);
		sendData = convertToObject(sendData);
		postData(sendData, "modify-body-rules?action=I");
	});
	
	$('#bodyUpdateBtn').on('click', function() {
		var sendData = getInputData(bodyElements, bodyInputElements);
		sendData = convertToObject(sendData);
		sendData.id = selectedData.id;
		postData(sendData, "modify-body-rules?action=U");
		
	});
	
	$('#bodyDeleteBtn').on('click', function() {
		var sendData = {"id": selectedData.id};
		postData(sendData, "modify-body-rules?action=D");
	});
	
	$('#launchInsertBtn').on('click', function() {
		var sendData = getInputData(launchElements, launchInputElements);
		postData(sendData, "modify-launch-rules?action=I");
	});
	
	$('#launchUpdateBtn').on('click', function() {
		var sendData = getInputData(launchElements, launchInputElements);
		sendData.id = selectedData.id;
		postData(sendData, "modify-launch-rules?action=U");
	});
	
	$('#launchDeleteBtn').on('click', function() {
		var sendData = {"id": selectedData.id};
		postData(sendData, "modify-launch-rules?action=D");
	});
	
	$('#massBtn').on('click', function() {
		var sendData = {"copyFrom" : $('#massFrom').val(),
				"copyTo" : $('#massTo').val()
				};
		
		postData(sendData, "launch-mass-copy");
	});
	
	$('#productInsertBtn').on('click', function() {
		var sendData = getInputData(productElements, productInputElements);
		postData(sendData, "modify-product-desc?action=I");
	});
	
	$('#productUpdateBtn').on('click', function() {
		var sendData = getInputData(productElements, productInputElements);
		//These fields are the id fields
		sendData.oldProductLine = selectedData.productLine;
		sendData.oldPlatform = selectedData.platform;
		postData(sendData, "modify-product-desc?action=U");
	});
	
	$('#productDeleteBtn').on('click', function() {
		var sendData = getInputData(productElements, productOutputElements);
		postData(sendData, "modify-product-desc?action=D");
	});
	
	$('#platformInsertBtn').on('click', function() {
		var sendData = getInputData(platformElements, platformInputElements);
		postData(sendData, "modify-platform-desc?action=I");
	});
	
	$('#platformUpdateBtn').on('click', function() {
		var sendData = getInputData(platformElements, platformInputElements);
		sendData.oldPlatform = selectedData.platform;
		postData(sendData, "modify-platform-desc?action=U");
	});
	
	$('#platformDeleteBtn').on('click', function() {
		var sendData = getInputData(platformElements, platformOutputElements);
		postData(sendData, "modify-platform-desc?action=D");
	});
	
	$('#priceInsertBtn').on('click', function() {
		var sendData = getInputData(priceElements, priceInputElements);
		postData(sendData, "modify-price-class-desc?action=I");
	});
	
	$('#priceUpdateBtn').on('click', function() {
		var sendData = getInputData(priceElements, priceInputElements);
		sendData.oldPriceClass = selectedData.priceClass;
		postData(sendData, "modify-price-class-desc?action=U");
	});
	
	$('#priceDeleteBtn').on('click', function() {
		var sendData = getInputData(priceElements, priceOutputElements);
		postData(sendData, "modify-price-class-desc?action=D");
	});
	
	
	
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		
		//Body rule
		if (selection == BODYRULE)
		{
			myTable = $('#bodyTable').DataTable({
				data: data,
				columns: [
				   {title: 'Model Year', data: 'modelYear'},
				   {title: 'Product Line', data: 'productLine'},
				   {title: 'Family', data: 'family'},
				   {title: 'Line', data: 'line'},
				   {title: 'Series', data: 'series'},
				   {title: 'Platform', data: 'platform'},
				   {title: 'Body Style', data: 'bodyStyle'},
				   {title: 'Assembly Plant', data: 'assemblyPlant'},
				   {title: 'Corp Location', data: 'corpLoc'},
				   {title: 'Blocked', data: 'block', 
					   render: function(data, type, row, meta) {
			    		 return renderCheckbox(data)}, display: 'display'
				     },
				   {title: 'Sales Codes', data: 'salesCodes'},
				   {title: 'Start Date', data: 'effectiveStart'},
				   {title: 'End Date', data: 'effectiveEnd'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'},
				   {title: 'id', data: 'id', visible: false, searchable: false}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
			$('#massCopyBtn').show();
		}
		
		//Launch rule
		if (selection == LAUNCHRULE)
		{
			myTable = $('#bodyTable').DataTable({
				data: data,
				columns: [
				   {title: 'Model Year', data: 'modelYear'},
				   {title: 'Market', data: 'market'},
				   {title: 'Family', data: 'family'},
				   {title: 'Series', data: 'series'},
				   {title: 'Line', data: 'line'},
				   
				   {title: 'Body Style', data: 'bodyStyle'},
				   {title: 'Launch Date', data: 'launchDate'},
				   {title: 'Effective Start', data: 'effectiveStart'},
				   {title: 'Effective End', data: 'effectiveEnd'},
				   {title: 'Assembly Plant', data: 'assemblyPlant'},
				   {title: 'Corp Location', data: 'corpLoc'},
				   {title: 'Sales Codes', data: 'salesCode'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'},
				   
				   {title: 'id', data: 'id', visible: false, searchable: false}
				]
			});
			$('#massCopyBtn').hide();
		}
		
		if (selection == PLATFORMDESC)
		{
			myTable = $('#bodyTable').DataTable({
				data: data,
				columns: [
				    {title: 'Platform', data: 'platform'},
				    {title: 'Description', data: 'description'},
				    {title: 'Updated By', data: 'user'},
				    {title: 'Updated On', data: 'updateTime'}
				]
			});
			$('#massCopyBtn').hide();
		}
		
		if (selection == PRODUCTDESC)
		{
			myTable = $('#bodyTable').DataTable({
				data: data,
				columns: [
				    {title: 'Product Line', data: 'productLine'},
				    {title: 'Description', data: 'description'},
				    {title: 'Lop Book', data: 'lopBook'},
				    {title: 'Platform', data: 'platform'},
				    {title: 'Updated By', data: 'user'},
				    {title: 'Updated On', data: 'updateTime'}
				]
			});
			$('#massCopyBtn').hide();
		}
		
		if (selection == PRICECLASSDESC)
		{
			myTable = $('#bodyTable').DataTable({
				data: data,
				columns: [
				    {title: 'Price Class', data: 'priceClass'},
				    {title: 'Price Class Description', data: 'priceClassDesc'}
				]
			});
			$('#massCopyBtn').hide();
		}
		
		//Row selection
		$('#bodyTable tbody').on( 'click', 'tr', function () {
			clearInputVals(bodyOutputElements);
			clearInputVals(bodyInputElements);
			clearInputVals(launchOutputElements);
			clearInputVals(launchInputElements);
			clearInputVals(productInputElements);
			clearInputVals(productOutputElements);
			clearInputVals(platformInputElements);
			clearInputVals(platformOutputElements);
			clearInputVals(priceInputElements);
			clearInputVals(priceOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            if (selection == BODYRULE)
	            {
	            	setInputVals(selectedData, bodyElements, bodyOutputElements);
	            }
	            if (selection == LAUNCHRULE)
	            {
	            	setInputVals(selectedData, launchElements, launchOutputElements);
	            }
	            if (selection == PRODUCTDESC)
	            {
	            	setInputVals(selectedData, productElements, productOutputElements);
	            }
	            if (selection == PLATFORMDESC)
	            {
	            	setInputVals(selectedData, platformElements, platformOutputElements);
	            }
	            if (selection == PRICECLASSDESC)
	            {
	            	setInputVals(selectedData, priceElements, priceOutputElements);
	            }
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {
		clearInputVals(priceInputElements);
		clearInputVals(priceOutputElements);
		clearInputVals(platformInputElements);
		clearInputVals(platformOutputElements);
		clearInputVals(productInputElements);
		clearInputVals(productOutputElements);
		clearInputVals(launchInputElements);
		clearInputVals(launchOutputElements);
		clearInputVals(bodyInputElements);
		clearInputVals(bodyOutputElements);
		clearInputVals(massElements);
		if (myTable != null)
		{
			$('#bodyTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	//Pass in I, D, or U in the url action parameter
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(dropSelection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
	function convertToObject(dataObj) {
		if (dataObj.block == true)
			dataObj.block = 1;
		else
			dataObj.block = 0;
		
		return dataObj;
	}
});