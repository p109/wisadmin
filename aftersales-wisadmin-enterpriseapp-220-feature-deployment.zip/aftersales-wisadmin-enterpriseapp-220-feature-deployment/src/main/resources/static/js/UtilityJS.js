//Clear and set the inputs for update and delete inputs
function clearInputVals(inputFields)
{
	for (i = 0; i < inputFields.length; i++)
	{
		$(inputFields[i]).val('');
	}
}

function showError(data)
{
	$('body').append("<div class='alert alert-danger alert-dismissible fade show' role='alert'>" +
			data.errorMessage + "<button type='button' class='btn-close' " +
			"data-bs-dismiss='alert' aria-label='Close'></button>" +
			"</div>"
	)
}

/*
 * function setInputVals
 * myData is the json data, elements are the keys of the json data
 * inputFields are the ids of the HTML elements that populate when a table row is clicked
 * elements array and the fields array must be in the same order
 * eg: if the description is the first element in the elements array,
 * then the id of the HTML input for description must be the first
 * element in the fields array
*/
function setInputVals(myData, elements, inputFields)
{
	for (var key in myData) {
		if (myData.hasOwnProperty(key)) {
			var eIndex = elements.indexOf(key);
			
			//If the key from the data is actually in the array
			//There are data fields which are not editable or displayed on front end
			if (eIndex > -1) {
				var element = inputFields[eIndex];
				if ($(element).attr('type') == 'checkbox')
				{
					if (myData[key] == '1')
						$(element).prop('checked', true);
					else
						$(element).prop('checked', false);
				}
				else
				$(inputFields[eIndex]).val(myData[key]);
			}
		}
	}
}

//Copies input fields from copyFrom to copyTo
function copyInputVals(copyFrom, copyTo)
{
	for (i = 0; i < copyFrom.length; i++)
	{
		if ($(copyFrom[i]).attr('type') == 'checkbox')
		{
			$(copyTo[i]).prop('checked', $(copyFrom[i]).is(':checked'));
		}
		else
		$(copyTo[i]).val($(copyFrom[i]).val());
	}
}

//Creates a checkbox in the table
function renderCheckbox(data)
{
	if (data == '1')
		return "<input class='form-check-input' type='checkbox' checked disabled>";
	 	else
	 		return "<input class='form-check-input' type='checkbox' disabled>";
}

//Returns a JSON object using the keys and input fields from user
function getInputData(elements, fields)
{
	var myData = {};

	for (var i = 0; i < elements.length; i++)
	{
		var element = fields[i];
		if ($(element).attr('type') == 'checkbox')
		{
			myData[elements[i]] = $(element).is(':checked');
		}
		else
			myData[elements[i]] = $(fields[i]).val();
	}

	return myData;
}

//Elements have Input and Output added to them.
//See id of html
function appendElements(elements, append)
{
	var output = [];
	for (var i = 0; i < elements.length; i++)
	{
		output.push(elements[i] + append);
	}
	return output;
}

function validateForm(formId)
{
	if (!$(formId).data('validator'))
	{
		console.log("validator initalize");
		$(formId).validate({
			errorPlacement: function(error, element) {
		        if(element.parent('.input-group').length) {
		            error.insertAfter(element.parent());
		        } else {
		            error.insertAfter(element);
		        }
		    }
		});
	}

	return $(formId).valid();
}

//Load the header in every page
$(document).ready(function() {
	//Load in the nav and sidebars used on every page
	$('.nav-loader').load("html/header.html");
	$('.sidebar-loader').load("html/sidebar.html");
	
	//nav link should set active, but way it is implemented it doesn't
	//This is for insert/update/delete buttons
	$('.nav-link').on('click', function() {
		$('.nav-link').removeClass('active');
		$(this).addClass('active');
	});
	
	//Give all input boxes date-input class to use datepicker
	$('.date-input').datepicker({dateFormat: 'yy-mm-dd'}).on('change', function() {
		$(this).valid();
	});
})