$(document).ready(function() {
	$('#createRequest').on('click', function() {
		
	});
	$('#myRequest').on('click', function() {
		window.location.href = "workflow";
	});
	
	$('#approveRequest').on('click', function() {
		window.location.href = "workflow";
	});
	
	$('#allRequest').on('click', function() {
		window.location.href = "workflow";
	});
	
	$('#approvals').on('click', function() {
		window.location.href = "workflow-approvals";
	});
	
	$('#submitRequest').on('click', function() {
		var inputData = {'description': $('#descriptionInput').val()};
		postData(inputData, "insert-workflow-request");
	});
	
	function postData(myData, url) {

		$('#submitRequest').prop("disabled", true);
		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				window.location.href="workflow";
			},
			error: function(result) {
				showError(result.responseJSON[0]);
				$('#submitRequest').prop("disabled", false);
			}
		});
		
	}
});