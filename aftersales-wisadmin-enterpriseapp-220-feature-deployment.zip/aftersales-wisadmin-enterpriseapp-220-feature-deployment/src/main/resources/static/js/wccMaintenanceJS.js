$(document).ready(function() {
	var myTable;
	var data;
	var selectedData = {};
	var dropSelection
	
	var WCCDESC = "wdesc";
	var WRULE = "wrule";
	var WCLASS = "wclass";
	var COCLASS = "coclass";
	var COCVRG = "cocvrg";
	
	var descBaseElements = ["#wccDesc", "#descDesc"];
	var ruleBaseElements = ["#wccRule", "#monthRule", "#mileRule", "#startRule", "#endRule"];
	var classBaseElements = ["#idClass", "#condClass", "#transClass"];
	var condBaseElements = ["#condCond", "#descCond"];
	
	//Generates the html element tags for input (user editable) and output (not editable)
	var descInputElements = appendElements(descBaseElements, "Input");
	var descOutputElements = appendElements(descBaseElements, "Output");
	var ruleInputElements = appendElements(ruleBaseElements, "Input");
	var ruleOutputElements = appendElements(ruleBaseElements, "Output");
	var classInputElements = appendElements(classBaseElements, "Input");
	var classOutputElements = appendElements(classBaseElements, "Output");
	var condInputElements = appendElements(condBaseElements, "Input");
	var condOutputElements = appendElements(condBaseElements, "Output");
	
	var descElements = ["wcc", "wccDesc"];
	var ruleElements = ["wcc", "monthLimit", "mileLimit", "effectiveStart", "effectiveEnd"];
	var classElements = ["id", "conditionClass", "transaction"];
	var condElements = ["code", "desc"];
	
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#wccSelect').on('change',function() {
		dropSelection = $(this).val();
		if (dropSelection == WCCDESC)
		{
			fetchTableData("get-wcc-desc", dropSelection);
		}
		if (dropSelection == WRULE)
		{
			fetchTableData("get-wcc-rule", dropSelection);
		}
		if (dropSelection == WCLASS)
		{
			fetchTableData("get-wcc-class", dropSelection);
		}
		if (dropSelection == COCLASS)
		{
			fetchTableData("get-cond-class", dropSelection);
		}
		if (dropSelection == COCVRG)
		{
			fetchTableData("get-cond-coverage", dropSelection);
		}
		
	});
	
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		
		if (dropSelection == WCCDESC)
		{
			$('#descriptionInputDiv').show();
			$('#insertDesc').show();
		}
		if (dropSelection == WRULE)
		{
			$('#ruleInputDiv').show();
			$('#insertRule').show();
		}
		if (dropSelection == WCLASS)
		{
			$('#classInputDiv').show();
			$('#insertClass').show();
		}
		if (dropSelection == COCLASS)
		{
			$('#condInputDiv').show();
			$('#insertCond').show();
		}
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('.copy-div').show();
		$('.output-div').show();
		
		if (dropSelection == WCCDESC)
		{
			$('#descriptionInputDiv').show();
			$('#updateDesc').show();
		}
		if (dropSelection == WRULE)
		{
			$('#ruleInputDiv').show();
			$('#updateRule').show();
		}
		if (dropSelection == WCLASS)
		{
			$('#classInputDiv').show();
			$('#updateClass').show();
		}
		if (dropSelection == COCLASS)
		{
			$('#condInputDiv').show();
			$('#updateCond').show();
		}
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.output-div').show();
		
		if (dropSelection == WCCDESC)
		{
			$('#descriptionInputDiv').show();
			$('#deleteDesc').show();
		}
		if (dropSelection == WRULE)
		{
			$('#ruleInputDiv').show();
			$('#deleteRule').show();
		}
		if (dropSelection == WCLASS)
		{
			$('#classInputDiv').show();
			$('#deleteClass').show();
		}
		if (dropSelection == COCLASS)
		{
			$('#condInputDiv').show();
			$('#deleteCond').show();
		}
	});
	
	$('#descInsertBtn').on('click', function() {
		if (validateForm('#descriptionInputDiv'))
		{
			var sendData = getInputData(descElements, descInputElements);
			postData(sendData, "modify-wcc-desc?action=I");
		}
	});
	
	$('#descUpdateBtn').on('click', function() {
		if (validateForm('#descriptionInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(descElements, descInputElements);
			sendData.oldWcc = selectedData.wcc;
			postData(sendData, "modify-wcc-desc?action=U");
		}
	});
	
	$('#descDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(descElements, descOutputElements);
			postData(sendData, "modify-wcc-desc?action=D");
		}
	});
	
	$('#ruleInsertBtn').on('click', function() {
		if (validateForm('#ruleInputDiv'))
		{
			var sendData = getInputData(ruleElements, ruleInputElements);
			postData(sendData, "modify-wcc-rule?action=I");
		}
	});
	
	$('#ruleUpdateBtn').on('click', function() {
		if (validateForm('#ruleInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(ruleElements, ruleInputElements);
			sendData.id = selectedData.id;
			postData(sendData, "modify-wcc-rule?action=U");
		}
	});
	
	$('#ruleDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			postData(selectedData, "modify-wcc-rule?action=D");
		}
	});
	
	$('#classInsertBtn').on('click', function() {
		if (validateForm('#classInputDiv'))
		{
			var sendData = getInputData(classElements, classInputElements);
			postData(sendData, "modify-wcc-class?action=I");
		}
	});
	
	$('#classUpdateBtn').on('click', function() {
		if (validateForm('#classInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = [];
			sendData.push(selectedData);
			sendData.push(getInputData(classElements, classInputElements));
			postData(sendData, "update-wcc-class?action=U");
		}
	});
	
	$('#classDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			postData(selectedData, "modify-wcc-class?action=D");
		}
	});

	$('#condInsertBtn').on('click', function() {
		if (validateForm('#condInputDiv'))
		{
			var sendData = getInputData(condElements, condInputElements);
			postData(sendData, "modify-cond-class?action=I");
		}
	});

	$('#condUpdateBtn').on('click', function() {
		if (validateForm('#condInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(condElements, condInputElements);
			sendData.oldCode = selectedData.code;
			postData(sendData, "modify-cond-class?action=U");
		}
	});

	$('#condDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			postData(selectedData, "modify-cond-class?action=D");
		}
	});
	
	$('.copy-btn').on('click', function() {
		copyInputVals(descOutputElements, descInputElements);
		copyInputVals(classOutputElements, classInputElements);
		copyInputVals(ruleOutputElements, ruleInputElements);
		copyInputVals(condOutputElements, condInputElements);
	});
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		$('.modify-table-div').show();
		//Body rule
		if (selection == WCCDESC)
		{
			myTable = $('#wccTable').DataTable({
				data: data,
				columns: [
				   {title: 'WCC', data: 'wcc'},
				   {title: 'Description', data: 'wccDesc'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		if (selection == WRULE)
		{
			myTable = $('#wccTable').DataTable({
				data: data,
				columns: [
				   {title: 'ID', data: 'id'},
				   {title: 'WCC', data: 'wcc'},
				   {title: 'Month Limit', data: 'monthLimit'},
				   {title: 'Mile Limit', data: 'mileLimit'},
				   {title: 'Start Date', data: 'effectiveStart'},
				   {title: 'End Date', data: 'effectiveEnd'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		if (selection == WCLASS)
		{
			myTable = $('#wccTable').DataTable({
				data: data,
				columns: [
				   {title: 'ID', data: 'id'},
				   {title: 'Condition Class', data: 'conditionClass'},
				   {title: 'Transaction', data: 'transaction'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}

		if (selection == COCLASS)
		{
			console.log("selection is COCLASS");
			myTable = $('#wccTable').DataTable({
				data: data,
				columns: [
					{title: 'Condition Code', data: 'code'},
					{title: 'Description', data: 'desc'},
					{title: 'Updated By', data: 'user'},
					{title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}

		if (selection == COCVRG)
		{
			myTable = $('#wccTable').DataTable({
				data: data,
				columns: [
					{title: 'Coverage', data: 'wcc'},
					{title: 'Coverage Description', data: 'wccDesc', searchable: false},
					{title: 'Condition Class', data: 'condClass'},
					{title: 'Class Description', data: 'classDesc', searchable: false}
				],
				dom: 'Bfrtip',
				button: ['print']
			});
			$('.modify-table-div').hide();
		}
		
		//Row selection
		$('#wccTable tbody').on( 'click', 'tr', function () {

			clearInputVals(descInputElements);
			clearInputVals(descOutputElements);
			clearInputVals(ruleInputElements);
			clearInputVals(ruleOutputElements);
			clearInputVals(classInputElements);
			clearInputVals(classOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            if (selection == WCCDESC)
	            {
	            	setInputVals(selectedData, descElements, descOutputElements);
	            }
	            
	            if (selection == WRULE)
	            {
	            	setInputVals(selectedData, ruleElements, ruleOutputElements);
	            }
	            
	            if (selection == WCLASS)
	            {
	            	setInputVals(selectedData, classElements, classOutputElements);
				}

				if (selection == COCLASS)
				{
					setInputVals(selectedData, condElements, condOutputElements);
				}
	        }
	    } );
	}
		
	//Empty existing table contents
	function emptyTable() {

		clearInputVals(descInputElements);
		clearInputVals(descOutputElements);
		clearInputVals(ruleInputElements);
		clearInputVals(ruleOutputElements);
		clearInputVals(classInputElements);
		clearInputVals(classOutputElements);
		clearInputVals(condInputElements);
		clearInputVals(condOutputElements);

		$('.toggle-div').hide();
		selectedData = {};
		if (myTable != null)
		{
			$('#wccTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	//Pass in I, D, or U in the url action parameter
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(dropSelection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
		
	}
});