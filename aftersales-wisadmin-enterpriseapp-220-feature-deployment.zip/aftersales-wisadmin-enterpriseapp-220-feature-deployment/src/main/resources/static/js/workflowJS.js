$(document).ready(function() {
	var myTable;
	var tableData;
	var selectedData = {};
	var dropSelection = "";
	
	workflowInputElements = ["#workflowRequestDescInput"];
	workflowOutputElements = ["#workflowIdOutput", "#workflowRequestDescOutput", "#workflowRequestorOutput"];
	
	workflowElements = ["id", "description", "requestor"];
	
	fetchTableData("get-workflow-requests", dropSelection);
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				tableData = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	$('#createRequestBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('#workflowInputDiv').show();
		$('#insertWorkflow').show();
	});
	
	$('#approvalRequestBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.output-div').show();
		$('#workflowInputDiv').show();
		$('#approveWorkflow').show();
	});
	
	$('#workflowCreateRequestBtn').on('click', function() {
		var inputData = {'description': $('#workflowRequestDescInput').val()};
		postData(inputData, "insert-workflow-request");
	});
	
	$('#approveRequestBtn').on('click', function(){
		if (!jQuery.isEmptyObject(selectedData))
		{
			postData(selectedData, "action-workflow-request?action=A");
		}
	});
	
	$('#rejectRequestBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			postData(selectedData, "action-workflow-request?action=R");
		}
	});
	
	
	
	
	
	//Refresh table with new data
	function
	 updateTable(selection) {
		
		//Body rule
		if (selection == "")
		{
			myTable = $('#workflowTable').DataTable({
				data: tableData.requestList,
				columns: [
				   {title: 'ID', data: 'id'},
				   {title: 'Requestor', data: 'requestor'},
				   {title: 'Description', data: 'description'},
				   {title: 'Status', data: 'status'},
				   {title: 'Submitted On', data: 'requestTime'},
				   {title: 'Completed On', data: 'completeTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		//Row selection
		$('#workflowTable tbody').on( 'click', 'tr', function () {

			clearInputVals(workflowInputElements);
			clearInputVals(workflowOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            setInputVals(selectedData, workflowElements, workflowOutputElements);
	            displayWorkflow(selectedData, tableData);
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {

		clearInputVals(workflowInputElements);
		clearInputVals(workflowOutputElements);
		$('#cardDiv').empty();
		selectedData = {};
		if (myTable != null)
		{
			$('#workflowTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	
	
	//-------------------------------Card Display functions---------------------------
	
	
	//Displays a card and returns the amount of space a card took up
	function displayCard(title, text, div, end, size, cardClass,workflowData,grayOut)
	{
		var divString = "<div class='card col-md-" + size + " " + cardClass + "'>" + 
		"<div class='card-body'>" ;
		divString += "<h5 class='card-title'>" + title + "</h5>";
		
		if (text != "")
		{
			divString += "<p class='card-text'>" + text + "</p>";
		}
		if(workflowData.status == "P" ){
			if(title!="Start" && title!="End"){
				if(grayOut=="true"){
					divString += "<button id='infoButton' ><i class='fas fa-info'></i></button>";
				}
			}
		}
		divString += "</div></div>";
	
		$(div).append(divString);
		
		$('.fa-info').unbind('click');
		$('.fa-info').on('click', function() {
		console.log("counter for ajax call " );
			$.ajax({
			url: 'get-approver-list',
			data: {
       			  'requestId': workflowData.id,
      		 },
			method: "GET",
			contentType: "application/json",
			success: function(result) {
				data = result;
				$('#main-list').empty();
				for (var i = 0; i < data.length; i++)
				{
				  $('#main-list').append("<li>" + data[i] + "</li>");
				}
				$('#approvalModal').modal('show');
			},
			error: function(result) {
				 alert('error');
			}
			});
		});
		
		
		
		
		//Add more arrows to suggest next steps if it isn't the end
		if (!end)
		{
			divString = "<div class='col-md-1'>";
			divString += "<i class='fas fa-caret-right fa-3x center-icon'></i></div>";
			$(div).append(divString);
		}
		console.log(size + (!end));
		return size + (!end);
	}
	
	function addCardRow(div, rowNum)
	{
		$(div).append("</div><div class='row card-row' id='cardRow" + rowNum + "'>");
		return "#cardRow" + rowNum;
	}
	
	function compareStep(a, b) {
		if (a.step > b.step)
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}
	
	function getApprovalList(id, list)
	{
		var approvalList = [];
		for (var i = 0; i < list.length; i++)
		{
			if (list[i].requestId == id)
			{
				approvalList.push(list[i]);
			}
		}
		approvalList.sort(compareStep);
		return approvalList;
	}

	function displayWorkflow(workflowData, fullData) {
		//Shows completed steps from approved and future workflow steps if pending
		var displayDiv = "#cardDiv";
		var rowNum = 1;
		var rowDiv;
		var approvalList;
		
		$(displayDiv).empty();

		//This counter keeps track of how many cards are in the row and
		//adds new rows when we run out of space
		colCounter = 0;
		$(displayDiv).append("<div class='row card-row' id='cardRow1'>");
		rowDiv = "#cardRow1";
		colCounter += displayCard("Start", "", rowDiv, false, 1, "",workflowData,"");
		console.log("counter: " + colCounter);
		if (workflowData.status == "P")
		{
			 approvalList = getApprovalList(workflowData.id, fullData.approvedList);
			var grayOut = false;

			fullData.stepList.sort(compareStep);
			
			for (var i = 0; i < fullData.stepList.length; i++)
			{
				console.log("counter: " + colCounter);
				//Insert new row if we ran out of space
				if (colCounter > 9)
				{
					rowNum++;
					rowDiv = addCardRow(displayDiv, rowNum);
					colCounter = 0;
				}
				
				//If a request is pending, there are no steps that have been rejected
				if (i < approvalList.length)
				{
					colCounter += displayCard(approvalList[i].name, 
							"Approved by " + approvalList[i].approver, rowDiv, false, 2, "",workflowData,"");
				}
				else
				{
					if (grayOut)
					{
						colCounter += displayCard(fullData.stepList[i].name, 
							fullData.stepList[i].group + " must approve", 
							rowDiv, false, 2, "gray-card",workflowData,"");
					}
					else
					{
						colCounter += displayCard(fullData.stepList[i].name, 
								fullData.stepList[i].group + " must approve", 
								rowDiv, false, 2, "",workflowData,"true");
						grayOut = true;
					}
				}
			}
		}
		else
		{
			//Shows only completed steps if not pending
			 approvalList = getApprovalList(workflowData.id, fullData.approvedList);
			for (var i = 0; i < approvalList.length; i++)
			{
				if (colCounter > 9)
				{
					rowNum++;
					rowDiv = addCardRow(displayDiv, rowNum);
					colCounter = 0;
				}
				
				if (approvalList[i].status == "A")
				{
					colCounter += displayCard(approvalList[i].name, 
						"Approved by " + approvalList[i].approver, rowDiv, false, 2, "",workflowData,"");
				}
				else
				{
					colCounter += displayCard(approvalList[i].name,
							"Rejected by " + approvalList[i].approver, rowDiv, false, 2, "",workflowData,"");
				}
			}
		}
		
		if (colCounter >= 12)
		{
			rowNum++;
			rowDiv = addCardRow(displayDiv, rowNum);
		}
		displayCard("End", "", rowDiv, true, 1, "",workflowData,"");
		$(displayDiv).append("</div>");
	}
	
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	//Pass in I, D, or U in the url action parameter
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				tableData = result;
				emptyTable();
				updateTable(dropSelection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
		
	}
	
	
	
	
});