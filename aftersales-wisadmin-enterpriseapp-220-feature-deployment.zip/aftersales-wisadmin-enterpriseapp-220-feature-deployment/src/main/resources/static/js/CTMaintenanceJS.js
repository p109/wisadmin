$(document).ready(function() {
	var myTable;
	var data;
	var selectedData;
	var dropSelection;
	
	//store these constants for UI and table updates
	var CTDESC = 'ctdesc';
	var CTCDESC = 'ctcdesc';
	var CTRULE = 'ctrule';
	
	//Input field elements
	var insertCTElements = ["#ctInsertInput", "#descInsertInput"];
	var updateCTElements = ["#ctUpdateOld", "#descUpdateOld"];
	var deleteCTElements = ["#ctDeleteInput", "#descDeleteInput"];
	
	var insertCTCElements = ["#ctcInsertInput", "#ctcDescInsertInput"];
	var updateCTCElements = ["#ctcUpdateOld", "#ctcDescUpdateOld"];
	var deleteCTCElements = ["#ctcDeleteInput", "#ctcDescDeleteInput"];
	
	var insertCTRElements = ["#ctRuleInsertInput", "#ctcRuleInsertInput", "#plRuleInsertInput",
	                         "#epRuleInsertInput", "#tpRuleInsertInput", "#scodeRuleInsertInput",
	                         "#bldStartInsertInput", "#bldEndInsertInput",
	                         "#effStartInsertInput", "#effEndInsertInput"];
	var updateCTRElements = ["#ctRuleUpdateOld", "#ctcRuleUpdateOld", "#plRuleUpdateOld",
	                         "#epRuleUpdateOld", "#tpRuleUpdateOld", "#scodeRuleUpdateOld",
	                         "#bldStartUpdateOld", "#bldEndUpdateOld", "#effStartUpdateOld",
	                         "#effEndUpdateOld"];
	var deleteCTRElements = ["#ctRuleDeleteInput", "#ctcRuleDeleteInput", "#plRuleDeleteInput",
	                         "#epRuleDeleteInput", "#tpRuleDeleteInput", "#scodeRuleDeleteInput",
	                         "#bldStartDeleteInput", "#bldEndDeleteInput",
	                         "#effStartDeleteInput", "#effEndDeleteInput"];
	//Copy to field when clicking copy button
	var copyCTElements = ["#ctUpdateNew", "#descUpdateNew"];
	var copyCTCElements = ["#ctcUpdateNew", "#ctcDescUpdateNew"];
	var copyCTRElements = ["#ctRuleUpdateNew", "#ctcRuleUpdateNew", "#plRuleUpdateNew",
	                         "#epRuleUpdateNew", "#tpRuleUpdateNew", "#scodeRuleUpdateNew",
	                         "#bldStartUpdateNew", "#bldEndUpdateNew", "#effStartUpdateNew",
	                         "#effEndUpdateNew"];
	//Order of keys to elements
	var ctElements = ["ct", "ctDesc"];
	var ctcElements = ["ctClass", "classDesc"];
	var ctrElements = ["ct", "ctClass", "productLine", "enginePlant", "transPlant",
	                   "scodePattern", "buildStart", "buildEnd", "effectiveStart",
	                   "effectiveEnd"];
	
	
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#ctSelect').on('change',function() {
		dropSelection = $(this).val();
		if ($(this).val() == CTDESC)
		{
			fetchTableData("get-ct-desc", $(this).val());
		}
		
		if ($(this).val() == CTCDESC)
		{
			fetchTableData("get-ctc-desc", $(this).val());
		}
		
		if ($(this).val() == CTRULE)
		{
			fetchTableData("get-ct-rule", $(this).val());
		}
	});
	
	//Insert data into ct desc
	$('#ctInsertBtn').on('click', function() {
			var insertData = getInputData(ctElements, insertCTElements);
			postData(insertData, "insert-ct-desc", CTDESC);
	});
	
	$('#ctcInsertBtn').on('click', function() {
			var insertData = getInputData(ctcElements, insertCTCElements);
			postData(insertData, "insert-ct-class", CTCDESC);
	});
	
	$('#ctRuleInsertBtn').on('click', function() {
			var insertData = getInputData(ctrElements, insertCTRElements);
			postData(insertData, "insert-ct-rule", CTRULE);
	});
	
	//Update data on ct desc
	$('#ctUpdateBtn').on('click', function() {
			var updateData = [];
			updateData.push(getInputData(ctElements, updateCTElements));
			updateData.push(getInputData(ctElements, copyCTElements));

			postData(updateData, "update-ct-desc", CTDESC);
	});
	
	$('#ctcUpdateBtn').on('click', function() {
			var updateData = [];
			updateData.push(getInputData(ctcElements, updateCTCElements));
			updateData.push(getInputData(ctcElements, copyCTCElements));
		
			postData(updateData, "update-ct-class", CTCDESC);
	});
	
	$('#ctRuleUpdateBtn').on('click', function() {
			var updateData = [];
			updateData.push({"id": selectedData.id});
			updateData.push(getInputData(ctrElements, copyCTRElements));
		
			postData(updateData, "update-ct-rule", CTRULE);
	});
	
	//Delete data from ct desc
	$('#ctDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = getInputData(ctElements, deleteCTElements);
			postData(deleteData, "delete-ct-desc", CTDESC);
		}
	});
	
	$('#ctcDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = getInputData(ctcElements, deleteCTCElements);
			postData(deleteData, "delete-ct-class", CTCDESC);
		}
	});
	
	$('#ctRuleDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = {"id": selectedData.id};
			postData(deleteData, "delete-ct-rule", CTRULE);
		}
	});
	
	$('.copy-btn').on('click', function() {
		copyInputVals(updateCTElements, copyCTElements);
		copyInputVals(updateCTCElements, copyCTCElements);
		copyInputVals(updateCTRElements, copyCTRElements);
	});
	
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		if (dropSelection == CTDESC)
		{
			$('#insertCtDesc').show();
		}
		if (dropSelection == CTCDESC)
		{
			$('#insertCtcDesc').show();
		}
		if (dropSelection == CTRULE)
		{
			$('#insertCtRule').show();
		}
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		if (dropSelection == CTDESC)
		{
			$('#updateCtDesc').show();
		}
		if (dropSelection == CTCDESC)
		{
			$('#updateCtcDesc').show();
		}
		if (dropSelection == CTRULE)
		{
			$('#updateCtRule').show();
		}
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		if (dropSelection == CTDESC)
		{
			$('#deleteCtDesc').show();
		}
		if (dropSelection == CTCDESC)
		{
			$('#deleteCtcDesc').show();
		}
		if (dropSelection == CTRULE)
		{
			$('#deleteCtRule').show();
		}
	});
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		//Component type
		
		if (selection == CTDESC)
		{	
			//Need to handle < symbols before loading table
			for (var i = 0; i < data.length; i++)
			{
				var element = data[i];
				element.ctDesc = element.ctDesc.replace("<","&#60;");
			}
			
			myTable = $('#CTTable').DataTable({
				data: data,
				columns: [
				     {title: 'Component Type', data: 'ct'},
				     {title: 'Description', data: 'ctDesc'},
				     {title: 'Updated By', data: 'user'},
				     {title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}

		//Class description
		if (selection == CTCDESC)
		{
			myTable = $('#CTTable').DataTable({
				data: data,
				columns: [
				   {title: 'Component Type Class', data: 'ctClass'},
				   {title: 'Description', data: 'classDesc'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'}
				],
				buttons: ['print']
			});
		}
		
		//Rule maintenance
		if (selection == CTRULE)
		{
			//Need to handle < symbols before loading table
			for (var i = 0; i < data.length; i++)
			{
				var element = data[i];
				element.ctDesc = element.ctDesc.replace("&", "&amp;");
				element.ctDesc = element.ctDesc.replace("<","&#60;");
				element.ct = element.ct.replace("&", "&amp;");
			}
			myTable = $('#CTTable').DataTable({
				data: data.ruleList,
				columns: [
				  {title: 'Component Type', data: 'ct'},
				  {title: 'Component Type Class', data: 'ctClass'},
				  {title: 'Engine Plant', data: 'enginePlant'},
				  {title: 'Transmission Plant', data: 'transPlant'},
				  {title: 'Built From', data: 'buildStart'},
				  {title: 'Built To', data: 'buildEnd'},
				  {title: 'Effective Start', data: 'effectiveStart'},
				  {title: 'Effective End', data: 'effectiveEnd'},
				  {title: 'Product Line', data: 'productLine'},
				  {title: 'Sales Code Pattern', data: 'scodePattern'},
				  {title: 'Updated By', data: 'user'},
				  {title: 'Updated On', data: 'updateTime'},
				  {title: 'Description', data: 'description'},
				  {title: 'ID', data: 'id', visible: false}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		//Row selection
		$('#CTTable tbody').on( 'click', 'tr', function () {
	        
	        clearInputVals(updateCTElements);
	        clearInputVals(deleteCTElements);
	        clearInputVals(updateCTCElements);
	        clearInputVals(deleteCTCElements);
	        clearInputVals(updateCTRElements);
	        clearInputVals(deleteCTRElements);
	        clearInputVals(copyCTElements);
	        clearInputVals(copyCTCElements);
	        clearInputVals(copyCTRElements);
	        
	        selectedData = {};
	        
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            //copy row data to input fields
	            if (selection == CTDESC)
	            {
	            	setInputVals(selectedData, ctElements, updateCTElements);
	            	setInputVals(selectedData, ctElements, deleteCTElements);
	            }
	            if (selection == CTCDESC)
	            {
	            	setInputVals(selectedData, ctcElements, updateCTCElements);
	            	setInputVals(selectedData, ctcElements, deleteCTCElements);
	            }
	            if (selection == CTRULE)
	            {
	            	setInputVals(selectedData, ctrElements, updateCTRElements);
	            	setInputVals(selectedData, ctrElements, deleteCTRElements);
	            }
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {
		if (myTable != null)
		{
			clearInputVals(insertCTElements);
			clearInputVals(updateCTElements);
	        clearInputVals(deleteCTElements);
	        clearInputVals(insertCTCElements);
	        clearInputVals(updateCTCElements);
	        clearInputVals(deleteCTCElements);
	        clearInputVals(insertCTRElements);
	        clearInputVals(updateCTRElements);
	        clearInputVals(deleteCTRElements);
	        clearInputVals(copyCTElements);
	        clearInputVals(copyCTCElements);
	        clearInputVals(copyCTRElements);
	        
			$('#CTTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	function postData(myData, url, selection) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
});