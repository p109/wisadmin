$(document).ready(function() {
	var myTable;
	var data;
	var selectedData;
	var dropSelection;
	
	//store these constants for UI and table updates
	var COMMODITYDIR= 'commoditydir';
	var QUALITYMGR= 'qualitymgr';
	
	var commodityBaseElements=["#idCommodity","#directorNameCommodity","#directorTypeCommodity"];
	var qualityBaseElements=["#qualityManagerQuality","#qualityManagerDescriptionQuality","#commodityDirectorQuality"];
	
	var commodityInputElements = appendElements(commodityBaseElements, "Input");
	var commodityOutputElements = appendElements(commodityBaseElements, "Output");
	
	var qualityInputElements = appendElements(qualityBaseElements, "Input");
	var qualityOutputElements = appendElements(qualityBaseElements, "Output");
	
	var commodityElements= ["id","directorName","directorType"];
	var qualityElements= ["qualityManager","qualityManagerDescription","commodityDirector"];
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#bodySelect').on('change',function() {
		dropSelection = $(this).val();
		if (dropSelection == COMMODITYDIR)
		{
			fetchTableData("get-commodity-director", dropSelection);
		}
		if (dropSelection == QUALITYMGR)
		{
			fetchTableData("get-quality-manager", dropSelection);
		}
		
	});
	
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		if (dropSelection == COMMODITYDIR)
		{
			$('#commodityInputDiv').show();
			$('#insertCommodityDir').show();
		}
		if (dropSelection == QUALITYMGR)
		{
			$('#qualityInputDiv').show();
			$('#insertQualityMgr').show();
		}
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('.output-div').show();
		$('.copy-div').show();
		if (dropSelection == COMMODITYDIR)
		{
			$('#commodityInputDiv').show();
			$('#updateCommodityDir').show();
		}
		if (dropSelection == QUALITYMGR)
		{
			$('#qualityInputDiv').show();
			$('#updateQualityMgr').show();
		}
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.output-div').show();
		if (dropSelection == COMMODITYDIR)
		{
			$('#commodityInputDiv').show();
			$('#deleteCommodityDir').show();
		}
		if (dropSelection == QUALITYMGR)
		{
			$('#qualityInputDiv').show();
			$('#deleteQualityMgr').show();
		}
	});
	
	
	
	$('.copy-btn').on('click', function() {
		copyInputVals(commodityOutputElements, commodityInputElements);
		copyInputVals(qualityOutputElements, qualityInputElements);
	});
	
	
	$('#commodityInsertBtn').on('click', function() {
		var sendData = getInputData(commodityElements, commodityInputElements);
		postData(sendData, "modify-commodity-director?action=I");
	});
	
	$('#commodityUpdateBtn').on('click', function() {
		var sendData = getInputData(commodityElements, commodityInputElements);
		sendData.oldId = selectedData.id;
		postData(sendData, "modify-commodity-director?action=U");
	});
	
	$('#commodityDeleteBtn').on('click', function() {
		var sendData = getInputData(commodityElements, commodityOutputElements);
		postData(sendData, "modify-commodity-director?action=D");
	});
	
	$('#qualityInsertBtn').on('click', function() {
		var sendData = getInputData(qualityElements, qualityInputElements);
		postData(sendData, "modify-quality-manager?action=I");
	});
	
	$('#qualityUpdateBtn').on('click', function() {
		var sendData = getInputData(qualityElements, qualityInputElements);
		sendData.oldManager = selectedData.qualityManager;
		postData(sendData, "modify-quality-manager?action=U");
	});
	
	$('#qualityDeleteBtn').on('click', function() {
		var sendData = getInputData(qualityElements, qualityOutputElements);
		postData(sendData, "modify-quality-manager?action=D");
	});
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		
		
		if (selection == COMMODITYDIR)
		{
			myTable = $('#bodyTable').DataTable({
				data: data,
				columns: [
				    {title: 'Id', data: 'id'},
				    {title: 'Director Name', data: 'directorName'},
				    {title: 'Director Type Class', data: 'directorType'},
				    {title: 'User', data: 'user'},
				    {title: 'Update Time', data: 'updateTime'}
				]
			});
		}
		
		if (selection == QUALITYMGR)
		{
			myTable = $('#bodyTable').DataTable({
				data: data,
				columns: [
				    {title: 'Quality Manager', data: 'qualityManager'},
				    {title: 'Quality Manager Description', data: 'qualityManagerDescription'},
				    {title: 'Commodity Director', data: 'commodityDirector'},
				    {title: 'User', data: 'user'},
				    {title: 'Update Time', data: 'updateTime'}
				]
			});
		}
		
		//Row selection
		$('#bodyTable tbody').on( 'click', 'tr', function () {
			clearInputVals(commodityInputElements);
			clearInputVals(commodityOutputElements);
			clearInputVals(qualityInputElements);
			clearInputVals(qualityOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            if (selection == COMMODITYDIR)
	            {
	            	setInputVals(selectedData, commodityElements, commodityOutputElements);
	            }
	             if (selection == QUALITYMGR)
	            {
	            	setInputVals(selectedData, qualityElements, qualityOutputElements);
	            }
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {

		clearInputVals(commodityInputElements);
		clearInputVals(commodityOutputElements);
		clearInputVals(qualityInputElements);
		clearInputVals(qualityOutputElements);
		if (myTable != null)
		{
			$('#bodyTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	//Pass in I, D, or U in the url action parameter
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(dropSelection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
});