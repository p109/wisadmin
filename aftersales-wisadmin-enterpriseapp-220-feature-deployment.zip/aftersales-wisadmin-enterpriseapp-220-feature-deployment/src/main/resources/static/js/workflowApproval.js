$(document).ready(function() {
	var myTable;
	var data;
	var selectedData = {};
	var dropSelection = "";
	
	fetchTableData("get-workflow-requests", dropSelection);
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	
	//Refresh table with new data
	function updateTable(selection) {
	
		var finalList = new Array();
		var approvedList=data.approvedList;
		var requestList=data.requestList;
		for(var i =0; i< approvedList.length; i++){
			for(var j=0; j<requestList.length; j++){
				if(approvedList[i].requestId == requestList[j].id){
					finalList.push(new resultTable(
					approvedList[i].approver,
					approvedList[i].name,
					approvedList[i].requestId,
					approvedList[i].status,
					approvedList[i].actionTime,
					requestList[j].description));
				}
			}
		}
	
		//Body rule
		if (selection == "")
		{
			myTable = $('#workflowTable').DataTable({
			data: finalList,
				columns: [
				   {title: 'Request Id', data: 'requestId'},
				   {title: 'Request Description', data: 'description'},
				   {title: 'Step Name', data: 'name'},
				   {title: 'Approver', data: 'approver'},
				   {title: 'Approval Time', data: 'actionTime'},
				   {title: 'Status', data: 'status'}
				   ],
			dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		
		//Row selection
		$('#workflowTable tbody').on( 'click', 'tr', function () {
			clearInputVals(workflowInputElements);
			clearInputVals(workflowOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            setInputVals(selectedData, workflowElements, workflowOutputElements);
	            displayWorkflow(selectedData, data);
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {

		selectedData = {};
		if (myTable != null)
		{
			$('#workflowTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	function resultTable(approver, name, requestId, status, actionTime, description){
		this.approver = approver;
		this.name = name;
		this.requestId  =requestId;
		this.status = status;
		this.actionTime = actionTime;
		this.description = description;
	}
		
});