$(document).ready(function() {
	var myTable;
	var data;
	var selectedData = {};
	var dropSelection
	
	var BMSG = "bmsg";
	var BDESC= "bdesc";
	var RDESC= "rdesc";
	var TDESC= "tdesc";
	
	var msgBaseElements = ["#broadcastTypeMsg", "#reportTypeMsg","#messageTypeMsg","#subjectMsg","#messageMsg","#emailMsg","#effectiveDateMsg"];
	var typeBaseElements=["#broadcastTypeType","#typeDescriptionType"];
	
	var msgInputElements = appendElements(msgBaseElements, "Input");
	var msgOutputElements = appendElements(msgBaseElements, "Output");
	var typeInputElements=appendElements(typeBaseElements, "Input");
	var typeOutputElements=appendElements(typeBaseElements, "Output");
	
	var msgElements = ["broadcastType", "reportType","messageType","subject","message","email","effectiveDate"];
	var typeElements=["broadcastType","typeDescription"];
	
	
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#bcSelect').on('change',function() {
		dropSelection = $(this).val();
		if (dropSelection == BMSG)
		{
			fetchTableData("get-broadcast-message", dropSelection);
		}
		if (dropSelection == BDESC || dropSelection == RDESC || dropSelection == TDESC)
		{
			fetchTableDataForDesc("get-broadcast-type", dropSelection);
		}
		
	});
	
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		if (dropSelection == BMSG)
		{
			getDataForMessage();
			$('#messageInputDiv').show();
			$('#insertMsg').show();
		}
		if (dropSelection == BDESC ||dropSelection == RDESC || dropSelection == TDESC)
		{
			$('#typeInputDiv').show();
			$('#insertType').show();
		}
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('.copy-div').show();
		$('.output-div').show();
		
		if (dropSelection == BMSG)
		{
			getDataForMessage();
			$('#messageInputDiv').show();
			$('#updateMsg').show();
		}
		if (dropSelection == BDESC ||dropSelection == RDESC || dropSelection == TDESC)
		{
			$('#typeInputDiv').show();
			$('#updateType').show();
		}
		
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.output-div').show();
		
		if (dropSelection == BMSG)
		{
			$('#messageInputDiv').show();
			$('#deleteMsg').show();
		}
		if (dropSelection == BDESC ||dropSelection == RDESC || dropSelection == TDESC)
		{
			$('#typeInputDiv').show();
			$('#deleteType').show();
		}
	});
	
	$('#messageInsertBtn').on('click', function() {
		if (validateForm('#messageInputDiv'))
		{
			var sendData = getInputData(msgElements, msgInputElements);
			postData(sendData, "modify-broadcast-message?action=I");
		}
	});
	
	$('#messageUpdateBtn').on('click', function() {
		if (validateForm('#messageInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(msgElements, msgInputElements);
			sendData.id = selectedData.id;
			postData(sendData, "modify-broadcast-message?action=U");
		}
	});
	
	$('#messageDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			postData(selectedData, "modify-broadcast-message?action=D");
		}
	});
	
	$('#typeInsertBtn').on('click', function() {
		if (validateForm('#typeInputDiv'))
		{
			var sendData = getInputData(typeElements, typeInputElements);
			postDataForDesc(sendData, "modify-broadcast-type?action=I", dropSelection);
		}
	});
	
	$('#typeUpdateBtn').on('click', function() {
		if (validateForm('#typeInputDiv') && !jQuery.isEmptyObject(selectedData))
		{
			var sendData = getInputData(typeElements, typeInputElements);
			sendData.oldBroadcastType = selectedData.broadcastType;
			postDataForDesc(sendData, "modify-broadcast-type?action=U",dropSelection);
		}
	});
	
	$('#typeDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			postDataForDesc(selectedData, "modify-broadcast-type?action=D",dropSelection);
		}
	});
	
	
	
	$('.copy-btn').on('click', function() {
		copyInputVals(msgOutputElements, msgInputElements);
		copyInputVals(typeOutputElements, typeInputElements);
		
	});
	
	//--------------------------Data display functions-----------------------------
	
	function getUrlParam(selection)
	{
		if (selection == BDESC)
			return "B";
		if (selection == RDESC )
			return "R";
		if (selection == TDESC )
			return "M";
	}
	
	function fetchTableDataForDesc(url, selection){
		url += "?type=" + getUrlParam(selection);
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		
		//Body rule
		if (selection == BMSG)
		{
			myTable = $('#bcTable').DataTable({
				data: data,
				columns: [
				   {title: 'ID', data: 'id'},
				   {title: 'Broadcast Type', data: 'broadcastType'},
				   {title: 'Report Type', data: 'reportType'},
				   {title: 'Message Type', data: 'messageType'},
				   {title: 'Date', data: 'effectiveDate'},
				   {title: 'Subject', data: 'subject'},
				   {title: 'Message', data: 'message'},
				   {title: 'Email', data: 'email'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		if (selection == BDESC  || selection == RDESC  || selection == TDESC)
		{
			myTable = $('#bcTable').DataTable({
				data: data,
				columns: [
				   {title: 'Type', data: 'broadcastType'},
				   {title: 'Description', data: 'typeDescription'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
				
		//Row selection
		$('#bcTable tbody').on( 'click', 'tr', function () {

			clearInputVals(msgInputElements);
			clearInputVals(msgOutputElements);
			clearInputVals(typeInputElements);
			clearInputVals(typeOutputElements);
			
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            if (selection == BMSG)
	            {
	            	setInputVals(selectedData, msgElements, msgOutputElements);
	            }
	            
	            if (selection == BDESC  || selection == RDESC  || selection == TDESC)
	            {
	            	setInputVals(selectedData, typeElements, typeOutputElements);
	            }
	            
	            
	        }
	    } );
	}
		
	//Empty existing table contents
	function emptyTable() {

		clearInputVals(msgInputElements);
		clearInputVals(msgOutputElements);
		clearInputVals(typeInputElements);
		clearInputVals(typeOutputElements);
		$('.toggle-div').hide();
		selectedData = {};
		if (myTable != null)
		{
			$('#bcTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	//Pass in I, D, or U in the url action parameter
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(dropSelection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
		
	}
	
	//Update, insert, or delete based on url
	function postDataForDesc(myData, url, selection) {

		url += "&type=" + getUrlParam(selection);
		console.log(url);
		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
	function getDataForMessage(){
	  $.ajax({  
           type: "GET",  
           url: "get-input-parameters",  
           success: function (data) {  
           	   var b ; 
               var bMap=data.broadcastTypeMap;
               b +='<option selected="hidden">Select a type</option>';
               for (const [key, value] of Object.entries(bMap)) {  
                   b += '<option value="' + key + '">' + value + '</option>';  
               } 
               $('#broadcastTypeMsgInput').html(b);  
               
               var r ; 
               var rMap=data.reportTypeMap; 
               r +='<option selected="hidden">Select a type</option>';
                for (const [key, value] of Object.entries(rMap)) {  
                   r += '<option value="' + key + '">' + value + '</option>';  
               }  
               $('#reportTypeMsgInput').html(r);
               
               var mt ; 
               var mMap=data.messageTypeMap; 
               mt +='<option selected="hidden">Select a type</option>';
               for (const [key, value] of Object.entries(mMap)) {  
                   mt += '<option value="' + key + '">' + value + '</option>';  
               }  
               $('#messageTypeMsgInput').html(mt);
               
              
           }  
       }); 
       
      } 
});