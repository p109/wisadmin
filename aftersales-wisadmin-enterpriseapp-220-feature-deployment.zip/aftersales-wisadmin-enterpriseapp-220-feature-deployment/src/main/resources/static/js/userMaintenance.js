$(document).ready(function() {
	var myTable;
	var data;
	var selectedData = {};
	var groupsOpen = [];
	var groupsChosen = [];
	var groupsDescription = {};
	var searchClicked = false;
	var idSearched = "";
	
	fetchTableData("get-user-membership");
	fetchGroupDescription("get-user-group");
	
	function fetchTableData(url){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable();
			}
		});
	}
	
	function fetchGroupDescription(url) {
		$.ajax({
			url: url,
			success: function(result) {
				groupsDescription = result;
			}
		});
	}
	
	//Refresh table with new data
	function updateTable() {
					
		myTable = $('#userTable').DataTable({
			data: data,
			columns: [
			     {title: 'User', data: 'userId'},
			     {title: 'Group', data: 'userGroup'},
			],
			dom: 'Bfrtip',
			buttons: [{
				extend: 'print',
				exportOptions: {
					stripHtml: false
				}
			}]
		});
	}
	
	//Empty existing table contents
	function emptyTable() {		
		if (myTable != null)
		{
			$('#userTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	
	$('#searchButton').on('click', function() {
		//Prevents user from multi clicking
		if (!searchClicked)
		{
			searchClicked = true;
			groupsChosen = [];
			groupsOpen = [];
			$.ajax({
				url: "get-user-details?id=" + $('#userSearch').val(),
				success: function(result) {
					if (result.fullName != null)
					{
						$('#userDetails').text(result.fullName);
					}
					else
					{
						$('#userDetails').text("Name not found in directory." + 
								"  User can still be assigned roles.");
					}
				}
			});
			
			$.ajax({
				url: "get-user-membership?id=" + $('#userSearch').val(),
				success: function(result) {
					searchClicked = false;
					idSearched = $('#userSearch').val();
					//Put the group results into active groups
					for (var i = 0; i < result.length; i++)
					{
						currGroup = result[i];
						addGroup(currGroup);
					}
					
					populateAvailableGroups();
					
					populateSelect();
				}
			});
		}
	});
	
	$('#updateUserButton').on('click', function () {
		
		var userArr = [];
		
		//Get groups which user will be assigned
		for (var i = 0; i < groupsChosen.length; i++)
		{
			var userData = {};
			userData.userId = idSearched;
			userData.userGroup = groupsChosen[i].groupName;
			userArr.push(userData);
		}
		
		if (groupsChosen.length == 0)
		{
			var userData = {};
			userData.userId = idSearched;
			userData.userGroup = "";
			userArr.push(userData);
		}
		
		$.ajax({
			url: "update-user-membership",
			data: JSON.stringify(userArr),
			method: "POST",
			contentType: "application/json",
			success: function(result)
			{
				console.log(result);
				data = result;
				emptyTable();
				updateTable();
			}
		});
	});
	
	$('#addGroupButton').on('click', function () {
		var groupArr = $('#availableGroup').val();
		//Add group to the array
		for (var i = 0; i < groupArr.length; i++)
		{
			for (var j = 0; j < groupsDescription.length; j++)
			{
				if (groupsDescription[j].groupName == groupArr[i])
				{
					groupsChosen.push(groupsDescription[j]);
				}
			}
		}
		//Rebuild available groups
		populateAvailableGroups();
		
		//Rebuild the html groups
		populateSelect();
	});
	
	//Same function as above just swapped the groups modified
	$('#removeGroupButton').on('click', function() {
		var groupArr = $('#activeGroup').val();
		for (var i = 0; i < groupArr.length; i++)
		{
			for (var j = 0; j < groupsDescription.length; j++)
			{
				if (groupsDescription[j].groupName == groupArr[i])
				{
					groupsOpen.push(groupsDescription[j]);
				}
			}
		}
		populateChosenGroups();
		
		populateSelect();
	});
	
	//Adds a group to the user active group
	function addGroup(currGroup)
	{
		for (var i = 0; i < groupsDescription.length; i++)
		{
			if (groupsDescription[i].groupName == currGroup.userGroup)
			{
				groupsChosen.push(groupsDescription[i]);
				break;
			}
		}
	}
	
	function populateChosenGroups()
	{
		groupsChosen = [];
		//Put the unfound groups into chosen groups
		for (var i = 0; i < groupsDescription.length; i++)
		{
			var currGroup = groupsDescription[i];
			var addUnfound = true;
			for (var j = 0; j < groupsOpen.length; j++)
			{
				if (currGroup.groupName == groupsOpen[j].groupName)
				{
					addUnfound = false;
					break;
				}
			}
			
			if (addUnfound)
			{
				groupsChosen.push(currGroup);
			}
		}
	}
	
	function populateAvailableGroups()
	{
		groupsOpen = [];
		//Put the unfound groups into available groups
		for (var i = 0; i < groupsDescription.length; i++)
		{
			var currGroup = groupsDescription[i];
			var addUnfound = true;
			for (var j = 0; j < groupsChosen.length; j++)
			{
				if (currGroup.groupName == groupsChosen[j].groupName)
				{
					addUnfound = false;
					break;
				}
			}
			
			if (addUnfound)
			{
				groupsOpen.push(currGroup);
			}
		}
	}
	
	function populateSelect()
	{
		$('#availableGroup').empty();
		$('#activeGroup').empty();
		for (var i = 0; i < groupsOpen.length; i++)
		{
			var currName = groupsOpen[i].groupName
			$('#availableGroup').append("<option value='" + currName + "'>" + currName + "</option>")
		}
		
		for (var i = 0; i < groupsChosen.length; i++)
		{
			var currName = groupsChosen[i].groupName
			$('#activeGroup').append("<option value='" + currName + "'>" + currName + "</option>");
		}
	}
});