$(document).ready(function() {
	var myTable;
	var data;
	var selectedData;
	var dropSelection;
	
	//store these constants for UI and table updates
	var APDESC = 'apdesc';
	var EPDESC = 'epdesc';
	var TPDESC = 'tpdesc';
	var EPCODE = 'epcode';
	var TPCODE = 'tpcode';
	
	//Input field elements
	var insertPlantElements = ["#plantInsertInput", "#plantDescInsertInput", "#plantLocInsertInput"];
	var updatePlantElements = ["#plantUpdateOld", "#plantDescUpdateOld", "#plantLocUpdateOld"];
	var deletePlantElements = ["#plantDeleteInput", "#plantDescDeleteInput", "#plantLocDeleteInput"];
	var copyPlantElements = ["#plantUpdateNew", "#plantDescUpdateNew", "#plantLocUpdateNew"];
	
	var insertPlantCodeElements = ["#plantCodeInsertInput", "#plantUcodeInsertInput", 
	                           "#salesCodeInsertInput", "#myInsertInput"];
	var updatePlantCodeElements = ["#plantCodeUpdateOld", "#plantUcodeUpdateOld", 
	                               "#salesCodeUpdateOld", "#myUpdateOld"];
	var deletePlantCodeElements = ["#plantCodeDeleteInput", "#plantUcodeDeleteInput", 
	                               "#salesCodeDeleteInput","#myDeleteInput"];
	var copyPlantCodeElements = ["#plantCodeUpdateNew", "#plantUcodeUpdateNew", 
	                             "#salesCodeUpdateNew", "#myUpdateNew"];
	
	var plantElements = ["plant", "plantDescription", "plantLocation"];
	var plantCodeElements = ["plant", "plantCode", "salesCode", "modelYear"];
	
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#plantSelect').on('change',function() {
		dropSelection = $(this).val();
		if (dropSelection == APDESC || dropSelection == EPDESC || dropSelection == TPDESC)
		{
			fetchTableData("get-plant-desc", dropSelection);
		}
		
		if (dropSelection == EPCODE || dropSelection == TPCODE)
		{
			fetchTableData("get-plant-codes", dropSelection);
		}
		
	});
	
	//Change data on tables
	$('#plantInsertBtn').on('click', function() {
			var insertData = getInputData(plantElements, insertPlantElements);
			postData(insertData, "insert-plant-desc", dropSelection);
	});
	
	$('#plantUpdateBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var updateData = [];
			updateData.push(getInputData(plantElements, updatePlantElements));
			updateData.push(getInputData(plantElements, copyPlantElements));
			postData(updateData, "update-plant-desc", dropSelection);
		}
	});
	
	$('#plantDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = getInputData(plantElements, deletePlantElements);
			postData(deleteData, "delete-plant-desc", dropSelection);
		}
	});
	
	$('#plantCodeInsertBtn').on('click', function() {
			var insertData = getInputData(plantCodeElements, insertPlantCodeElements);
			postData(insertData, "insert-plant-code", dropSelection);
	});
	
	$('#plantCodeUpdateBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var updateData = [];
			updateData.push({"id": selectedData.id});
			updateData.push(getInputData(plantCodeElements, copyPlantCodeElements));
			postData(updateData, "update-plant-code", dropSelection);
		}
	});
	
	$('#plantCodeDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = {"id": selectedData.id};
			postData(deleteData, "delete-plant-code", dropSelection);
		}
	});
	
	
	//Show / hide data update input fields
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		if (dropSelection == APDESC || dropSelection == EPDESC || dropSelection == TPDESC)
		{
			$('#insertPlantDesc').show();
		}
		if (dropSelection == EPCODE || dropSelection == TPCODE)
		{
			$('#insertPlantCode').show();
		}
		
		showHideAssembly(dropSelection);
		
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		if (dropSelection == APDESC || dropSelection == EPDESC || dropSelection == TPDESC)
		{
			$('#updatePlantDesc').show();
		}
		if (dropSelection == EPCODE || dropSelection == TPCODE)
		{
			$('#updatePlantCode').show();
		}
		
		showHideAssembly(dropSelection);
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		if (dropSelection == APDESC || dropSelection == EPDESC || dropSelection == TPDESC)
		{
			$('#deletePlantDesc').show();
		}
		if (dropSelection == EPCODE || dropSelection == TPCODE)
		{
			$('#deletePlantCode').show();
		}
		
		showHideAssembly(dropSelection);
	});
	
	$('.copy-btn').on('click', function() {
		copyInputVals(updatePlantElements, copyPlantElements);
		copyInputVals(updatePlantCodeElements, copyPlantCodeElements);
	});
	
	//Shows or hides the assembly plant inputs if assembly plant is selected
	function showHideAssembly(selection)
	{
		if (selection == APDESC)
			$('.assembly-only').show();
		else
			$('.assembly-only').hide();
	}
	
	//--------------------------Data display functions-----------------------------
	
	function getUrlParam(selection)
	{
		if (selection == APDESC)
			return "A";
		if (selection == EPDESC || selection == EPCODE)
			return "E";
		if (selection == TPDESC || selection == TPCODE)
			return "T";
	}
	
	function fetchTableData(url, selection){
		url += "?type=" + getUrlParam(selection);
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		//Component type
		
		if (selection == APDESC)
		{	
			
			myTable = $('#plantTable').DataTable({
				data: data,
				columns: [
				     {title: 'Plant code', data: 'plant'},
				     {title: 'Description', data: 'plantDescription'},
				     {title: 'Location', data: 'plantLocation'},
				     {title: 'Updated By', data: 'user'},
				     {title: 'Updated On', data: 'updateTimestamp'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}

		//Class description
		if (selection == EPDESC || selection == TPDESC)
		{
			myTable = $('#plantTable').DataTable({
				data: data,
				columns: [
				   {title: 'Plant Code', data: 'plant'},
				   {title: 'Description', data: 'plantDescription'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTimestamp'}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		//Trans description
		if (selection == EPCODE || selection == TPCODE)
		{
			myTable = $('#plantTable').DataTable({
				data: data,
				columns: [
				   {title: 'Plant', data: 'plant'},
				   {title: 'Plant Code', data: 'plantCode'},
				   {title: 'Sales Code', data: 'salesCode'},
				   {title: 'Model Year', data: 'modelYear'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTimestamp'},
				   {title: 'id', data: 'id', visible: false}
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		//Row selection
		$('#plantTable tbody').on( 'click', 'tr', function () {
	        
			clearInputVals(updatePlantElements);
			clearInputVals(deletePlantElements);
			clearInputVals(updatePlantCodeElements);
			clearInputVals(deletePlantCodeElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            //Insert selection into input fields
	            if (selection == APDESC || selection == EPDESC || selection == TPDESC)
	            {
	            	setInputVals(selectedData, plantElements, updatePlantElements);
	            	setInputVals(selectedData, plantElements, deletePlantElements);
	            }
	            if (selection == EPCODE || selection == TPCODE)
	            {
	            	setInputVals(selectedData, plantCodeElements, updatePlantCodeElements);
	            	setInputVals(selectedData, plantCodeElements, deletePlantCodeElements);
	            }
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {
		clearInputVals(insertPlantElements);
		clearInputVals(updatePlantElements);
		clearInputVals(deletePlantElements);
		clearInputVals(copyPlantElements);
		clearInputVals(insertPlantCodeElements);
		clearInputVals(updatePlantCodeElements);
		clearInputVals(deletePlantCodeElements);
		clearInputVals(copyPlantCodeElements);
		
		selectedData = {};
		
		if (myTable != null)
		{
			$('#plantTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	function postData(myData, url, selection) {

		url += "?type=" + getUrlParam(selection);
		console.log(url);
		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
});