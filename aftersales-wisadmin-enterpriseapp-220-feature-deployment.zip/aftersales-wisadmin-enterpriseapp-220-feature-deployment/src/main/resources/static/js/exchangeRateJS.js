$(document).ready(function() {
	var myTable;
	var data;
	var selectedData;
	var dropSelection;
	
	//store these constants for UI and table updates
	var CANADA = 'canada';
	var EXCHANGE = 'exchange';
	
	var canadaBaseElements = ["#myCanada", "#rateCanada"];
	var exchangeBaseElements = ["#currencyExchange", "#effectiveDateExchange","#rateExchange"];
	
	var canadaInputElements = appendElements(canadaBaseElements, "Input");
	var canadaOutputElements = appendElements(canadaBaseElements, "Output");
	
	var exchangeInputElements = appendElements(exchangeBaseElements, "Input");
	var exchangeOutputElements = appendElements(exchangeBaseElements, "Output");
	
	var canadaElements = ["modelYear", "rate"];
	var exchangeElements=["curr","effectiveDate","rate"];
	
	//-------------------------UI functions----------------------------
	
	//If table dropdown changes fetch new data
	$('#exchangeSelect').on('change',function() {
		dropSelection = $(this).val();
		if (dropSelection == CANADA)
		{
			fetchTableData("get-canada-rates", dropSelection);
		}
		if (dropSelection == EXCHANGE)
		{
			fetchTableData("get-exchange-rates", dropSelection);
		}
		
	});
	
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		if (dropSelection == CANADA)
		{
			$('#canadaInputDiv').show();
			$('#insertCanadaRate').show();
		}
		if (dropSelection == EXCHANGE)
		{
			$('#exchangeInputDiv').show();
			$('#insertExchangeRate').show();
		}
		
	});
	
	$('#updateBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.input-div').show();
		$('.output-div').show();
		$('.copy-div').show();
		if (dropSelection == CANADA)
		{
			$('#canadaInputDiv').show();
			$('#updateCanadaRate').show();
		}
		if (dropSelection == EXCHANGE)
		{
			$('#exchangeInputDiv').show();
			$('#updateExchangeRate').show();
		}
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
		$('.output-div').show();
		if (dropSelection == CANADA)
		{
			$('#canadaInputDiv').show();
			$('#deleteCanadaRate').show();
		}
		if (dropSelection == EXCHANGE)
		{
			$('#exchangeInputDiv').show();
			$('#deleteExchangeRate').show();
		}
	});
	
	$('.copy-btn').on('click', function() {
		copyInputVals(canadaOutputElements, canadaInputElements);
		copyInputVals(exchangeOutputElements, exchangeInputElements);
	});
	
	$('#canadaInsertBtn').on('click', function() {
		var sendData = getInputData(canadaElements, canadaInputElements);
		postData(sendData, "modify-canada-rate?action=I");
	});
	
	$('#canadaUpdateBtn').on('click', function() {
		var sendData = getInputData(canadaElements, canadaInputElements);
		sendData.oldModelYear = selectedData.modelYear;
		postData(sendData, "modify-canada-rate?action=U");
	});
	
	$('#canadaDeleteBtn').on('click', function() {
		var sendData = getInputData(canadaElements, canadaOutputElements);
		postData(sendData, "modify-canada-rate?action=D");
	});
	
	$('#exchangeInsertBtn').on('click', function() {
		var sendData = getInputData(exchangeElements, exchangeInputElements);
		postData(sendData, "modify-exchange-rate?action=I");
	});
	
	$('#exchangeUpdateBtn').on('click', function() {
		var sendData = getInputData(exchangeElements, exchangeInputElements);
		sendData.oldCurr = selectedData.curr;
		sendData.oldEffectiveDate=selectedData.effectiveDate;
		postData(sendData, "modify-exchange-rate?action=U");
	});
	
	$('#exchangeDeleteBtn').on('click', function() {
		var sendData = getInputData(exchangeElements, exchangeOutputElements);
		postData(sendData, "modify-exchange-rate?action=D");
	});
	
	//--------------------------Data display functions-----------------------------
	
	function fetchTableData(url, selection){
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(selection);
			}
		});
	}
	
	//Refresh table with new data
	function updateTable(selection) {
		
		//Oh Canada
		if (selection == CANADA)
		{
			myTable = $('#exchangeTable').DataTable({
				data: data,
				columns: [
				   {title: 'Model Year', data: 'modelYear'},
				   {title: 'Exchange Rate', data: 'rate'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'},
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		if (selection == EXCHANGE)
		{
			myTable = $('#exchangeTable').DataTable({
				data: data,
				columns: [
				   {title: 'Currency', data: 'curr'},
				   {title: 'Effective Date', data: 'effectiveDate'},
				   {title: 'Exchange Rate', data: 'rate'},
				   {title: 'Updated By', data: 'user'},
				   {title: 'Updated On', data: 'updateTime'},
				],
				dom: 'Bfrtip',
				buttons: ['print']
			});
		}
		
		//Row selection
		$('#exchangeTable tbody').on( 'click', 'tr', function () {

			clearInputVals(canadaInputElements);
			clearInputVals(canadaOutputElements);
			clearInputVals(exchangeInputElements);
			clearInputVals(exchangeOutputElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            
	            if (selection == CANADA)
	            {
	            	setInputVals(selectedData, canadaElements, canadaOutputElements);
	            }
	            
	            if (selection == EXCHANGE)
	            {
	            	setInputVals(selectedData, exchangeElements, exchangeOutputElements);
	            }
	        }
	    } );
	}
	
	//Empty existing table contents
	function emptyTable() {

		clearInputVals(canadaInputElements);
		clearInputVals(canadaOutputElements);
		clearInputVals(exchangeInputElements);
		clearInputVals(exchangeOutputElements);
		if (myTable != null)
		{
			$('#exchangeTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	//-------------------------------Data update functions---------------------------
	
	//Update, insert, or delete based on url
	//Pass in I, D, or U in the url action parameter
	function postData(myData, url) {

		$.ajax({
			url: url,
			data: JSON.stringify(myData),
			method: "POST",
			contentType: "application/json",
			success: function(result) {
				data = result;
				emptyTable();
				updateTable(dropSelection);
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
});